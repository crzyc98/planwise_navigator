"""
Cross-year cost attribution system with UUID-stamped precision for multi-year coordination.

This module provides enterprise-grade cost attribution capabilities for workforce simulation with:
- UUID-stamped cost attribution across year boundaries with sub-millisecond precision  
- Decimal precision (18,6) for regulatory compliance
- Cross-year cost calculation and attribution functionality
- Immutable audit trails through event sourcing
- Integration with existing SimulationEvent model

Components:
- CostAttributionEntry: Individual cost attribution record with UUID tracking
- CrossYearCostAttributor: Main cost attribution engine with precision calculations
- CostAllocationStrategy: Configurable allocation strategies for different cost types
- AttributionAuditTrail: Complete audit trail for regulatory compliance

Architecture follows PlanWise Navigator's event sourcing principles:
- All cost attributions are event-driven and immutable
- Complete audit trail preservation for regulatory compliance
- Type-safe validation using Pydantic v2
- Integration with existing state management system
"""

from __future__ import annotations
import logging
from typing import Dict, Any, Optional, List, Set, Union, Tuple, Literal
from datetime import datetime, date
from decimal import Decimal, ROUND_HALF_UP
from uuid import UUID, uuid4
from dataclasses import dataclass, field
from enum import Enum
import time
import hashlib
import json

from pydantic import BaseModel, Field, ConfigDict, field_validator, computed_field
from pydantic.types import NonNegativeInt, PositiveInt

# Import existing event model and state management
from config.events import SimulationEvent, EventFactory
from .state_management import SimulationState, WorkforceMetrics

logger = logging.getLogger(__name__)


class CostAttributionType(str, Enum):
    """Types of cost attribution calculations."""
    COMPENSATION_BASELINE = "compensation_baseline"
    COMPENSATION_CHANGE = "compensation_change"
    BENEFIT_ENROLLMENT = "benefit_enrollment"
    CONTRIBUTION_MATCHING = "contribution_matching"
    FORFEITURE_ALLOCATION = "forfeiture_allocation"
    ADMINISTRATIVE_OVERHEAD = "administrative_overhead"
    COMPLIANCE_MONITORING = "compliance_monitoring"
    CROSS_YEAR_TRANSITION = "cross_year_transition"


class AllocationStrategy(str, Enum):
    """Strategies for cost allocation across time periods."""
    PRO_RATA_TEMPORAL = "pro_rata_temporal"          # Time-based allocation
    PRO_RATA_WORKFORCE = "pro_rata_workforce"        # Workforce size-based
    EVENT_DRIVEN = "event_driven"                    # Based on specific events
    COMPENSATION_WEIGHTED = "compensation_weighted"   # Weighted by compensation levels
    HYBRID_TEMPORAL_WORKFORCE = "hybrid"             # Combined approach


class CostAttributionEntry(BaseModel):
    """
    Individual cost attribution record with UUID tracking and regulatory precision.
    
    Provides immutable cost attribution records with:
    - UUID-stamped attribution for complete audit trail
    - Decimal precision (18,6) for regulatory compliance
    - Cross-year attribution capabilities
    - Event source tracking for audit purposes
    """
    
    model_config = ConfigDict(
        frozen=True,  # Immutable for audit trail integrity
        use_enum_values=True,
        validate_assignment=True
    )
    
    # Core identification with UUID tracking
    attribution_id: UUID = Field(default_factory=uuid4)
    employee_id: str = Field(..., min_length=1)
    scenario_id: str = Field(..., min_length=1)
    plan_design_id: str = Field(..., min_length=1)
    
    # Temporal context with sub-millisecond precision
    attribution_timestamp: datetime = Field(default_factory=lambda: datetime.utcnow())
    effective_date: date
    attribution_year: PositiveInt
    source_year: PositiveInt  # Year that generated the cost
    
    # Cost attribution details with regulatory precision
    attribution_type: CostAttributionType
    allocation_strategy: AllocationStrategy
    
    # Monetary amounts with enterprise precision (18,6)
    gross_amount: Decimal = Field(..., decimal_places=6, ge=0)
    attributed_amount: Decimal = Field(..., decimal_places=6, ge=0)
    allocation_percentage: Decimal = Field(..., decimal_places=6, ge=0, le=1)
    
    # Event source tracking for audit trail
    source_event_id: Optional[UUID] = None
    related_event_ids: List[UUID] = Field(default_factory=list)
    
    # Cost category context
    cost_category: str = Field(..., min_length=1)
    cost_subcategory: Optional[str] = None
    business_unit: Optional[str] = None
    
    # Attribution metadata
    attribution_basis: str = Field(..., min_length=1)  # Explanation of allocation basis
    confidence_score: Decimal = Field(default=Decimal('1.0'), decimal_places=4, ge=0, le=1)
    
    # Audit and compliance
    created_by_system: str = Field(default="cost_attribution_engine")
    regulatory_category: Optional[str] = None
    requires_annual_testing: bool = False
    
    @field_validator('gross_amount', 'attributed_amount')
    @classmethod
    def validate_monetary_precision(cls, v: Decimal) -> Decimal:
        """Ensure monetary amounts have enterprise-grade precision (18,6)."""
        return v.quantize(Decimal('0.000001'), rounding=ROUND_HALF_UP)
    
    @field_validator('allocation_percentage', 'confidence_score')
    @classmethod
    def validate_percentage_precision(cls, v: Decimal) -> Decimal:
        """Ensure percentages have proper precision (6 decimal places)."""
        return v.quantize(Decimal('0.000001'), rounding=ROUND_HALF_UP)
    
    @field_validator('employee_id', 'scenario_id', 'plan_design_id')
    @classmethod
    def validate_identifiers(cls, v: str) -> str:
        """Validate identifiers are not empty."""
        if not v or not v.strip():
            raise ValueError('Identifier cannot be empty')
        return v.strip()
    
    @field_validator('attribution_basis')
    @classmethod
    def validate_attribution_basis(cls, v: str) -> str:
        """Validate attribution basis is descriptive."""
        if not v or len(v.strip()) < 10:
            raise ValueError('Attribution basis must be at least 10 characters')
        return v.strip()
    
    @computed_field
    @property
    def allocation_variance(self) -> Decimal:
        """Calculate variance between gross and attributed amounts."""
        if self.gross_amount == 0:
            return Decimal('0')
        return ((self.attributed_amount - self.gross_amount) / self.gross_amount).quantize(Decimal('0.000001'))
    
    @computed_field
    @property
    def cross_year_attribution(self) -> bool:
        """Check if this is a cross-year attribution."""
        return self.attribution_year != self.source_year
    
    def verify_attribution_integrity(self) -> Tuple[bool, List[str]]:
        """
        Verify attribution record integrity for audit purposes.
        
        Returns:
            Tuple of (is_valid, list_of_issues)
        """
        issues = []
        
        # Verify attribution amounts are consistent
        expected_attributed = (self.gross_amount * self.allocation_percentage).quantize(Decimal('0.000001'))
        if abs(self.attributed_amount - expected_attributed) > Decimal('0.000001'):
            issues.append(f"Attribution amount inconsistency: expected {expected_attributed}, got {self.attributed_amount}")
        
        # Verify temporal consistency
        if self.source_year > self.attribution_year:
            issues.append(f"Invalid temporal relationship: source year {self.source_year} > attribution year {self.attribution_year}")
        
        # Verify allocation percentage bounds
        if not (Decimal('0') <= self.allocation_percentage <= Decimal('1')):
            issues.append(f"Allocation percentage out of bounds: {self.allocation_percentage}")
        
        # Verify confidence score bounds
        if not (Decimal('0') <= self.confidence_score <= Decimal('1')):
            issues.append(f"Confidence score out of bounds: {self.confidence_score}")
        
        return len(issues) == 0, issues


class AttributionAuditTrail(BaseModel):
    """Complete audit trail for cost attribution operations."""
    
    model_config = ConfigDict(
        frozen=True,
        use_enum_values=True
    )
    
    # Audit identification
    audit_id: UUID = Field(default_factory=uuid4)
    operation_timestamp: datetime = Field(default_factory=datetime.utcnow)
    
    # Attribution context
    scenario_id: str = Field(..., min_length=1)
    attribution_year: PositiveInt
    operation_type: Literal["create", "allocate", "cross_year_transfer", "validation"]
    
    # Attribution records involved
    attribution_entries: List[CostAttributionEntry] = Field(default_factory=list)
    total_gross_amount: Decimal = Field(default=Decimal('0'), decimal_places=6)
    total_attributed_amount: Decimal = Field(default=Decimal('0'), decimal_places=6)
    
    # Processing metadata
    processing_duration_ms: Decimal = Field(default=Decimal('0'), decimal_places=3)
    records_processed: NonNegativeInt = 0
    
    # Validation results
    validation_passed: bool = True
    validation_issues: List[str] = Field(default_factory=list)
    
    # System context
    system_version: str = Field(default="1.0.0")
    processor_id: str = Field(default="cost_attribution_engine")
    
    @field_validator('total_gross_amount', 'total_attributed_amount')
    @classmethod
    def validate_totals_precision(cls, v: Decimal) -> Decimal:
        """Ensure totals have proper precision."""
        return v.quantize(Decimal('0.000001'), rounding=ROUND_HALF_UP)
    
    @computed_field
    @property
    def allocation_efficiency(self) -> Decimal:
        """Calculate allocation efficiency percentage."""
        if self.total_gross_amount == 0:
            return Decimal('0')
        return (self.total_attributed_amount / self.total_gross_amount).quantize(Decimal('0.000001'))


@dataclass
class CrossYearAllocationContext:
    """Context for cross-year cost allocation operations."""
    
    source_year: int
    target_years: List[int]
    allocation_strategy: AllocationStrategy
    
    # Source data
    source_workforce_metrics: WorkforceMetrics
    source_events: List[SimulationEvent]
    
    # Target allocation data
    target_workforce_metrics: Dict[int, WorkforceMetrics]
    
    # Allocation parameters
    allocation_weights: Dict[int, Decimal] = field(default_factory=dict)
    temporal_decay_factor: Decimal = field(default=Decimal('1.0'))
    
    # Processing metadata
    start_timestamp: Optional[datetime] = None
    estimated_complexity: Optional[int] = None


class CrossYearCostAttributor:
    """
    Enterprise-grade cross-year cost attribution engine with UUID-stamped precision.
    
    Provides sophisticated cost attribution capabilities for multi-year workforce simulations:
    - UUID-stamped cost attribution across year boundaries with sub-millisecond precision
    - Decimal precision (18,6) for regulatory compliance
    - Multiple allocation strategies for different cost types
    - Complete audit trail for regulatory compliance
    - Performance optimization for large-scale simulations
    
    Features:
    - Cross-year workforce cost transitions
    - Event-driven cost attribution with audit trails
    - Multiple allocation strategies (pro-rata, event-driven, compensation-weighted)
    - Regulatory compliance with immutable audit records
    - Integration with existing state management system
    """
    
    def __init__(
        self,
        scenario_id: str,
        plan_design_id: str,
        default_allocation_strategy: AllocationStrategy = AllocationStrategy.PRO_RATA_TEMPORAL,
        precision_decimal_places: int = 6,
        enable_audit_trail: bool = True,
        logger: Optional[logging.Logger] = None
    ):
        """
        Initialize cross-year cost attributor.
        
        Args:
            scenario_id: Unique scenario identifier
            plan_design_id: Plan design identifier
            default_allocation_strategy: Default strategy for cost allocation
            precision_decimal_places: Decimal precision for calculations (default 6)
            enable_audit_trail: Enable comprehensive audit trail
            logger: Optional logger instance
        """
        self.scenario_id = scenario_id
        self.plan_design_id = plan_design_id
        self.default_allocation_strategy = default_allocation_strategy
        self.precision_decimal_places = precision_decimal_places
        self.enable_audit_trail = enable_audit_trail
        self.logger = logger or logging.getLogger(__name__)
        
        # Attribution tracking
        self._attribution_entries: Dict[UUID, CostAttributionEntry] = {}
        self._audit_trails: List[AttributionAuditTrail] = []
        
        # Performance metrics
        self._total_attributions_processed = 0
        self._total_processing_time_ms = Decimal('0')
        
        # Precision context for calculations
        self._precision_context = Decimal('0.' + '0' * (precision_decimal_places - 1) + '1')
        
        self.logger.info(f"Initialized CrossYearCostAttributor for scenario {scenario_id}")
        self.logger.info(f"Using {default_allocation_strategy.value} allocation strategy with {precision_decimal_places} decimal precision")
    
    def attribute_compensation_costs_across_years(
        self,
        allocation_context: CrossYearAllocationContext
    ) -> List[CostAttributionEntry]:
        """
        Attribute compensation costs across multiple years with regulatory precision.
        
        Args:
            allocation_context: Context for cross-year allocation
            
        Returns:
            List of cost attribution entries
        """
        start_time = time.time()
        allocation_context.start_timestamp = datetime.utcnow()
        
        try:
            self.logger.info(f"Starting cross-year cost attribution from {allocation_context.source_year} to {allocation_context.target_years}")
            
            # Extract compensation events from source year
            compensation_events = [
                event for event in allocation_context.source_events
                if event.payload.event_type in ['hire', 'promotion', 'merit', 'termination']
            ]
            
            if not compensation_events:
                self.logger.warning(f"No compensation events found for attribution from year {allocation_context.source_year}")
                return []
            
            # Calculate total compensation impact
            total_compensation_impact = self._calculate_total_compensation_impact(compensation_events)
            
            self.logger.info(f"Total compensation impact: ${total_compensation_impact:,.2f} from {len(compensation_events)} events")
            
            # Generate attribution entries for each target year
            attribution_entries = []
            
            for target_year in allocation_context.target_years:
                if target_year not in allocation_context.target_workforce_metrics:
                    self.logger.warning(f"No workforce metrics available for target year {target_year}, skipping")
                    continue
                
                # Calculate allocation weights for this target year
                allocation_weight = self._calculate_allocation_weight(
                    allocation_context.source_workforce_metrics,
                    allocation_context.target_workforce_metrics[target_year],
                    allocation_context.allocation_strategy,
                    target_year - allocation_context.source_year
                )
                
                # Create attribution entries for each compensation event
                for event in compensation_events:
                    attributed_amount = self._calculate_attributed_amount(
                        event,
                        total_compensation_impact,
                        allocation_weight,
                        allocation_context.allocation_strategy
                    )
                    
                    if attributed_amount > Decimal('0'):
                        attribution_entry = self._create_attribution_entry(
                            event,
                            allocation_context.source_year,
                            target_year,
                            attributed_amount,
                            allocation_weight,
                            allocation_context.allocation_strategy
                        )
                        
                        attribution_entries.append(attribution_entry)
                        self._attribution_entries[attribution_entry.attribution_id] = attribution_entry
            
            # Create audit trail if enabled
            if self.enable_audit_trail:
                processing_duration = Decimal(str((time.time() - start_time) * 1000)).quantize(Decimal('0.001'))
                audit_trail = self._create_audit_trail(
                    allocation_context.source_year,
                    "cross_year_transfer",
                    attribution_entries,
                    processing_duration
                )
                self._audit_trails.append(audit_trail)
            
            # Update performance metrics
            self._total_attributions_processed += len(attribution_entries)
            self._total_processing_time_ms += Decimal(str((time.time() - start_time) * 1000))
            
            self.logger.info(f"Created {len(attribution_entries)} cost attribution entries across {len(allocation_context.target_years)} target years")
            
            return attribution_entries
            
        except Exception as e:
            self.logger.error(f"Cross-year cost attribution failed: {str(e)}")
            raise
    
    def attribute_benefit_enrollment_costs(
        self,
        enrollment_events: List[SimulationEvent],
        source_year: int,
        target_year: int,
        default_contribution_rate: Decimal = Decimal('0.03')
    ) -> List[CostAttributionEntry]:
        """
        Attribute benefit enrollment costs with precision tracking.
        
        Args:
            enrollment_events: List of enrollment events
            source_year: Source year for cost calculation
            target_year: Target year for attribution
            default_contribution_rate: Default employer contribution rate
            
        Returns:
            List of cost attribution entries
        """
        start_time = time.time()
        
        try:
            self.logger.info(f"Attributing benefit enrollment costs: {len(enrollment_events)} events from year {source_year} to {target_year}")
            
            attribution_entries = []
            
            for event in enrollment_events:
                if event.payload.event_type != 'enrollment':
                    continue
                
                # Estimate employer contribution cost
                if hasattr(event.payload, 'pre_tax_contribution_rate'):
                    contribution_rate = event.payload.pre_tax_contribution_rate
                else:
                    contribution_rate = default_contribution_rate
                
                # Estimate annual compensation (simplified - would need actual data)
                estimated_annual_compensation = Decimal('75000.00')  # Placeholder
                estimated_employer_cost = (estimated_annual_compensation * contribution_rate * default_contribution_rate).quantize(self._precision_context)
                
                if estimated_employer_cost > Decimal('0'):
                    attribution_entry = CostAttributionEntry(
                        employee_id=event.employee_id,
                        scenario_id=self.scenario_id,
                        plan_design_id=self.plan_design_id,
                        effective_date=event.effective_date,
                        attribution_year=target_year,
                        source_year=source_year,
                        attribution_type=CostAttributionType.BENEFIT_ENROLLMENT,
                        allocation_strategy=AllocationStrategy.EVENT_DRIVEN,
                        gross_amount=estimated_employer_cost,
                        attributed_amount=estimated_employer_cost,
                        allocation_percentage=Decimal('1.0'),
                        source_event_id=event.event_id,
                        cost_category="benefit_enrollment",
                        attribution_basis=f"Direct employer contribution for enrollment event {event.event_id}"
                    )
                    
                    attribution_entries.append(attribution_entry)
                    self._attribution_entries[attribution_entry.attribution_id] = attribution_entry
            
            # Create audit trail
            if self.enable_audit_trail:
                processing_duration = Decimal(str((time.time() - start_time) * 1000)).quantize(Decimal('0.001'))
                audit_trail = self._create_audit_trail(
                    source_year,
                    "allocate",
                    attribution_entries,
                    processing_duration
                )
                self._audit_trails.append(audit_trail)
            
            self.logger.info(f"Created {len(attribution_entries)} benefit enrollment attribution entries")
            
            return attribution_entries
            
        except Exception as e:
            self.logger.error(f"Benefit enrollment cost attribution failed: {str(e)}")
            raise
    
    def get_attribution_summary(
        self,
        target_year: int,
        attribution_type: Optional[CostAttributionType] = None
    ) -> Dict[str, Any]:
        """
        Generate comprehensive attribution summary for analysis.
        
        Args:
            target_year: Year to summarize
            attribution_type: Optional filter by attribution type
            
        Returns:
            Attribution summary dictionary
        """
        # Filter attribution entries
        entries = [
            entry for entry in self._attribution_entries.values()
            if entry.attribution_year == target_year
        ]
        
        if attribution_type:
            entries = [entry for entry in entries if entry.attribution_type == attribution_type]
        
        if not entries:
            return {
                'target_year': target_year,
                'attribution_type': attribution_type.value if attribution_type else 'all',
                'total_entries': 0,
                'total_attributed_amount': Decimal('0'),
                'message': 'No attribution entries found'
            }
        
        # Calculate summary statistics
        total_attributed = sum(entry.attributed_amount for entry in entries)
        total_gross = sum(entry.gross_amount for entry in entries)
        
        # Group by cost category
        category_breakdown = {}
        for entry in entries:
            category = entry.cost_category
            if category not in category_breakdown:
                category_breakdown[category] = {
                    'count': 0,
                    'total_amount': Decimal('0'),
                    'avg_confidence': Decimal('0')
                }
            
            category_breakdown[category]['count'] += 1
            category_breakdown[category]['total_amount'] += entry.attributed_amount
            category_breakdown[category]['avg_confidence'] += entry.confidence_score
        
        # Calculate averages
        for category_data in category_breakdown.values():
            if category_data['count'] > 0:
                category_data['avg_confidence'] = (category_data['avg_confidence'] / Decimal(str(category_data['count']))).quantize(Decimal('0.0001'))
        
        # Cross-year analysis
        cross_year_entries = [entry for entry in entries if entry.cross_year_attribution]
        cross_year_amount = sum(entry.attributed_amount for entry in cross_year_entries)
        
        return {
            'target_year': target_year,
            'attribution_type': attribution_type.value if attribution_type else 'all',
            'total_entries': len(entries),
            'total_attributed_amount': float(total_attributed),
            'total_gross_amount': float(total_gross),
            'allocation_efficiency': float((total_attributed / total_gross).quantize(Decimal('0.0001'))) if total_gross > 0 else 0.0,
            'category_breakdown': {
                category: {
                    'count': data['count'],
                    'total_amount': float(data['total_amount']),
                    'avg_confidence': float(data['avg_confidence'])
                }
                for category, data in category_breakdown.items()
            },
            'cross_year_analysis': {
                'cross_year_entries': len(cross_year_entries),
                'cross_year_amount': float(cross_year_amount),
                'cross_year_percentage': float((cross_year_amount / total_attributed).quantize(Decimal('0.0001'))) if total_attributed > 0 else 0.0
            },
            'performance_metrics': {
                'total_processing_time_ms': float(self._total_processing_time_ms),
                'avg_processing_time_per_entry_ms': float((self._total_processing_time_ms / Decimal(str(max(self._total_attributions_processed, 1)))).quantize(Decimal('0.001')))
            },
            'generated_timestamp': datetime.utcnow().isoformat()
        }
    
    def validate_attribution_integrity(self) -> Tuple[bool, List[str]]:
        """
        Validate integrity of all attribution entries.
        
        Returns:
            Tuple of (is_valid, list_of_issues)
        """
        all_issues = []
        
        for attribution_id, entry in self._attribution_entries.items():
            is_valid, issues = entry.verify_attribution_integrity()
            if not is_valid:
                all_issues.extend([f"Entry {attribution_id}: {issue}" for issue in issues])
        
        # Validate audit trail consistency
        if self.enable_audit_trail:
            for audit_trail in self._audit_trails:
                if not audit_trail.validation_passed:
                    all_issues.extend([f"Audit trail {audit_trail.audit_id}: {issue}" for issue in audit_trail.validation_issues])
        
        return len(all_issues) == 0, all_issues
    
    def _calculate_total_compensation_impact(
        self,
        compensation_events: List[SimulationEvent]
    ) -> Decimal:
        """Calculate total compensation impact from events."""
        total_impact = Decimal('0')
        
        for event in compensation_events:
            if hasattr(event.payload, 'annual_compensation') and event.payload.annual_compensation:
                if event.payload.event_type == 'hire':
                    total_impact += Decimal(str(event.payload.annual_compensation))
                elif event.payload.event_type == 'termination':
                    # Estimate termination cost (simplified)
                    total_impact += Decimal('75000.00')  # Placeholder
            elif hasattr(event.payload, 'new_annual_compensation') and event.payload.new_annual_compensation:
                # Promotion or merit increase
                if hasattr(event.payload, 'previous_compensation') and event.payload.previous_compensation:
                    total_impact += (Decimal(str(event.payload.new_annual_compensation)) - 
                                   Decimal(str(event.payload.previous_compensation)))
                else:
                    total_impact += Decimal(str(event.payload.new_annual_compensation))
        
        return total_impact.quantize(self._precision_context)
    
    def _calculate_allocation_weight(
        self,
        source_metrics: WorkforceMetrics,
        target_metrics: WorkforceMetrics,
        strategy: AllocationStrategy,
        year_distance: int
    ) -> Decimal:
        """Calculate allocation weight based on strategy and metrics."""
        if strategy == AllocationStrategy.PRO_RATA_TEMPORAL:
            # Time-based decay
            decay_factor = Decimal(str(max(0.1, 1.0 - (year_distance * 0.1))))
            return decay_factor.quantize(self._precision_context)
        
        elif strategy == AllocationStrategy.PRO_RATA_WORKFORCE:
            # Workforce size-based allocation
            if source_metrics.active_employees == 0:
                return Decimal('0')
            ratio = (Decimal(str(target_metrics.active_employees)) / 
                    Decimal(str(source_metrics.active_employees)))
            return min(ratio, Decimal('1.0')).quantize(self._precision_context)
        
        elif strategy == AllocationStrategy.COMPENSATION_WEIGHTED:
            # Compensation-based weighting
            if source_metrics.total_compensation_cost == 0:
                return Decimal('0')
            ratio = (target_metrics.total_compensation_cost / 
                    source_metrics.total_compensation_cost)
            return min(ratio, Decimal('1.0')).quantize(self._precision_context)
        
        elif strategy == AllocationStrategy.HYBRID_TEMPORAL_WORKFORCE:
            # Combined temporal and workforce approach
            temporal_weight = Decimal(str(max(0.1, 1.0 - (year_distance * 0.1))))
            if source_metrics.active_employees > 0:
                workforce_ratio = (Decimal(str(target_metrics.active_employees)) / 
                                 Decimal(str(source_metrics.active_employees)))
            else:
                workforce_ratio = Decimal('0')
            
            # 70% temporal, 30% workforce
            combined_weight = (temporal_weight * Decimal('0.7') + 
                             workforce_ratio * Decimal('0.3'))
            return min(combined_weight, Decimal('1.0')).quantize(self._precision_context)
        
        else:  # EVENT_DRIVEN - equal weight
            return Decimal('1.0')
    
    def _calculate_attributed_amount(
        self,
        event: SimulationEvent,
        total_impact: Decimal,
        allocation_weight: Decimal,
        strategy: AllocationStrategy
    ) -> Decimal:
        """Calculate attributed amount for specific event."""
        # Get event-specific cost
        event_cost = Decimal('0')
        
        if hasattr(event.payload, 'annual_compensation') and event.payload.annual_compensation:
            if event.payload.event_type == 'hire':
                event_cost = Decimal(str(event.payload.annual_compensation))
            elif event.payload.event_type == 'termination':
                event_cost = Decimal('75000.00')  # Placeholder
        elif hasattr(event.payload, 'new_annual_compensation') and event.payload.new_annual_compensation:
            event_cost = Decimal(str(event.payload.new_annual_compensation))
        
        # Apply allocation weight
        attributed_amount = (event_cost * allocation_weight).quantize(self._precision_context)
        
        return attributed_amount
    
    def _create_attribution_entry(
        self,
        event: SimulationEvent,
        source_year: int,
        target_year: int,
        attributed_amount: Decimal,
        allocation_weight: Decimal,
        strategy: AllocationStrategy
    ) -> CostAttributionEntry:
        """Create cost attribution entry from event data."""
        # Determine gross amount
        gross_amount = attributed_amount / allocation_weight if allocation_weight > 0 else attributed_amount
        
        # Determine attribution type based on event
        if event.payload.event_type == 'hire':
            attribution_type = CostAttributionType.COMPENSATION_BASELINE
        elif event.payload.event_type in ['promotion', 'merit']:
            attribution_type = CostAttributionType.COMPENSATION_CHANGE
        elif event.payload.event_type == 'termination':
            attribution_type = CostAttributionType.CROSS_YEAR_TRANSITION
        else:
            attribution_type = CostAttributionType.COMPENSATION_BASELINE
        
        return CostAttributionEntry(
            employee_id=event.employee_id,
            scenario_id=self.scenario_id,
            plan_design_id=self.plan_design_id,
            effective_date=event.effective_date,
            attribution_year=target_year,
            source_year=source_year,
            attribution_type=attribution_type,
            allocation_strategy=strategy,
            gross_amount=gross_amount.quantize(self._precision_context),
            attributed_amount=attributed_amount,
            allocation_percentage=allocation_weight,
            source_event_id=event.event_id,
            cost_category=f"workforce_{event.payload.event_type}",
            attribution_basis=f"Cross-year allocation using {strategy.value} strategy for {event.payload.event_type} event",
            confidence_score=Decimal('0.95')  # High confidence for direct attribution
        )
    
    def _create_audit_trail(
        self,
        source_year: int,
        operation_type: str,
        attribution_entries: List[CostAttributionEntry],
        processing_duration: Decimal
    ) -> AttributionAuditTrail:
        """Create audit trail for attribution operation."""
        total_gross = sum(entry.gross_amount for entry in attribution_entries)
        total_attributed = sum(entry.attributed_amount for entry in attribution_entries)
        
        return AttributionAuditTrail(
            scenario_id=self.scenario_id,
            attribution_year=source_year,
            operation_type=operation_type,
            attribution_entries=attribution_entries.copy(),
            total_gross_amount=total_gross,
            total_attributed_amount=total_attributed,
            processing_duration_ms=processing_duration,
            records_processed=len(attribution_entries),
            validation_passed=True,
            validation_issues=[]
        )


# Factory functions for easier instantiation
def create_cost_attributor(
    scenario_id: str,
    plan_design_id: str,
    allocation_strategy: AllocationStrategy = AllocationStrategy.PRO_RATA_TEMPORAL
) -> CrossYearCostAttributor:
    """Create configured cross-year cost attributor."""
    return CrossYearCostAttributor(
        scenario_id=scenario_id,
        plan_design_id=plan_design_id,
        default_allocation_strategy=allocation_strategy,
        enable_audit_trail=True
    )


def create_allocation_context(
    source_year: int,
    target_years: List[int],
    source_workforce_metrics: WorkforceMetrics,
    target_workforce_metrics: Dict[int, WorkforceMetrics],
    source_events: List[SimulationEvent],
    allocation_strategy: AllocationStrategy = AllocationStrategy.PRO_RATA_TEMPORAL
) -> CrossYearAllocationContext:
    """Create cross-year allocation context."""
    return CrossYearAllocationContext(
        source_year=source_year,
        target_years=target_years,
        allocation_strategy=allocation_strategy,
        source_workforce_metrics=source_workforce_metrics,
        source_events=source_events,
        target_workforce_metrics=target_workforce_metrics
    )