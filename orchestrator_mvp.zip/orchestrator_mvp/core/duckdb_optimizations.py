"""
DuckDB-specific performance optimizations for the orchestrator_dbt system.

This module contains DuckDB-specific tuning parameters and optimization strategies
that can significantly improve query performance and data loading speed.
"""

import os
from typing import Dict, Any, Optional
from .database_manager import get_connection


def apply_duckdb_optimizations(connection=None) -> Dict[str, Any]:
    """
    Apply DuckDB-specific performance optimizations for analytical workloads.
    
    Args:
        connection: Optional DuckDB connection. If None, creates a new one.
    
    Returns:
        Dictionary with optimization results and performance settings applied
    """
    close_connection = False
    if connection is None:
        connection = get_connection()
        close_connection = True
    
    optimization_results = {
        "memory_optimizations": {},
        "query_optimizations": {},
        "io_optimizations": {},
        "errors": []
    }
    
    try:
        print("🔧 Applying DuckDB performance optimizations...")
        
        # Memory optimizations
        memory_settings = {
            # Increase memory limit for better performance (use 75% of available RAM)
            "memory_limit": "75%",
            # Increase buffer pool size for better caching
            "max_memory": "75%",
            # Optimize for analytical workloads
            "temp_directory": "/tmp/duckdb_temp",
        }
        
        for setting, value in memory_settings.items():
            try:
                if setting == "temp_directory":
                    # Ensure temp directory exists
                    os.makedirs(value, exist_ok=True)
                
                connection.execute(f"SET {setting} = '{value}'")
                optimization_results["memory_optimizations"][setting] = value
                print(f"  ✅ Set {setting} = {value}")
            except Exception as e:
                optimization_results["errors"].append(f"Memory setting {setting}: {str(e)}")
                print(f"  ⚠️ Failed to set {setting}: {str(e)}")
        
        # Query optimization settings
        query_settings = {
            # Enable parallel query execution
            "threads": "4",
            # Optimize join order automatically
            "enable_optimizer": "true",
            # Use columnar storage advantages
            "enable_object_cache": "true",
            # Optimize for batch processing
            "preserve_insertion_order": "false",
        }
        
        for setting, value in query_settings.items():
            try:
                connection.execute(f"SET {setting} = {value}")
                optimization_results["query_optimizations"][setting] = value
                print(f"  ✅ Set {setting} = {value}")
            except Exception as e:
                optimization_results["errors"].append(f"Query setting {setting}: {str(e)}")
                print(f"  ⚠️ Failed to set {setting}: {str(e)}")
        
        # I/O optimization settings  
        io_settings = {
            # Optimize CSV reading for seed files
            "enable_progress_bar": "false",  # Reduce I/O overhead
            "checkpoint_threshold": "16MB",   # Optimize checkpointing
        }
        
        for setting, value in io_settings.items():
            try:
                connection.execute(f"SET {setting} = {value}")
                optimization_results["io_optimizations"][setting] = value
                print(f"  ✅ Set {setting} = {value}")
            except Exception as e:
                optimization_results["errors"].append(f"I/O setting {setting}: {str(e)}")
                print(f"  ⚠️ Failed to set {setting}: {str(e)}")
        
        # Additional analytical workload optimizations
        try:
            # Optimize for aggregation-heavy workloads
            connection.execute("SET enable_http_metadata_cache = true")
            optimization_results["query_optimizations"]["http_metadata_cache"] = "true"
            print("  ✅ Enabled HTTP metadata cache for better performance")
        except Exception as e:
            optimization_results["errors"].append(f"HTTP cache setting: {str(e)}")
        
        print(f"✅ Applied {len(optimization_results['memory_optimizations']) + len(optimization_results['query_optimizations']) + len(optimization_results['io_optimizations'])} DuckDB optimizations")
        
        if optimization_results["errors"]:
            print(f"⚠️ {len(optimization_results['errors'])} optimization settings failed")
        
    except Exception as e:
        optimization_results["errors"].append(f"General optimization error: {str(e)}")
        print(f"❌ DuckDB optimization failed: {str(e)}")
    
    finally:
        if close_connection:
            connection.close()
    
    return optimization_results


def create_performance_indexes(connection=None) -> Dict[str, Any]:
    """
    Create performance-oriented indexes for frequently queried columns.
    
    Args:
        connection: Optional DuckDB connection. If None, creates a new one.
    
    Returns:
        Dictionary with index creation results
    """
    close_connection = False
    if connection is None:
        connection = get_connection()
        close_connection = True
    
    index_results = {
        "indexes_created": [],
        "errors": []
    }
    
    try:
        print("📊 Creating performance indexes...")
        
        # Indexes for frequently queried columns in simulation tables
        index_definitions = [
            # Workforce snapshot indexes
            ("idx_workforce_sim_year", "fct_workforce_snapshot", "simulation_year"),
            ("idx_workforce_emp_status", "fct_workforce_snapshot", "employment_status"),
            ("idx_workforce_emp_id", "fct_workforce_snapshot", "employee_id"),
            
            # Yearly events indexes  
            ("idx_events_sim_year", "fct_yearly_events", "simulation_year"),
            ("idx_events_type", "fct_yearly_events", "event_type"),
            ("idx_events_emp_id", "fct_yearly_events", "employee_id"),
            ("idx_events_date", "fct_yearly_events", "event_date"),
            
            # Baseline workforce indexes
            ("idx_baseline_emp_status", "int_baseline_workforce", "employment_status"),
            ("idx_baseline_job_level", "int_baseline_workforce", "job_level"),
        ]
        
        for index_name, table_name, column_name in index_definitions:
            try:
                # Check if table exists first
                table_check = connection.execute(f"""
                    SELECT COUNT(*) FROM information_schema.tables 
                    WHERE table_name = '{table_name}'
                """).fetchone()
                
                if table_check and table_check[0] > 0:
                    # Create index if table exists
                    connection.execute(f"CREATE INDEX IF NOT EXISTS {index_name} ON {table_name} ({column_name})")
                    index_results["indexes_created"].append(f"{index_name} on {table_name}({column_name})")
                    print(f"  ✅ Created index {index_name} on {table_name}({column_name})")
                else:
                    print(f"  ⏭️ Skipped {index_name} - table {table_name} does not exist yet")
                    
            except Exception as e:
                index_results["errors"].append(f"Index {index_name}: {str(e)}")
                print(f"  ⚠️ Failed to create index {index_name}: {str(e)}")
        
        print(f"✅ Created {len(index_results['indexes_created'])} performance indexes")
        
    except Exception as e:
        index_results["errors"].append(f"General index creation error: {str(e)}")
        print(f"❌ Index creation failed: {str(e)}")
    
    finally:
        if close_connection:
            connection.close()
    
    return index_results


def analyze_query_performance(query: str, connection=None) -> Dict[str, Any]:
    """
    Analyze query performance and provide optimization suggestions.
    
    Args:
        query: SQL query to analyze
        connection: Optional DuckDB connection
    
    Returns:
        Dictionary with performance analysis results
    """
    close_connection = False
    if connection is None:
        connection = get_connection()
        close_connection = True
    
    analysis_results = {
        "query": query,
        "execution_plan": None,
        "estimated_cost": None,
        "suggestions": [],
        "errors": []
    }
    
    try:
        # Get query execution plan
        explain_query = f"EXPLAIN {query}"
        plan_result = connection.execute(explain_query).fetchall()
        analysis_results["execution_plan"] = [row[0] for row in plan_result]
        
        # Analyze plan for optimization opportunities
        plan_text = " ".join(analysis_results["execution_plan"]).lower()
        
        # Check for common performance issues
        if "seq_scan" in plan_text:
            analysis_results["suggestions"].append("Consider adding indexes to avoid sequential scans")
        
        if "sort" in plan_text and "merge" not in plan_text:
            analysis_results["suggestions"].append("Large sorts detected - consider using ORDER BY with LIMIT")
        
        if "hash_join" in plan_text:
            analysis_results["suggestions"].append("Hash joins detected - ensure join columns are indexed")
        
        if len(analysis_results["execution_plan"]) > 20:
            analysis_results["suggestions"].append("Complex query plan - consider breaking into smaller parts")
        
        print(f"📈 Query analysis completed - {len(analysis_results['suggestions'])} optimization suggestions")
        
    except Exception as e:
        analysis_results["errors"].append(f"Query analysis error: {str(e)}")
        print(f"❌ Query analysis failed: {str(e)}")
    
    finally:
        if close_connection:
            connection.close()
    
    return analysis_results


def optimize_dbt_execution_environment() -> Dict[str, Any]:
    """
    Optimize the environment for dbt execution with DuckDB.
    
    Returns:
        Dictionary with environment optimization results
    """
    optimization_results = {
        "environment_variables": {},
        "duckdb_settings": {},
        "recommendations": []
    }
    
    # Set optimal environment variables for dbt + DuckDB
    optimal_env_vars = {
        "DBT_PROFILES_DIR": os.path.expanduser("~/.dbt"),
        "DUCKDB_MEMORY_LIMIT": "75%",
        "DUCKDB_THREADS": "4",
        "PYTHONHASHSEED": "0",  # For reproducible results
    }
    
    for var, value in optimal_env_vars.items():
        try:
            os.environ[var] = value
            optimization_results["environment_variables"][var] = value
            print(f"  ✅ Set {var} = {value}")
        except Exception as e:
            print(f"  ⚠️ Failed to set {var}: {str(e)}")
    
    # Add performance recommendations
    optimization_results["recommendations"] = [
        "Use batch operations instead of individual dbt commands",
        "Group independent models for parallel execution", 
        "Apply DuckDB optimizations before running large queries",
        "Create indexes on frequently queried columns",
        "Use appropriate materialization strategies (table vs view)",
        "Consider using DuckDB's columnar advantages for aggregations"
    ]
    
    print("✅ Environment optimization completed")
    return optimization_results