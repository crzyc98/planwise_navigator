"""
State validation module for workforce continuity and integrity verification.

This module provides comprehensive validation capabilities for the multi-year coordination system:
- Workforce continuity validation across simulation years
- Event sequence integrity verification
- Cost model accuracy validation
- Cross-year dependency verification
- Regulatory compliance validation

Integration with state management components:
- Works with SimulationState for current state validation
- Integrates with EventSourcingCheckpoint for historical validation
- Supports WorkforceStateManager for cross-year validation
- Provides audit trail verification for regulatory compliance
"""

from __future__ import annotations
import logging
from typing import Dict, Any, Optional, List, Set, Tuple, Union
from datetime import datetime, date
from decimal import Decimal
from dataclasses import dataclass
from enum import Enum

from pydantic import BaseModel, Field, ConfigDict
from pydantic.types import NonNegativeInt, PositiveInt

# Import state management components
from .state_management import (
    SimulationState, EventSourcingCheckpoint, WorkforceStateManager,
    WorkforceMetrics, EventSummary, StateStatus
)

# Import existing event model
from config.events import SimulationEvent

logger = logging.getLogger(__name__)


class ValidationSeverity(str, Enum):
    """Severity levels for validation issues."""
    CRITICAL = "critical"      # Simulation cannot proceed
    ERROR = "error"           # Data integrity compromised
    WARNING = "warning"       # Potential issue, but can proceed
    INFO = "info"            # Informational notice


class ValidationCategory(str, Enum):
    """Categories of validation checks."""
    WORKFORCE_CONTINUITY = "workforce_continuity"
    EVENT_INTEGRITY = "event_integrity"
    COST_ACCURACY = "cost_accuracy"
    DEPENDENCY_SATISFACTION = "dependency_satisfaction"
    REGULATORY_COMPLIANCE = "regulatory_compliance"
    DATA_QUALITY = "data_quality"
    CONFIGURATION_CONSISTENCY = "configuration_consistency"


class ValidationIssue(BaseModel):
    """Individual validation issue with detailed context."""
    
    model_config = ConfigDict(
        frozen=True,
        use_enum_values=True
    )
    
    # Issue identification
    issue_id: str = Field(..., min_length=1)
    category: ValidationCategory
    severity: ValidationSeverity
    
    # Issue details
    title: str = Field(..., min_length=1)
    description: str = Field(..., min_length=1)
    recommendation: Optional[str] = None
    
    # Context information
    simulation_year: Optional[int] = None
    affected_employees: Optional[List[str]] = None
    affected_events: Optional[List[str]] = None
    
    # Quantitative impact
    employee_count_impact: Optional[int] = None
    cost_impact: Optional[Decimal] = None
    
    # Metadata
    detected_at: datetime = Field(default_factory=datetime.utcnow)
    validation_rule: str = Field(..., min_length=1)
    
    @property
    def is_blocking(self) -> bool:
        """Check if this issue blocks simulation progress."""
        return self.severity in [ValidationSeverity.CRITICAL, ValidationSeverity.ERROR]


class ValidationResult(BaseModel):
    """Comprehensive validation result with categorized issues."""
    
    model_config = ConfigDict(
        frozen=True,
        use_enum_values=True
    )
    
    # Overall result
    is_valid: bool
    validation_timestamp: datetime = Field(default_factory=datetime.utcnow)
    
    # Issue tracking
    issues: List[ValidationIssue] = Field(default_factory=list)
    
    # Summary statistics
    critical_count: NonNegativeInt = 0
    error_count: NonNegativeInt = 0
    warning_count: NonNegativeInt = 0
    info_count: NonNegativeInt = 0
    
    # Validation context
    validation_scope: str = Field(..., min_length=1)
    simulation_years: List[int] = Field(default_factory=list)
    
    @property
    def blocking_issue_count(self) -> int:
        """Count of issues that block simulation progress."""
        return self.critical_count + self.error_count
    
    @property
    def total_issue_count(self) -> int:
        """Total count of all issues."""
        return self.critical_count + self.error_count + self.warning_count + self.info_count
    
    def get_issues_by_category(self, category: ValidationCategory) -> List[ValidationIssue]:
        """Get all issues for a specific category."""
        return [issue for issue in self.issues if issue.category == category]
    
    def get_issues_by_severity(self, severity: ValidationSeverity) -> List[ValidationIssue]:
        """Get all issues for a specific severity level."""
        return [issue for issue in self.issues if issue.severity == severity]


@dataclass
class ValidationContext:
    """Context for validation operations."""
    
    # Validation scope
    simulation_years: List[int]
    scenario_id: str
    plan_design_id: str
    
    # State references
    state_manager: WorkforceStateManager
    configuration: Dict[str, Any]
    
    # Validation options
    strict_mode: bool = True
    include_warnings: bool = True
    validate_cross_year_dependencies: bool = True
    validate_regulatory_compliance: bool = True
    
    # Performance options
    parallel_validation: bool = False
    max_validation_workers: int = 4


class WorkforceContinuityValidator:
    """Validates workforce continuity across simulation years."""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        self.logger = logger or logging.getLogger(__name__)
    
    def validate_year_to_year_continuity(
        self,
        from_state: SimulationState,
        to_state: SimulationState,
        events_processed: List[SimulationEvent]
    ) -> List[ValidationIssue]:
        """Validate continuity between consecutive simulation years."""
        issues = []
        
        # Validate workforce count consistency
        issues.extend(self._validate_workforce_count_continuity(from_state, to_state, events_processed))
        
        # Validate cost continuity
        issues.extend(self._validate_cost_continuity(from_state, to_state, events_processed))
        
        # Validate demographic continuity
        issues.extend(self._validate_demographic_continuity(from_state, to_state))
        
        return issues
    
    def _validate_workforce_count_continuity(
        self,
        from_state: SimulationState,
        to_state: SimulationState,
        events_processed: List[SimulationEvent]
    ) -> List[ValidationIssue]:
        """Validate workforce count changes match processed events."""
        issues = []
        
        from_count = from_state.workforce_metrics.active_employees
        to_count = to_state.workforce_metrics.active_employees
        actual_change = to_count - from_count
        
        # Calculate expected change from events
        hire_count = sum(1 for e in events_processed if e.payload.event_type == 'hire')
        termination_count = sum(1 for e in events_processed if e.payload.event_type == 'termination')
        expected_change = hire_count - termination_count
        
        if actual_change != expected_change:
            issues.append(ValidationIssue(
                issue_id=f"workforce_count_mismatch_{from_state.simulation_year}_{to_state.simulation_year}",
                category=ValidationCategory.WORKFORCE_CONTINUITY,
                severity=ValidationSeverity.ERROR,
                title="Workforce Count Mismatch",
                description=f"Workforce count change ({actual_change}) does not match expected change from events ({expected_change})",
                recommendation="Review event processing logic and workforce snapshot generation",
                simulation_year=to_state.simulation_year,
                employee_count_impact=abs(actual_change - expected_change),
                validation_rule="workforce_count_continuity_check"
            ))
        
        # Validate non-negative workforce count
        if to_count < 0:
            issues.append(ValidationIssue(
                issue_id=f"negative_workforce_count_{to_state.simulation_year}",
                category=ValidationCategory.WORKFORCE_CONTINUITY,
                severity=ValidationSeverity.CRITICAL,
                title="Negative Workforce Count",
                description=f"Active workforce count cannot be negative: {to_count}",
                recommendation="Review termination event logic for over-processing",
                simulation_year=to_state.simulation_year,
                employee_count_impact=abs(to_count),
                validation_rule="non_negative_workforce_check"
            ))
        
        return issues
    
    def _validate_cost_continuity(
        self,
        from_state: SimulationState,
        to_state: SimulationState,
        events_processed: List[SimulationEvent]
    ) -> List[ValidationIssue]:
        """Validate total compensation cost continuity."""
        issues = []
        
        from_cost = from_state.workforce_metrics.total_compensation_cost
        to_cost = to_state.workforce_metrics.total_compensation_cost
        
        # Calculate expected cost change from events
        expected_cost_change = Decimal('0')
        for event in events_processed:
            if hasattr(event.payload, 'compensation_amount') and event.payload.compensation_amount:
                if event.payload.event_type == 'hire':
                    expected_cost_change += Decimal(str(event.payload.compensation_amount))
                elif event.payload.event_type == 'termination':
                    expected_cost_change -= Decimal(str(event.payload.compensation_amount))
                elif event.payload.event_type in ['promotion', 'merit']:
                    if hasattr(event.payload, 'previous_compensation') and event.payload.previous_compensation:
                        expected_cost_change += (Decimal(str(event.payload.compensation_amount)) - 
                                               Decimal(str(event.payload.previous_compensation)))
        
        actual_cost_change = to_cost - from_cost
        cost_variance = abs(actual_cost_change - expected_cost_change)
        
        # Allow for small rounding differences (up to $1000)
        tolerance = Decimal('1000.00')
        if cost_variance > tolerance:
            issues.append(ValidationIssue(
                issue_id=f"cost_continuity_variance_{from_state.simulation_year}_{to_state.simulation_year}",
                category=ValidationCategory.COST_ACCURACY,
                severity=ValidationSeverity.WARNING,
                title="Cost Continuity Variance",
                description=f"Total cost change variance exceeds tolerance: ${cost_variance} (tolerance: ${tolerance})",
                recommendation="Review compensation calculation logic for precision issues",
                simulation_year=to_state.simulation_year,
                cost_impact=cost_variance,
                validation_rule="cost_continuity_tolerance_check"
            ))
        
        # Validate reasonable cost per employee
        if to_state.workforce_metrics.active_employees > 0:
            avg_compensation = to_cost / Decimal(str(to_state.workforce_metrics.active_employees))
            if avg_compensation < Decimal('20000') or avg_compensation > Decimal('1000000'):
                issues.append(ValidationIssue(
                    issue_id=f"unreasonable_avg_compensation_{to_state.simulation_year}",
                    category=ValidationCategory.COST_ACCURACY,
                    severity=ValidationSeverity.WARNING,
                    title="Unreasonable Average Compensation",
                    description=f"Average compensation appears unreasonable: ${avg_compensation}",
                    recommendation="Review compensation data and calculation logic",
                    simulation_year=to_state.simulation_year,
                    cost_impact=avg_compensation,
                    validation_rule="reasonable_compensation_range_check"
                ))
        
        return issues
    
    def _validate_demographic_continuity(
        self,
        from_state: SimulationState,
        to_state: SimulationState
    ) -> List[ValidationIssue]:
        """Validate demographic distribution continuity."""
        issues = []
        
        # Validate level distribution changes are reasonable
        from_levels = from_state.workforce_metrics.level_distribution
        to_levels = to_state.workforce_metrics.level_distribution
        
        for level_id in set(from_levels.keys()) | set(to_levels.keys()):
            from_count = from_levels.get(level_id, 0)
            to_count = to_levels.get(level_id, 0)
            change = to_count - from_count
            
            # Check for dramatic level distribution changes (>50% change)
            if from_count > 0 and abs(change) / from_count > 0.5:
                issues.append(ValidationIssue(
                    issue_id=f"level_distribution_change_{level_id}_{from_state.simulation_year}_{to_state.simulation_year}",
                    category=ValidationCategory.WORKFORCE_CONTINUITY,
                    severity=ValidationSeverity.WARNING,
                    title="Significant Level Distribution Change",
                    description=f"Level {level_id} count changed by {change} ({change/from_count:.1%})",
                    recommendation="Review hiring and promotion patterns for this level",
                    simulation_year=to_state.simulation_year,
                    employee_count_impact=abs(change),
                    validation_rule="level_distribution_stability_check"
                ))
        
        return issues


class EventIntegrityValidator:
    """Validates event sequence integrity and business rule compliance."""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        self.logger = logger or logging.getLogger(__name__)
    
    def validate_event_sequence(
        self,
        events: List[SimulationEvent],
        simulation_year: int
    ) -> List[ValidationIssue]:
        """Validate event sequence integrity and business rules."""
        issues = []
        
        # Validate event temporal consistency
        issues.extend(self._validate_event_dates(events, simulation_year))
        
        # Validate employee event sequences
        issues.extend(self._validate_employee_event_sequences(events))
        
        # Validate compensation event chains
        issues.extend(self._validate_compensation_event_chains(events))
        
        # Validate event business rules
        issues.extend(self._validate_business_rules(events))
        
        return issues
    
    def _validate_event_dates(
        self,
        events: List[SimulationEvent],
        simulation_year: int
    ) -> List[ValidationIssue]:
        """Validate event dates are within simulation year."""
        issues = []
        
        year_start = date(simulation_year, 1, 1)
        year_end = date(simulation_year, 12, 31)
        
        for event in events:
            if not (year_start <= event.effective_date <= year_end):
                issues.append(ValidationIssue(
                    issue_id=f"event_date_out_of_range_{event.event_id}",
                    category=ValidationCategory.EVENT_INTEGRITY,
                    severity=ValidationSeverity.ERROR,
                    title="Event Date Out of Range",
                    description=f"Event {event.event_id} date {event.effective_date} is outside simulation year {simulation_year}",
                    recommendation="Review event generation date logic",
                    simulation_year=simulation_year,
                    affected_events=[str(event.event_id)],
                    validation_rule="event_date_range_check"
                ))
        
        return issues
    
    def _validate_employee_event_sequences(
        self,
        events: List[SimulationEvent]
    ) -> List[ValidationIssue]:
        """Validate logical sequence of events for each employee."""
        issues = []
        
        # Group events by employee
        employee_events = {}
        for event in events:
            emp_id = event.employee_id
            if emp_id not in employee_events:
                employee_events[emp_id] = []
            employee_events[emp_id].append(event)
        
        # Validate each employee's event sequence
        for emp_id, emp_events in employee_events.items():
            # Sort events by date
            emp_events.sort(key=lambda e: e.effective_date)
            
            # Check for multiple hires
            hire_events = [e for e in emp_events if e.payload.event_type == 'hire']
            if len(hire_events) > 1:
                issues.append(ValidationIssue(
                    issue_id=f"multiple_hires_{emp_id}",
                    category=ValidationCategory.EVENT_INTEGRITY,
                    severity=ValidationSeverity.ERROR,  
                    title="Multiple Hire Events",
                    description=f"Employee {emp_id} has {len(hire_events)} hire events",
                    recommendation="Review employee ID generation and hire event logic",
                    affected_employees=[emp_id],
                    affected_events=[str(e.event_id) for e in hire_events],
                    validation_rule="single_hire_per_employee_check"
                ))
            
            # Check for events after termination
            termination_events = [e for e in emp_events if e.payload.event_type == 'termination']
            if termination_events:
                termination_date = min(e.effective_date for e in termination_events)
                post_termination_events = [e for e in emp_events 
                                         if e.effective_date > termination_date and e.payload.event_type != 'termination']
                
                if post_termination_events:
                    issues.append(ValidationIssue(
                        issue_id=f"events_after_termination_{emp_id}",
                        category=ValidationCategory.EVENT_INTEGRITY,
                        severity=ValidationSeverity.ERROR,
                        title="Events After Termination",
                        description=f"Employee {emp_id} has {len(post_termination_events)} events after termination",
                        recommendation="Review event sequence generation and termination handling",
                        affected_employees=[emp_id],
                        affected_events=[str(e.event_id) for e in post_termination_events],
                        validation_rule="no_events_after_termination_check"
                    ))
        
        return issues
    
    def _validate_compensation_event_chains(
        self,
        events: List[SimulationEvent]
    ) -> List[ValidationIssue]:
        """Validate compensation event chains for accuracy."""
        issues = []
        
        # Group compensation events by employee
        employee_comp_events = {}
        for event in events:
            if event.payload.event_type in ['hire', 'promotion', 'merit']:
                emp_id = event.employee_id
                if emp_id not in employee_comp_events:
                    employee_comp_events[emp_id] = []
                employee_comp_events[emp_id].append(event)
        
        # Validate compensation chains
        for emp_id, comp_events in employee_comp_events.items():
            comp_events.sort(key=lambda e: e.effective_date)
            
            for i in range(1, len(comp_events)):
                current_event = comp_events[i]
                previous_event = comp_events[i-1]
                
                # Check compensation continuity
                if (hasattr(current_event.payload, 'previous_compensation') and 
                    current_event.payload.previous_compensation and
                    hasattr(previous_event.payload, 'compensation_amount') and
                    previous_event.payload.compensation_amount):
                    
                    expected_prev = Decimal(str(previous_event.payload.compensation_amount))
                    actual_prev = Decimal(str(current_event.payload.previous_compensation))
                    
                    if abs(expected_prev - actual_prev) > Decimal('0.01'):
                        issues.append(ValidationIssue(
                            issue_id=f"compensation_chain_break_{emp_id}_{current_event.event_id}",
                            category=ValidationCategory.COST_ACCURACY,
                            severity=ValidationSeverity.WARNING,
                            title="Compensation Chain Discontinuity",
                            description=f"Employee {emp_id}: Expected previous compensation ${expected_prev}, got ${actual_prev}",
                            recommendation="Review compensation event chain generation",
                            affected_employees=[emp_id],
                            affected_events=[str(current_event.event_id)],
                            cost_impact=abs(expected_prev - actual_prev),
                            validation_rule="compensation_chain_continuity_check"
                        ))
        
        return issues
    
    def _validate_business_rules(
        self,
        events: List[SimulationEvent]
    ) -> List[ValidationIssue]:
        """Validate business rule compliance."""
        issues = []
        
        # Validate promotion rules
        for event in events:
            if event.payload.event_type == 'promotion':
                # Check promotion level increment
                if hasattr(event.payload, 'level_id') and hasattr(event.payload, 'previous_level_id'):
                    if hasattr(event.payload, 'previous_level_id'):  # If available in payload
                        level_change = event.payload.level_id - event.payload.previous_level_id
                        if level_change != 1:
                            issues.append(ValidationIssue(
                                issue_id=f"invalid_promotion_level_change_{event.event_id}",
                                category=ValidationCategory.EVENT_INTEGRITY,
                                severity=ValidationSeverity.WARNING,
                                title="Invalid Promotion Level Change",
                                description=f"Promotion level change is {level_change}, expected 1",
                                recommendation="Review promotion level increment logic",
                                affected_events=[str(event.event_id)],
                                validation_rule="single_level_promotion_check"
                            ))
        
        return issues


class StateValidator:
    """Comprehensive state validation orchestrator."""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        self.logger = logger or logging.getLogger(__name__)
        self.workforce_validator = WorkforceContinuityValidator(logger)
        self.event_validator = EventIntegrityValidator(logger)
    
    def validate_simulation_state(
        self,
        context: ValidationContext
    ) -> ValidationResult:
        """
        Perform comprehensive validation of simulation state.
        
        Args:
            context: Validation context with state references and options
            
        Returns:
            ValidationResult with all identified issues
        """
        self.logger.info(f"Starting comprehensive state validation for years {context.simulation_years}")
        
        all_issues = []
        
        # Validate individual year states
        for year in context.simulation_years:
            state = context.state_manager.get_state(year)
            if state:
                year_issues = self._validate_individual_year_state(state, context)
                all_issues.extend(year_issues)
        
        # Validate cross-year continuity
        if context.validate_cross_year_dependencies and len(context.simulation_years) > 1:
            continuity_issues = self._validate_cross_year_continuity(context)
            all_issues.extend(continuity_issues)
        
        # Validate regulatory compliance
        if context.validate_regulatory_compliance:
            compliance_issues = self._validate_regulatory_compliance(context)
            all_issues.extend(compliance_issues)
        
        # Count issues by severity
        critical_count = sum(1 for issue in all_issues if issue.severity == ValidationSeverity.CRITICAL)
        error_count = sum(1 for issue in all_issues if issue.severity == ValidationSeverity.ERROR)
        warning_count = sum(1 for issue in all_issues if issue.severity == ValidationSeverity.WARNING)
        info_count = sum(1 for issue in all_issues if issue.severity == ValidationSeverity.INFO)
        
        # Determine overall validation result
        is_valid = critical_count == 0 and (not context.strict_mode or error_count == 0)
        
        result = ValidationResult(
            is_valid=is_valid,
            issues=all_issues,
            critical_count=critical_count,
            error_count=error_count,
            warning_count=warning_count,
            info_count=info_count,
            validation_scope=f"comprehensive_validation_{len(context.simulation_years)}_years",
            simulation_years=context.simulation_years.copy()
        )
        
        self.logger.info(f"Validation completed: {result.total_issue_count} issues found "
                        f"({critical_count} critical, {error_count} errors, {warning_count} warnings)")
        
        return result
    
    def _validate_individual_year_state(
        self,
        state: SimulationState,
        context: ValidationContext
    ) -> List[ValidationIssue]:
        """Validate individual year state integrity."""
        issues = []
        
        # Validate state status
        if state.status == StateStatus.FAILED:
            issues.append(ValidationIssue(
                issue_id=f"failed_state_{state.simulation_year}",
                category=ValidationCategory.DATA_QUALITY,
                severity=ValidationSeverity.CRITICAL,
                title="Failed State Detected",
                description=f"Year {state.simulation_year} is in failed status",
                recommendation="Review and resolve state failure before proceeding",
                simulation_year=state.simulation_year,
                validation_rule="state_status_check"
            ))
        
        # Validate workforce metrics
        metrics = state.workforce_metrics
        if metrics.active_employees < 0:
            issues.append(ValidationIssue(
                issue_id=f"negative_active_employees_{state.simulation_year}",
                category=ValidationCategory.WORKFORCE_CONTINUITY,
                severity=ValidationSeverity.CRITICAL,
                title="Negative Active Employee Count",
                description=f"Active employees cannot be negative: {metrics.active_employees}",
                recommendation="Review workforce calculation logic",
                simulation_year=state.simulation_year,
                employee_count_impact=abs(metrics.active_employees),
                validation_rule="non_negative_workforce_check"
            ))
        
        if metrics.total_compensation_cost < 0:
            issues.append(ValidationIssue(
                issue_id=f"negative_total_cost_{state.simulation_year}",
                category=ValidationCategory.COST_ACCURACY,
                severity=ValidationSeverity.ERROR,
                title="Negative Total Compensation Cost",
                description=f"Total compensation cost cannot be negative: ${metrics.total_compensation_cost}",
                recommendation="Review compensation calculation logic",
                simulation_year=state.simulation_year,
                cost_impact=abs(metrics.total_compensation_cost),
                validation_rule="non_negative_cost_check"
            ))
        
        return issues
    
    def _validate_cross_year_continuity(
        self,
        context: ValidationContext
    ) -> List[ValidationIssue]:
        """Validate continuity across simulation years."""
        issues = []
        sorted_years = sorted(context.simulation_years)
        
        for i in range(1, len(sorted_years)):
            from_year = sorted_years[i-1]
            to_year = sorted_years[i]
            
            from_state = context.state_manager.get_state(from_year)
            to_state = context.state_manager.get_state(to_year)
            
            if from_state and to_state:
                # Use state manager's built-in continuity validation
                is_valid, continuity_issues = context.state_manager.validate_workforce_continuity(from_year, to_year)
                
                for issue_desc in continuity_issues:
                    issues.append(ValidationIssue(
                        issue_id=f"continuity_issue_{from_year}_{to_year}",
                        category=ValidationCategory.WORKFORCE_CONTINUITY,
                        severity=ValidationSeverity.ERROR,
                        title="Workforce Continuity Issue",
                        description=issue_desc,
                        recommendation="Review state transition logic and event processing",
                        simulation_year=to_year,
                        validation_rule="cross_year_continuity_check"
                    ))
        
        return issues
    
    def _validate_regulatory_compliance(
        self,
        context: ValidationContext
    ) -> List[ValidationIssue]:
        """Validate regulatory compliance requirements."""
        issues = []
        
        # Validate audit trail completeness
        for year in context.simulation_years:
            state = context.state_manager.get_state(year)
            if state and state.event_summary.total_events_processed == 0:
                issues.append(ValidationIssue(
                    issue_id=f"missing_audit_trail_{year}",
                    category=ValidationCategory.REGULATORY_COMPLIANCE,
                    severity=ValidationSeverity.WARNING,
                    title="Missing Event Audit Trail",
                    description=f"Year {year} has no recorded events for audit trail",
                    recommendation="Ensure all workforce changes are captured as events",
                    simulation_year=year,
                    validation_rule="audit_trail_completeness_check"
                ))
        
        # Additional regulatory compliance checks can be added here
        # e.g., compensation limits, eligibility rules, etc.
        
        return issues


# Factory functions for easier usage
def create_validation_context(
    state_manager: WorkforceStateManager,
    simulation_years: List[int],
    scenario_id: str,
    plan_design_id: str,
    configuration: Dict[str, Any],
    strict_mode: bool = True
) -> ValidationContext:
    """Create validation context with standard configuration."""
    return ValidationContext(
        simulation_years=simulation_years,
        scenario_id=scenario_id,
        plan_design_id=plan_design_id,
        state_manager=state_manager,
        configuration=configuration,
        strict_mode=strict_mode,
        include_warnings=True,
        validate_cross_year_dependencies=True,
        validate_regulatory_compliance=True
    )


def validate_simulation_comprehensive(
    state_manager: WorkforceStateManager,
    simulation_years: List[int],
    scenario_id: str,
    plan_design_id: str,
    configuration: Dict[str, Any],
    strict_mode: bool = True
) -> ValidationResult:
    """Perform comprehensive validation with standard configuration."""
    context = create_validation_context(
        state_manager=state_manager,
        simulation_years=simulation_years,
        scenario_id=scenario_id,
        plan_design_id=plan_design_id,
        configuration=configuration,
        strict_mode=strict_mode
    )
    
    validator = StateValidator()
    return validator.validate_simulation_state(context)