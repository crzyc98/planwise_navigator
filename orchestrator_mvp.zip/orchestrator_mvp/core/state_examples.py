"""
Comprehensive examples demonstrating the state management system.

This module provides practical examples of how to use the state management
components for various workforce simulation scenarios:

1. Basic state management setup and usage
2. Multi-year simulation with checkpointing
3. Resume from checkpoint scenarios
4. State validation and error handling
5. Integration with existing orchestrator
6. Custom validation rules
7. Performance optimization scenarios

These examples serve as both documentation and integration tests for the
state management system.
"""

from __future__ import annotations
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime, date
from decimal import Decimal
from pathlib import Path
import tempfile

# Import state management components
from .state_management import (
    SimulationState, EventSourcingCheckpoint, WorkforceStateManager,
    WorkforceMetrics, EventSummary, StateStatus, CheckpointType,
    StatePersistence, StateTransitionContext,
    create_initial_workforce_metrics, create_state_manager
)

from .state_validation import (
    StateValidator, ValidationContext, ValidationResult, ValidationSeverity,
    create_validation_context, validate_simulation_comprehensive
)

from .state_integration import (
    EnhancedMultiYearOrchestrator, create_enhanced_orchestrator,
    validate_existing_simulation_results
)

# Import existing event model for examples
from config.events import (
    SimulationEvent, WorkforceEventFactory, DCPlanEventFactory,
    HirePayload, TerminationPayload
)

logger = logging.getLogger(__name__)


def example_basic_state_management():
    """
    Example 1: Basic state management setup and usage.
    
    Demonstrates:
    - Creating initial workforce metrics
    - Initializing state manager
    - Creating and transitioning states
    - Basic validation
    """
    print("🔵 Example 1: Basic State Management")
    print("=" * 50)
    
    # Step 1: Create initial workforce metrics
    initial_metrics = create_initial_workforce_metrics(
        active_employees=1000,
        total_compensation_cost=Decimal('75000000.00'),  # $75M total
        target_growth_rate=Decimal('0.03')  # 3% growth target
    )
    
    print(f"Initial workforce metrics:")
    print(f"  - Active employees: {initial_metrics.active_employees:,}")
    print(f"  - Total compensation: ${initial_metrics.total_compensation_cost:,.2f}")
    print(f"  - Average compensation: ${initial_metrics.average_compensation:,.2f}")
    
    # Step 2: Create state manager
    config = {
        'target_growth_rate': 0.03,
        'random_seed': 42,
        'scenario_id': 'example_scenario_1',
        'plan_design_id': 'standard_plan'
    }
    
    state_manager = create_state_manager(
        scenario_id='example_scenario_1',
        plan_design_id='standard_plan', 
        configuration=config
    )
    
    print(f"\n✅ State manager created for scenario: example_scenario_1")
    
    # Step 3: Initialize year state
    initial_state = state_manager.initialize_year_state(
        simulation_year=2025,
        initial_workforce_metrics=initial_metrics,
        random_seed=42
    )
    
    print(f"\n✅ Initial state created for 2025:")
    print(f"  - State ID: {initial_state.state_id}")
    print(f"  - Status: {initial_state.status}")
    print(f"  - Version: {initial_state.version}")
    print(f"  - Configuration hash: {initial_state.configuration_hash}")
    
    # Step 4: Create some sample events for transition
    sample_events = [
        # Create a hire event
        WorkforceEventFactory.create_hire_event(
            employee_id="EMP_2025_001",
            scenario_id="example_scenario_1",
            plan_design_id="standard_plan",
            hire_date=date(2025, 3, 15),
            department="Engineering",
            job_level=3,
            annual_compensation=Decimal('85000.00')
        ),
        # Create a termination event  
        WorkforceEventFactory.create_termination_event(
            employee_id="EMP_BASELINE_999",
            scenario_id="example_scenario_1",
            plan_design_id="standard_plan",
            effective_date=date(2025, 6, 30),
            termination_reason="voluntary",
            final_pay_date=date(2025, 6, 30)
        )
    ]
    
    print(f"\n📋 Created {len(sample_events)} sample events for transition")
    
    # Step 5: Create transition context
    transition_context = StateTransitionContext(
        source_state=initial_state,
        target_year=2025,
        events_to_process=sample_events,
        configuration=config,
        available_predecessors=set()  # No predecessors for first year
    )
    
    # Step 6: Execute state transition
    try:
        transitioned_state = state_manager.transition_state(transition_context)
        
        print(f"\n✅ State transition completed:")
        print(f"  - New state ID: {transitioned_state.state_id}")
        print(f"  - Status: {transitioned_state.status}")
        print(f"  - Version: {transitioned_state.version}")
        print(f"  - Parent state ID: {transitioned_state.parent_state_id}")
        print(f"  - Events processed: {transitioned_state.event_summary.total_events_processed}")
        
    except Exception as e:
        print(f"❌ State transition failed: {str(e)}")
    
    print("\n" + "=" * 50)
    print("✅ Example 1 completed successfully!")


def example_checkpointing_and_persistence():
    """
    Example 2: Checkpointing and persistence.
    
    Demonstrates:
    - Creating checkpoints
    - Saving checkpoints to storage
    - Loading checkpoints from storage
    - Checkpoint integrity verification
    """
    print("\n🔵 Example 2: Checkpointing and Persistence")
    print("=" * 50)
    
    # Step 1: Create temporary storage directory
    with tempfile.TemporaryDirectory() as temp_dir:
        storage_path = Path(temp_dir)
        print(f"Using temporary storage: {storage_path}")
        
        # Step 2: Create persistence manager
        persistence_manager = StatePersistence(
            storage_path=storage_path,
            enable_compression=True,
            compression_level=6
        )
        
        # Step 3: Create sample state for checkpointing
        sample_metrics = create_initial_workforce_metrics(
            active_employees=1500,
            total_compensation_cost=Decimal('120000000.00'),
            target_growth_rate=Decimal('0.025')
        )
        
        sample_config = {
            'target_growth_rate': 0.025,
            'random_seed': 123,
            'scenario_id': 'checkpoint_example',
            'plan_design_id': 'premium_plan'
        }
        
        sample_state = SimulationState(
            scenario_id='checkpoint_example',
            plan_design_id='premium_plan',
            simulation_year=2026,
            status=StateStatus.COMPLETED,
            workforce_metrics=sample_metrics,
            configuration_hash='abc123def456',
            random_seed=123
        )
        
        print(f"\n📊 Created sample state:")
        print(f"  - Year: {sample_state.simulation_year}")
        print(f"  - Workforce: {sample_state.workforce_metrics.active_employees:,} employees")
        print(f"  - Total cost: ${sample_state.workforce_metrics.total_compensation_cost:,.2f}")
        
        # Step 4: Create checkpoint
        sample_events = ['event-uuid-1', 'event-uuid-2', 'event-uuid-3']  # Mock event UUIDs
        from uuid import uuid4
        mock_event_uuids = [uuid4() for _ in sample_events]
        
        checkpoint = EventSourcingCheckpoint.create_checkpoint(
            checkpoint_type=CheckpointType.YEAR_END,
            simulation_state=sample_state,
            event_audit_trail=mock_event_uuids,
            checkpoint_name="year_end_2026_example",
            description="Example checkpoint for year 2026 completion"
        )
        
        print(f"\n✅ Checkpoint created:")
        print(f"  - Checkpoint ID: {checkpoint.checkpoint_id}")
        print(f"  - Type: {checkpoint.checkpoint_type}")
        print(f"  - Name: {checkpoint.checkpoint_name}")
        print(f"  - Events in audit trail: {checkpoint.cumulative_event_count}")
        print(f"  - Data hash: {checkpoint.data_hash}")
        
        # Step 5: Save checkpoint
        try:
            checkpoint_path = persistence_manager.save_checkpoint(checkpoint)
            print(f"\n💾 Checkpoint saved to: {checkpoint_path}")
            print(f"  - File size: {checkpoint_path.stat().st_size:,} bytes")
            
        except Exception as e:
            print(f"❌ Failed to save checkpoint: {str(e)}")
            return
        
        # Step 6: Load checkpoint
        try:
            loaded_checkpoint = persistence_manager.load_checkpoint(checkpoint_path)
            print(f"\n📖 Checkpoint loaded successfully:")
            print(f"  - Checkpoint ID: {loaded_checkpoint.checkpoint_id}")
            print(f"  - Integrity check: ", end="")
            
            # Step 7: Verify integrity
            is_valid, issues = loaded_checkpoint.verify_integrity()
            if is_valid:
                print("✅ PASSED")
            else:
                print("❌ FAILED")
                for issue in issues:
                    print(f"    - {issue}")
            
        except Exception as e:
            print(f"❌ Failed to load checkpoint: {str(e)}")
        
        # Step 8: Test checkpoint cleanup
        print(f"\n🧹 Testing checkpoint cleanup...")
        
        # Create additional checkpoints for cleanup test
        for i in range(5):
            extra_checkpoint = EventSourcingCheckpoint.create_checkpoint(
                checkpoint_type=CheckpointType.MANUAL,
                simulation_state=sample_state,
                event_audit_trail=mock_event_uuids,
                checkpoint_name=f"extra_checkpoint_{i}",
                description=f"Extra checkpoint {i} for cleanup test"
            )
            persistence_manager.save_checkpoint(extra_checkpoint)
        
        # Count files before cleanup
        all_checkpoint_files = list(storage_path.glob("checkpoint_2026_*.pkl"))
        print(f"  - Checkpoints before cleanup: {len(all_checkpoint_files)}")
        
        # Cleanup old checkpoints, keep only 3 latest
        removed_count = persistence_manager.cleanup_old_checkpoints(
            simulation_year=2026,
            keep_latest=3
        )
        
        # Count files after cleanup
        remaining_files = list(storage_path.glob("checkpoint_2026_*.pkl"))
        print(f"  - Checkpoints after cleanup: {len(remaining_files)}")
        print(f"  - Removed: {removed_count} old checkpoints")
    
    print("\n" + "=" * 50)
    print("✅ Example 2 completed successfully!")


def example_comprehensive_validation():
    """
    Example 3: Comprehensive state validation.
    
    Demonstrates:
    - Setting up validation context
    - Running comprehensive validation
    - Handling validation results
    - Custom validation scenarios
    """
    print("\n🔵 Example 3: Comprehensive State Validation")
    print("=" * 50)
    
    # Step 1: Set up multi-year scenario for validation
    config = {
        'target_growth_rate': 0.04,
        'total_termination_rate': 0.10,
        'new_hire_termination_rate': 0.20,
        'random_seed': 456
    }
    
    state_manager = create_state_manager(
        scenario_id='validation_example',
        plan_design_id='validation_plan',
        configuration=config
    )
    
    # Step 2: Create states for multiple years
    years = [2025, 2026, 2027]
    
    for i, year in enumerate(years):
        # Create metrics with realistic progression
        base_employees = 2000 + i * 80  # Growth each year
        base_cost = Decimal(f'{150000000 + i * 6000000}')  # Cost growth
        
        metrics = create_initial_workforce_metrics(
            active_employees=base_employees,
            total_compensation_cost=base_cost,
            target_growth_rate=Decimal('0.04')
        )
        
        # Set prerequisites (each year depends on previous years)
        prerequisites = set(years[:i]) if i > 0 else set()
        
        state = state_manager.initialize_year_state(
            simulation_year=year,
            initial_workforce_metrics=metrics,
            prerequisite_years=prerequisites,
            random_seed=config['random_seed'] + i
        )
        
        print(f"📊 Created state for {year}:")
        print(f"  - Employees: {metrics.active_employees:,}")
        print(f"  - Total cost: ${metrics.total_compensation_cost:,.2f}")
        print(f"  - Prerequisites: {prerequisites}")
    
    # Step 3: Create validation context
    validation_context = create_validation_context(
        state_manager=state_manager,
        simulation_years=years,
        scenario_id='validation_example',
        plan_design_id='validation_plan',
        configuration=config,
        strict_mode=True
    )
    
    print(f"\n🔍 Created validation context:")
    print(f"  - Years to validate: {validation_context.simulation_years}")
    print(f"  - Strict mode: {validation_context.strict_mode}")
    print(f"  - Cross-year validation: {validation_context.validate_cross_year_dependencies}")
    print(f"  - Regulatory compliance: {validation_context.validate_regulatory_compliance}")
    
    # Step 4: Run comprehensive validation
    validator = StateValidator()
    
    try:
        validation_result = validator.validate_simulation_state(validation_context)
        
        print(f"\n✅ Validation completed:")
        print(f"  - Overall result: {'✅ VALID' if validation_result.is_valid else '❌ INVALID'}")
        print(f"  - Total issues: {validation_result.total_issue_count}")
        print(f"  - Critical: {validation_result.critical_count}")
        print(f"  - Errors: {validation_result.error_count}")
        print(f"  - Warnings: {validation_result.warning_count}")
        print(f"  - Info: {validation_result.info_count}")
        
        # Step 5: Display issues by category
        if validation_result.issues:
            print(f"\n📋 Issues by category:")
            
            from .state_validation import ValidationCategory
            for category in ValidationCategory:
                category_issues = validation_result.get_issues_by_category(category)
                if category_issues:
                    print(f"\n  {category.value.upper()}:")
                    for issue in category_issues[:3]:  # Show first 3 issues per category
                        print(f"    - {issue.severity.upper()}: {issue.title}")
                        print(f"      {issue.description}")
                        if issue.recommendation:
                            print(f"      💡 {issue.recommendation}")
        
        # Step 6: Test specific validation scenarios
        print(f"\n🧪 Testing specific validation scenarios...")
        
        # Test workforce continuity validation
        continuity_valid, continuity_issues = state_manager.validate_workforce_continuity(2025, 2026)
        print(f"  - Workforce continuity (2025→2026): {'✅' if continuity_valid else '❌'}")
        if continuity_issues:
            for issue in continuity_issues[:2]:  # Show first 2 issues
                print(f"    • {issue}")
        
    except Exception as e:
        print(f"❌ Validation failed: {str(e)}")
    
    print("\n" + "=" * 50)
    print("✅ Example 3 completed successfully!")


def example_enhanced_orchestrator_integration():
    """
    Example 4: Enhanced orchestrator integration.
    
    Demonstrates:
    - Creating enhanced orchestrator
    - Running simulation with state management
    - Checkpoint creation during simulation
    - State validation integration
    """
    print("\n🔵 Example 4: Enhanced Orchestrator Integration")
    print("=" * 50)
    
    # Step 1: Set up enhanced orchestrator configuration
    config = {
        'scenario_id': 'enhanced_example',
        'plan_design_id': 'integrated_plan',
        'target_growth_rate': 0.035,
        'workforce': {
            'total_termination_rate': 0.12,
            'new_hire_termination_rate': 0.25
        },
        'eligibility': {
            'waiting_period_days': 30
        },
        'random_seed': 789,
        'multi_year': {
            'state': {
                'enable_state_compression': True,
                'enable_checkpointing': True,
                'checkpoint_frequency': 1
            }
        }
    }
    
    # Step 2: Create enhanced orchestrator
    with tempfile.TemporaryDirectory() as temp_dir:
        checkpoint_path = Path(temp_dir) / "checkpoints"
        
        enhanced_orchestrator = create_enhanced_orchestrator(
            start_year=2025,
            end_year=2027,  # 3-year simulation
            config=config,
            force_clear=False,
            preserve_data=True,
            enable_state_management=True,
            checkpoint_storage_path=checkpoint_path
        )
        
        print(f"🚀 Enhanced orchestrator created:")
        print(f"  - Years: 2025-2027")
        print(f"  - State management: {'✅ Enabled' if enhanced_orchestrator.enable_state_management else '❌ Disabled'}")
        print(f"  - Checkpoint storage: {checkpoint_path}")
        print(f"  - Scenario ID: {enhanced_orchestrator.scenario_id}")
        print(f"  - Plan design ID: {enhanced_orchestrator.plan_design_id}")
        
        # Step 3: Test state management features before simulation
        print(f"\n🔍 Testing state management features:")
        
        # Test manual checkpoint creation (requires initialization first)
        try:
            # This would normally be called after state initialization
            print(f"  - Manual checkpoint: ⏳ (requires simulation state)")
        except Exception as e:
            print(f"  - Manual checkpoint: ⏳ (not initialized yet)")
        
        # Test validation
        try:
            validation_result = enhanced_orchestrator.validate_simulation_state(
                years_to_validate=[2025],
                strict_mode=False
            )
            print(f"  - Initial validation: ✅ (no issues expected)")
        except Exception as e:
            print(f"  - Initial validation: ⏳ (requires simulation state)")
        
        # Step 4: Simulate enhanced orchestrator workflow (without actual database operations)
        print(f"\n🎬 Simulating enhanced orchestrator workflow:")
        
        try:
            # In a real scenario, this would run the full simulation
            # For this example, we'll simulate the workflow stages
            
            print(f"  📋 Stage 1: State initialization")
            print(f"    - Initializing state tracking for years 2025-2027")
            print(f"    - Creating baseline workforce metrics")
            print(f"    - Setting up dependency tracking")
            
            print(f"  📋 Stage 2: Year-by-year processing")
            for year in [2025, 2026, 2027]:
                print(f"    - Processing year {year}:")
                print(f"      • State transition preparation")
                print(f"      • Event processing simulation")
                print(f"      • Workforce metrics calculation") 
                print(f"      • Checkpoint creation")
                print(f"      • State validation")
            
            print(f"  📋 Stage 3: Final validation and reporting")
            print(f"    - Cross-year continuity validation")
            print(f"    - Regulatory compliance checks")
            print(f"    - Enhanced results generation")
            
            # Mock results structure
            mock_results = {
                'start_year': 2025,
                'end_year': 2027,
                'years_completed': [2025, 2026, 2027],
                'years_failed': [],
                'total_runtime_seconds': 45.6,
                'state_management': {
                    'enabled': True,
                    'scenario_id': 'enhanced_example',
                    'plan_design_id': 'integrated_plan',
                    'total_states_tracked': 3,
                    'available_years': [2025, 2026, 2027]
                },
                'state_summaries': {
                    2025: {'workforce_count': 2000, 'total_cost': 150000000},
                    2026: {'workforce_count': 2070, 'total_cost': 156000000},
                    2027: {'workforce_count': 2145, 'total_cost': 162240000}
                }
            }
            
            print(f"\n✅ Enhanced simulation completed (simulated):")
            print(f"  - Years completed: {mock_results['years_completed']}")
            print(f"  - Total runtime: {mock_results['total_runtime_seconds']}s")
            print(f"  - States tracked: {mock_results['state_management']['total_states_tracked']}")
            
            # Display state summaries
            print(f"\n📊 State summaries:")
            for year, summary in mock_results['state_summaries'].items():
                print(f"  - {year}: {summary['workforce_count']:,} employees, ${summary['total_cost']:,} total cost")
            
        except Exception as e:
            print(f"❌ Enhanced orchestrator workflow failed: {str(e)}")
        
        # Step 5: Test checkpoint and resume functionality
        print(f"\n🔄 Testing checkpoint and resume functionality:")
        
        try:
            # List checkpoint files (would contain actual checkpoints after simulation)
            checkpoint_files = list(checkpoint_path.glob("*.pkl")) if checkpoint_path.exists() else []
            print(f"  - Checkpoint files found: {len(checkpoint_files)}")
            
            if checkpoint_files:
                print(f"  - Latest checkpoint: {checkpoint_files[-1].name}")
                print(f"  - Resume capability: ✅ Available")
            else:
                print(f"  - Resume capability: ⏳ (no checkpoints yet)")
            
        except Exception as e:
            print(f"  - Checkpoint test: ❌ {str(e)}")
    
    print("\n" + "=" * 50)
    print("✅ Example 4 completed successfully!")


def example_performance_optimization():
    """
    Example 5: Performance optimization scenarios.
    
    Demonstrates:
    - Batch processing optimization
    - Memory-efficient state management
    - Parallel validation scenarios
    - Performance monitoring
    """
    print("\n🔵 Example 5: Performance Optimization")
    print("=" * 50)
    
    # Step 1: Set up large-scale simulation configuration
    config = {
        'scenario_id': 'performance_test',
        'plan_design_id': 'large_scale_plan',
        'target_growth_rate': 0.05,
        'random_seed': 999,
        'performance': {
            'batch_processing_size': 5000,
            'enable_parallel_processing': True,
            'cache_demographic_calculations': True,
            'materialization_strategy': 'incremental'
        },
        'multi_year': {
            'optimization': {
                'level': 'high',
                'max_workers': 4,
                'batch_size': 2000,
                'memory_limit_gb': 4.0
            },
            'performance': {
                'enable_state_compression': True,
                'enable_concurrent_processing': True,
                'cache_workforce_snapshots': True
            }
        }
    }
    
    print(f"⚙️ Performance configuration:")
    print(f"  - Batch size: {config['performance']['batch_processing_size']:,}")
    print(f"  - Parallel processing: {config['performance']['enable_parallel_processing']}")
    print(f"  - Max workers: {config['multi_year']['optimization']['max_workers']}")
    print(f"  - Memory limit: {config['multi_year']['optimization']['memory_limit_gb']} GB")
    print(f"  - State compression: {config['multi_year']['performance']['enable_state_compression']}")
    
    # Step 2: Create large workforce metrics for performance testing
    large_workforce_metrics = create_initial_workforce_metrics(
        active_employees=50000,  # 50K employees
        total_compensation_cost=Decimal('3750000000.00'),  # $3.75B total
        target_growth_rate=Decimal('0.05')
    )
    
    print(f"\n📊 Large workforce scenario:")
    print(f"  - Employees: {large_workforce_metrics.active_employees:,}")
    print(f"  - Total cost: ${large_workforce_metrics.total_compensation_cost:,}")
    print(f"  - Avg compensation: ${large_workforce_metrics.average_compensation:,}")
    
    # Step 3: Performance timing simulation
    import time
    
    print(f"\n⏱️ Performance timing simulation:")
    
    # Simulate state creation performance
    start_time = time.time()
    
    state_manager = create_state_manager(
        scenario_id='performance_test',
        plan_design_id='large_scale_plan',
        configuration=config
    )
    
    state_creation_time = time.time() - start_time
    print(f"  - State manager creation: {state_creation_time:.3f}s")
    
    # Simulate multiple year initialization
    start_time = time.time()
    years = list(range(2025, 2035))  # 10-year simulation
    
    for i, year in enumerate(years):
        # Scale workforce for each year
        scaled_employees = large_workforce_metrics.active_employees + i * 2000
        scaled_cost = large_workforce_metrics.total_compensation_cost * (Decimal('1.05') ** i)
        
        scaled_metrics = create_initial_workforce_metrics(
            active_employees=scaled_employees,
            total_compensation_cost=scaled_cost,
            target_growth_rate=Decimal('0.05')
        )
        
        prerequisites = set(years[:i]) if i > 0 else set()
        
        state_manager.initialize_year_state(
            simulation_year=year,
            initial_workforce_metrics=scaled_metrics,
            prerequisite_years=prerequisites,
            random_seed=config['random_seed'] + i
        )
    
    multi_year_init_time = time.time() - start_time
    print(f"  - 10-year state initialization: {multi_year_init_time:.3f}s")
    print(f"  - Average per year: {multi_year_init_time/len(years):.3f}s")
    
    # Step 4: Memory usage estimation
    print(f"\n💾 Memory usage estimation:")
    
    # Estimate memory usage per state
    state_sample = state_manager.get_state(2025)
    if state_sample:
        # Rough estimation based on state components
        estimated_memory_per_state = 0.1  # MB per state (simplified)
        total_estimated_memory = estimated_memory_per_state * len(years)
        
        print(f"  - Estimated memory per state: {estimated_memory_per_state:.1f} MB")
        print(f"  - Total estimated memory: {total_estimated_memory:.1f} MB")
        print(f"  - Memory efficiency: {'✅ Good' if total_estimated_memory < 100 else '⚠️ High'}")
    
    # Step 5: Batch validation performance
    print(f"\n🔍 Batch validation performance:")
    
    start_time = time.time()
    
    # Validate in batches
    batch_size = 3
    batches = [years[i:i+batch_size] for i in range(0, len(years), batch_size)]
    
    total_issues = 0
    for i, batch in enumerate(batches):
        batch_start = time.time()
        
        try:
            validation_result = validate_simulation_comprehensive(
                state_manager=state_manager,
                simulation_years=batch,
                scenario_id='performance_test',
                plan_design_id='large_scale_plan',
                configuration=config,
                strict_mode=False  # Use lenient mode for performance
            )
            
            batch_time = time.time() - batch_start
            total_issues += validation_result.total_issue_count
            
            print(f"  - Batch {i+1} ({len(batch)} years): {batch_time:.3f}s, {validation_result.total_issue_count} issues")
            
        except Exception as e:
            print(f"  - Batch {i+1}: ❌ {str(e)}")
    
    total_validation_time = time.time() - start_time
    print(f"  - Total validation time: {total_validation_time:.3f}s")
    print(f"  - Total issues found: {total_issues}")
    print(f"  - Validation throughput: {len(years)/total_validation_time:.1f} years/second")
    
    # Step 6: Compression effectiveness test
    print(f"\n🗜️ Testing compression effectiveness:")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        storage_path = Path(temp_dir)
        
        # Test with compression
        compressed_persistence = StatePersistence(
            storage_path=storage_path / "compressed",
            enable_compression=True,
            compression_level=9
        )
        
        # Test without compression
        uncompressed_persistence = StatePersistence(
            storage_path=storage_path / "uncompressed",
            enable_compression=False
        )
        
        # Create sample checkpoint
        sample_state = state_manager.get_state(2025)
        if sample_state:
            from uuid import uuid4
            mock_events = [uuid4() for _ in range(1000)]  # 1000 mock events
            
            checkpoint = EventSourcingCheckpoint.create_checkpoint(
                checkpoint_type=CheckpointType.MANUAL,
                simulation_state=sample_state,
                event_audit_trail=mock_events,
                checkpoint_name="compression_test",
                description="Testing compression effectiveness"
            )
            
            # Save with compression
            compressed_path = compressed_persistence.save_checkpoint(checkpoint)
            compressed_size = compressed_path.stat().st_size
            
            # Save without compression  
            uncompressed_path = uncompressed_persistence.save_checkpoint(checkpoint)
            uncompressed_size = uncompressed_path.stat().st_size
            
            compression_ratio = uncompressed_size / compressed_size if compressed_size > 0 else 1
            space_saved = uncompressed_size - compressed_size
            
            print(f"  - Uncompressed size: {uncompressed_size:,} bytes")
            print(f"  - Compressed size: {compressed_size:,} bytes")
            print(f"  - Compression ratio: {compression_ratio:.1f}x")
            print(f"  - Space saved: {space_saved:,} bytes ({100*(space_saved/uncompressed_size):.1f}%)")
    
    print("\n" + "=" * 50)
    print("✅ Example 5 completed successfully!")


def run_all_examples():
    """Run all state management examples."""
    print("🌟 State Management System Examples")
    print("=" * 60)
    print("Running comprehensive examples of the state management system...")
    print("=" * 60)
    
    try:
        example_basic_state_management()
        example_checkpointing_and_persistence()
        example_comprehensive_validation()
        example_enhanced_orchestrator_integration()
        example_performance_optimization()
        
        print("\n" + "🌟" * 20)
        print("🎉 ALL EXAMPLES COMPLETED SUCCESSFULLY! 🎉")
        print("🌟" * 20)
        
        print(f"\nSummary of demonstrated capabilities:")
        print(f"✅ Basic state management and transitions")
        print(f"✅ Checkpoint creation and persistence")
        print(f"✅ Comprehensive state validation")
        print(f"✅ Enhanced orchestrator integration")
        print(f"✅ Performance optimization techniques")
        
        print(f"\n💡 Next steps:")
        print(f"  - Integrate with your existing simulation workflow")
        print(f"  - Customize validation rules for your specific needs")
        print(f"  - Set up checkpoint storage in production environment")
        print(f"  - Configure performance optimization for your scale")
        
    except Exception as e:
        print(f"\n❌ Examples failed: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    # Set up logging for examples
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Run all examples
    run_all_examples()