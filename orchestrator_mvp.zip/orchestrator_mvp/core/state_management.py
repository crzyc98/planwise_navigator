"""
Core state management components for multi-year coordination system.

This module provides enterprise-grade state management for workforce simulation with:
- Cost modeling precision with UUID-stamped attribution
- Immutable audit trails through event sourcing
- Checkpoint/resume functionality for multi-year simulations
- Cross-year workforce state transitions with dependency tracking
- Integration with existing SimulationEvent model

Components:
- SimulationState: Enhanced state management with cost precision
- EventSourcingCheckpoint: Immutable checkpoint system with audit preservation
- WorkforceStateManager: Cross-year state transitions with dependency tracking
- StateValidation: Workforce continuity validation
- StatePersistence: Checkpoint/resume functionality

Architecture follows PlanWise Navigator's event sourcing principles:
- All state changes are event-driven and immutable
- Complete audit trail preservation for regulatory compliance
- Type-safe validation using Pydantic v2
- Integration with existing event model in config/events.py
"""

from __future__ import annotations
import logging
from typing import Dict, Any, Optional, List, Set, Union, Tuple
from datetime import datetime, date
from decimal import Decimal
from uuid import UUID, uuid4
from dataclasses import dataclass, field
from pathlib import Path
import json
import hashlib
import pickle
import gzip
from enum import Enum

from pydantic import BaseModel, Field, ConfigDict, field_validator, computed_field
from pydantic.types import NonNegativeInt, PositiveInt

# Import existing event model
from config.events import SimulationEvent, EventFactory

logger = logging.getLogger(__name__)


class StateStatus(str, Enum):
    """Enumeration of simulation state statuses."""
    INITIALIZING = "initializing"
    ACTIVE = "active"
    SUSPENDED = "suspended"
    COMPLETED = "completed"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"


class CheckpointType(str, Enum):
    """Types of state checkpoints."""
    YEAR_START = "year_start"
    YEAR_END = "year_end"
    EVENT_BATCH = "event_batch"
    MILESTONE = "milestone"
    MANUAL = "manual"
    ERROR_RECOVERY = "error_recovery"


class WorkforceMetrics(BaseModel):
    """Workforce metrics with cost modeling precision."""
    
    model_config = ConfigDict(
        frozen=True,  # Immutable for audit trail integrity
        use_enum_values=True,
        validate_assignment=True
    )
    
    # Core workforce counts
    total_employees: NonNegativeInt
    active_employees: NonNegativeInt
    terminated_employees: NonNegativeInt = 0
    
    # New hire tracking
    new_hires_ytd: NonNegativeInt = 0
    terminations_ytd: NonNegativeInt = 0
    
    # Cost metrics with precision
    total_compensation_cost: Decimal = Field(default=Decimal('0'), decimal_places=6)
    average_compensation: Decimal = Field(default=Decimal('0'), decimal_places=6)
    median_compensation: Decimal = Field(default=Decimal('0'), decimal_places=6)
    
    # Growth metrics
    growth_rate_ytd: Decimal = Field(default=Decimal('0'), decimal_places=4)
    target_growth_rate: Decimal = Field(default=Decimal('0'), decimal_places=4)
    
    # Demographic distribution
    level_distribution: Dict[int, int] = Field(default_factory=dict)
    age_band_distribution: Dict[str, int] = Field(default_factory=dict)
    tenure_band_distribution: Dict[str, int] = Field(default_factory=dict)
    
    @field_validator('total_compensation_cost', 'average_compensation', 'median_compensation')
    @classmethod
    def validate_compensation_precision(cls, v: Decimal) -> Decimal:
        """Ensure compensation has enterprise-grade precision (18,6)."""
        return v.quantize(Decimal('0.000001'))
    
    @field_validator('growth_rate_ytd', 'target_growth_rate')
    @classmethod
    def validate_rate_precision(cls, v: Decimal) -> Decimal:
        """Ensure rates have proper precision (4 decimal places)."""
        return v.quantize(Decimal('0.0001'))
    
    @computed_field
    @property
    def net_hiring_ytd(self) -> int:
        """Calculate net hiring year-to-date."""
        return self.new_hires_ytd - self.terminations_ytd
    
    @computed_field
    @property
    def turnover_rate_ytd(self) -> Decimal:
        """Calculate turnover rate year-to-date."""
        if self.active_employees == 0:
            return Decimal('0')
        return (Decimal(str(self.terminations_ytd)) / Decimal(str(self.active_employees))).quantize(Decimal('0.0001'))


class EventSummary(BaseModel):
    """Summary of events processed in a state transition."""
    
    model_config = ConfigDict(
        frozen=True,
        use_enum_values=True
    )
    
    # Event counts by type
    hire_events: NonNegativeInt = 0
    termination_events: NonNegativeInt = 0
    promotion_events: NonNegativeInt = 0
    merit_events: NonNegativeInt = 0
    eligibility_events: NonNegativeInt = 0
    enrollment_events: NonNegativeInt = 0
    
    # Processing metadata
    total_events_processed: NonNegativeInt = 0
    processing_duration_seconds: Decimal = Field(default=Decimal('0'), decimal_places=3)
    events_per_second: Decimal = Field(default=Decimal('0'), decimal_places=2)
    
    # Cost impact summary
    total_cost_impact: Decimal = Field(default=Decimal('0'), decimal_places=6)
    average_cost_impact_per_event: Decimal = Field(default=Decimal('0'), decimal_places=6)
    
    @field_validator('total_cost_impact', 'average_cost_impact_per_event')
    @classmethod
    def validate_cost_precision(cls, v: Decimal) -> Decimal:
        """Ensure cost impacts have proper precision."""
        return v.quantize(Decimal('0.000001'))


class SimulationState(BaseModel):
    """
    Enhanced state management with cost modeling precision and UUID-stamped attribution.
    
    This class maintains the complete state of a workforce simulation with:
    - Immutable audit trail through UUID tracking
    - Cost modeling precision for regulatory compliance
    - Type-safe validation using Pydantic v2
    - Integration with existing event sourcing architecture
    """
    
    model_config = ConfigDict(
        frozen=True,  # Immutable for audit trail integrity
        use_enum_values=True,
        validate_assignment=True
    )
    
    # Core identification
    state_id: UUID = Field(default_factory=uuid4)
    scenario_id: str = Field(..., min_length=1)
    plan_design_id: str = Field(..., min_length=1)
    
    # Temporal context
    simulation_year: PositiveInt
    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_updated_at: datetime = Field(default_factory=datetime.utcnow)
    
    # State status and metadata
    status: StateStatus = StateStatus.INITIALIZING
    version: PositiveInt = 1
    parent_state_id: Optional[UUID] = None  # For state transitions
    
    # Workforce metrics with cost precision
    workforce_metrics: WorkforceMetrics
    
    # Event processing summary
    event_summary: EventSummary = Field(default_factory=EventSummary)
    
    # Configuration context
    configuration_hash: str = Field(..., min_length=1)
    random_seed: Optional[int] = None
    
    # Dependency tracking
    prerequisite_years: Set[int] = Field(default_factory=set)
    dependent_states: Set[UUID] = Field(default_factory=set)
    
    # Error and validation context
    validation_errors: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    
    @field_validator('scenario_id', 'plan_design_id')
    @classmethod
    def validate_identifiers(cls, v: str) -> str:
        """Validate identifiers are not empty."""
        if not v or not v.strip():
            raise ValueError('Identifier cannot be empty')
        return v.strip()
    
    @field_validator('configuration_hash')
    @classmethod
    def validate_configuration_hash(cls, v: str) -> str:
        """Validate configuration hash format."""
        if not v or len(v) < 8:
            raise ValueError('Configuration hash must be at least 8 characters')
        return v
    
    def create_transition(
        self,
        new_status: StateStatus,
        workforce_metrics: WorkforceMetrics,
        event_summary: EventSummary,
        validation_errors: Optional[List[str]] = None,
        warnings: Optional[List[str]] = None
    ) -> 'SimulationState':
        """
        Create a new state representing a transition from current state.
        
        Args:
            new_status: New state status
            workforce_metrics: Updated workforce metrics
            event_summary: Summary of events processed in transition
            validation_errors: Optional validation errors
            warnings: Optional warnings
            
        Returns:
            New SimulationState representing the transition
        """
        return SimulationState(
            scenario_id=self.scenario_id,
            plan_design_id=self.plan_design_id,
            simulation_year=self.simulation_year,
            status=new_status,
            version=self.version + 1,
            parent_state_id=self.state_id,
            workforce_metrics=workforce_metrics,
            event_summary=event_summary,
            configuration_hash=self.configuration_hash,
            random_seed=self.random_seed,
            prerequisite_years=self.prerequisite_years.copy(),
            dependent_states=self.dependent_states.copy(),
            validation_errors=validation_errors or [],
            warnings=warnings or []
        )
    
    @computed_field
    @property
    def is_valid(self) -> bool:
        """Check if state is valid (no validation errors)."""
        return len(self.validation_errors) == 0
    
    @computed_field
    @property
    def state_summary(self) -> Dict[str, Any]:
        """Generate summary of current state for logging/reporting."""
        return {
            'state_id': str(self.state_id),
            'simulation_year': self.simulation_year,
            'status': self.status.value,
            'version': self.version,
            'workforce_count': self.workforce_metrics.active_employees,
            'total_cost': float(self.workforce_metrics.total_compensation_cost),
            'is_valid': self.is_valid,
            'error_count': len(self.validation_errors),
            'warning_count': len(self.warnings),
            'events_processed': self.event_summary.total_events_processed
        }


class EventSourcingCheckpoint(BaseModel):
    """
    Immutable checkpoint system with audit trail preservation.
    
    Provides enterprise-grade checkpointing for multi-year simulations with:
    - Complete event audit trail preservation
    - Immutable checkpoint snapshots
    - State reconstruction capabilities
    - Regulatory compliance support
    """
    
    model_config = ConfigDict(
        frozen=True,
        use_enum_values=True
    )
    
    # Core identification
    checkpoint_id: UUID = Field(default_factory=uuid4)
    checkpoint_type: CheckpointType
    created_at: datetime = Field(default_factory=datetime.utcnow)
    
    # State context
    simulation_state: SimulationState
    
    # Event audit trail (UUIDs of events that led to this checkpoint)
    event_audit_trail: List[UUID] = Field(default_factory=list)
    cumulative_event_count: NonNegativeInt = 0
    
    # Checkpoint metadata
    checkpoint_name: str = Field(..., min_length=1)
    description: Optional[str] = None
    
    # Data integrity
    data_hash: str = Field(..., min_length=1)
    compression_enabled: bool = False
    compressed_size_bytes: Optional[int] = None
    
    # Recovery metadata
    recovery_point_reliable: bool = True
    prerequisites_satisfied: bool = True
    
    @field_validator('checkpoint_name')
    @classmethod
    def validate_checkpoint_name(cls, v: str) -> str:
        """Validate checkpoint name format."""
        if not v or not v.strip():
            raise ValueError('Checkpoint name cannot be empty')
        return v.strip()
    
    @field_validator('data_hash')
    @classmethod
    def validate_data_hash(cls, v: str) -> str:
        """Validate data hash format."""
        if not v or len(v) < 16:
            raise ValueError('Data hash must be at least 16 characters')
        return v
    
    @classmethod
    def create_checkpoint(
        cls,
        checkpoint_type: CheckpointType,
        simulation_state: SimulationState,
        event_audit_trail: List[UUID],
        checkpoint_name: str,
        description: Optional[str] = None
    ) -> 'EventSourcingCheckpoint':
        """
        Create a new checkpoint with proper data integrity validation.
        
        Args:
            checkpoint_type: Type of checkpoint being created
            simulation_state: Current simulation state
            event_audit_trail: List of event UUIDs that led to this state
            checkpoint_name: Human-readable name for checkpoint
            description: Optional description
            
        Returns:
            New EventSourcingCheckpoint
        """
        # Generate data hash for integrity verification
        data_for_hash = {
            'state_id': str(simulation_state.state_id),
            'simulation_year': simulation_state.simulation_year,
            'workforce_count': simulation_state.workforce_metrics.active_employees,
            'total_cost': str(simulation_state.workforce_metrics.total_compensation_cost),
            'event_count': len(event_audit_trail),
            'configuration_hash': simulation_state.configuration_hash
        }
        data_hash = hashlib.sha256(json.dumps(data_for_hash, sort_keys=True).encode()).hexdigest()[:32]
        
        return cls(
            checkpoint_type=checkpoint_type,
            simulation_state=simulation_state,
            event_audit_trail=event_audit_trail.copy(),
            cumulative_event_count=len(event_audit_trail),
            checkpoint_name=checkpoint_name,
            description=description,
            data_hash=data_hash,
            prerequisites_satisfied=simulation_state.is_valid
        )
    
    def verify_integrity(self) -> Tuple[bool, List[str]]:
        """
        Verify checkpoint data integrity.
        
        Returns:
            Tuple of (is_valid, list_of_issues)
        """
        issues = []
        
        # Verify data hash
        data_for_hash = {
            'state_id': str(self.simulation_state.state_id),
            'simulation_year': self.simulation_state.simulation_year,
            'workforce_count': self.simulation_state.workforce_metrics.active_employees,
            'total_cost': str(self.simulation_state.workforce_metrics.total_compensation_cost),
            'event_count': len(self.event_audit_trail),
            'configuration_hash': self.simulation_state.configuration_hash
        }
        expected_hash = hashlib.sha256(json.dumps(data_for_hash, sort_keys=True).encode()).hexdigest()[:32]
        
        if expected_hash != self.data_hash:
            issues.append(f"Data hash mismatch: expected {expected_hash}, got {self.data_hash}")
        
        # Verify event count consistency
        if len(self.event_audit_trail) != self.cumulative_event_count:
            issues.append(f"Event count mismatch: trail has {len(self.event_audit_trail)}, declared {self.cumulative_event_count}")
        
        # Verify state validity
        if not self.simulation_state.is_valid and self.recovery_point_reliable:
            issues.append("State has validation errors but checkpoint marked as reliable recovery point")
        
        return len(issues) == 0, issues


@dataclass
class StateTransitionContext:
    """Context for state transitions with dependency tracking."""
    
    source_state: SimulationState
    target_year: int
    events_to_process: List[SimulationEvent]
    configuration: Dict[str, Any]
    
    # Dependency tracking
    required_predecessors: Set[int] = field(default_factory=set)
    available_predecessors: Set[int] = field(default_factory=set)
    
    # Processing metadata
    start_time: Optional[datetime] = None
    estimated_duration_seconds: Optional[float] = None
    
    @property
    def dependencies_satisfied(self) -> bool:
        """Check if all required predecessor years are available."""
        return self.required_predecessors.issubset(self.available_predecessors)
    
    @property
    def missing_dependencies(self) -> Set[int]:
        """Get set of missing dependency years."""
        return self.required_predecessors - self.available_predecessors


class WorkforceStateManager:
    """
    Cross-year state transitions with dependency tracking.
    
    Manages workforce state evolution across simulation years with:
    - Sequential dependency validation
    - Event-driven state transitions
    - Cost impact analysis
    - Workforce continuity preservation
    """
    
    def __init__(
        self,
        scenario_id: str,
        plan_design_id: str,
        configuration: Dict[str, Any],
        logger: Optional[logging.Logger] = None
    ):
        """
        Initialize workforce state manager.
        
        Args:
            scenario_id: Unique scenario identifier
            plan_design_id: Plan design identifier
            configuration: Simulation configuration
            logger: Optional logger instance
        """
        self.scenario_id = scenario_id
        self.plan_design_id = plan_design_id
        self.configuration = configuration
        self.logger = logger or logging.getLogger(__name__)
        
        # State tracking
        self._states_by_year: Dict[int, SimulationState] = {}
        self._checkpoints: Dict[UUID, EventSourcingCheckpoint] = {}
        self._event_audit_trail: List[UUID] = []
        
        # Configuration hash for integrity verification
        self._config_hash = hashlib.sha256(
            json.dumps(configuration, sort_keys=True).encode()
        ).hexdigest()[:16]
        
        self.logger.info(f"Initialized WorkforceStateManager for scenario {scenario_id}")
    
    def initialize_year_state(
        self,
        simulation_year: int,
        initial_workforce_metrics: WorkforceMetrics,
        prerequisite_years: Optional[Set[int]] = None,
        random_seed: Optional[int] = None
    ) -> SimulationState:
        """
        Initialize state for a simulation year.
        
        Args:
            simulation_year: Year to initialize
            initial_workforce_metrics: Initial workforce metrics
            prerequisite_years: Required predecessor years
            random_seed: Optional random seed
            
        Returns:
            Initialized SimulationState
            
        Raises:
            ValueError: If year already initialized or dependencies not met
        """
        if simulation_year in self._states_by_year:
            raise ValueError(f"Year {simulation_year} already initialized")
        
        # Validate dependencies
        prereq_years = prerequisite_years or set()
        if not prereq_years.issubset(self._states_by_year.keys()):
            missing = prereq_years - set(self._states_by_year.keys())
            raise ValueError(f"Missing prerequisite years: {missing}")
        
        # Create initial state
        initial_state = SimulationState(
            scenario_id=self.scenario_id,
            plan_design_id=self.plan_design_id,
            simulation_year=simulation_year,
            status=StateStatus.INITIALIZING,
            workforce_metrics=initial_workforce_metrics,
            configuration_hash=self._config_hash,
            random_seed=random_seed,
            prerequisite_years=prereq_years
        )
        
        self._states_by_year[simulation_year] = initial_state
        
        self.logger.info(f"Initialized state for year {simulation_year} with {initial_workforce_metrics.active_employees} employees")
        
        return initial_state
    
    def transition_state(
        self,
        transition_context: StateTransitionContext
    ) -> SimulationState:
        """
        Execute state transition with event processing and validation.
        
        Args:
            transition_context: Context for the state transition
            
        Returns:
            New SimulationState after transition
            
        Raises:
            ValueError: If dependencies not satisfied or transition invalid
        """
        if not transition_context.dependencies_satisfied:
            missing = transition_context.missing_dependencies
            raise ValueError(f"State transition dependencies not satisfied. Missing years: {missing}")
        
        start_time = datetime.utcnow()
        transition_context.start_time = start_time
        
        try:
            # Process events and calculate new workforce metrics
            new_metrics = self._process_events_for_metrics(
                transition_context.source_state.workforce_metrics,
                transition_context.events_to_process
            )
            
            # Create event summary
            event_summary = self._create_event_summary(
                transition_context.events_to_process,
                start_time
            )
            
            # Update event audit trail
            event_uuids = [event.event_id for event in transition_context.events_to_process]
            self._event_audit_trail.extend(event_uuids)
            
            # Create new state
            new_state = transition_context.source_state.create_transition(
                new_status=StateStatus.ACTIVE,
                workforce_metrics=new_metrics,
                event_summary=event_summary
            )
            
            # Update state tracking
            self._states_by_year[transition_context.target_year] = new_state
            
            self.logger.info(f"State transition completed for year {transition_context.target_year}")
            self.logger.info(f"Processed {len(transition_context.events_to_process)} events in {(datetime.utcnow() - start_time).total_seconds():.2f}s")
            
            return new_state
            
        except Exception as e:
            self.logger.error(f"State transition failed for year {transition_context.target_year}: {str(e)}")
            
            # Create failed state
            failed_state = transition_context.source_state.create_transition(
                new_status=StateStatus.FAILED,
                workforce_metrics=transition_context.source_state.workforce_metrics,
                event_summary=EventSummary(),
                validation_errors=[f"State transition failed: {str(e)}"]
            )
            
            self._states_by_year[transition_context.target_year] = failed_state
            raise
    
    def create_checkpoint(
        self,
        simulation_year: int,
        checkpoint_type: CheckpointType,
        checkpoint_name: str,
        description: Optional[str] = None
    ) -> EventSourcingCheckpoint:
        """
        Create checkpoint for current state.
        
        Args:
            simulation_year: Year to checkpoint
            checkpoint_type: Type of checkpoint
            checkpoint_name: Human-readable checkpoint name
            description: Optional description
            
        Returns:
            Created EventSourcingCheckpoint
            
        Raises:
            ValueError: If year not found in state tracking
        """
        if simulation_year not in self._states_by_year:
            raise ValueError(f"No state found for year {simulation_year}")
        
        current_state = self._states_by_year[simulation_year]
        
        checkpoint = EventSourcingCheckpoint.create_checkpoint(
            checkpoint_type=checkpoint_type,
            simulation_state=current_state,
            event_audit_trail=self._event_audit_trail.copy(),
            checkpoint_name=checkpoint_name,
            description=description
        )
        
        self._checkpoints[checkpoint.checkpoint_id] = checkpoint
        
        self.logger.info(f"Created checkpoint {checkpoint_name} for year {simulation_year}")
        
        return checkpoint
    
    def get_state(self, simulation_year: int) -> Optional[SimulationState]:
        """Get state for specific year."""
        return self._states_by_year.get(simulation_year)
    
    def get_available_years(self) -> Set[int]:
        """Get set of years with available states."""
        return set(self._states_by_year.keys())
    
    def validate_workforce_continuity(
        self,
        year_from: int,
        year_to: int
    ) -> Tuple[bool, List[str]]:
        """
        Validate workforce continuity between years.
        
        Args:
            year_from: Source year
            year_to: Target year
            
        Returns:
            Tuple of (is_valid, list_of_issues)
        """
        issues = []
        
        if year_from not in self._states_by_year:
            issues.append(f"Source year {year_from} not found in state tracking")
            return False, issues
        
        if year_to not in self._states_by_year:
            issues.append(f"Target year {year_to} not found in state tracking")
            return False, issues
        
        from_state = self._states_by_year[year_from]
        to_state = self._states_by_year[year_to]
        
        # Validate workforce count consistency
        from_active = from_state.workforce_metrics.active_employees
        to_active = to_state.workforce_metrics.active_employees
        net_change = to_active - from_active
        
        # Expected change from events
        from_summary = from_state.event_summary
        to_summary = to_state.event_summary
        
        expected_hires = to_summary.hire_events - from_summary.hire_events
        expected_terminations = to_summary.termination_events - from_summary.termination_events
        expected_net_change = expected_hires - expected_terminations
        
        if abs(net_change - expected_net_change) > 0:
            issues.append(f"Workforce count inconsistency: actual net change {net_change}, expected {expected_net_change}")
        
        # Validate cost continuity
        from_cost = from_state.workforce_metrics.total_compensation_cost
        to_cost = to_state.workforce_metrics.total_compensation_cost
        
        if to_cost < from_cost and to_summary.merit_events == 0 and to_summary.promotion_events == 0:
            issues.append("Total compensation decreased without merit or promotion events")
        
        return len(issues) == 0, issues
    
    def _process_events_for_metrics(
        self,
        current_metrics: WorkforceMetrics,
        events: List[SimulationEvent]
    ) -> WorkforceMetrics:
        """Process events to calculate new workforce metrics."""
        # Count events by type
        hire_count = sum(1 for e in events if e.payload.event_type == 'hire')
        termination_count = sum(1 for e in events if e.payload.event_type == 'termination')
        promotion_count = sum(1 for e in events if e.payload.event_type == 'promotion')
        merit_count = sum(1 for e in events if e.payload.event_type == 'merit')
        
        # Calculate new workforce counts
        new_active = current_metrics.active_employees + hire_count - termination_count
        new_terminated = current_metrics.terminated_employees + termination_count
        new_hires_ytd = current_metrics.new_hires_ytd + hire_count
        new_terminations_ytd = current_metrics.terminations_ytd + termination_count
        
        # Estimate cost impact (simplified calculation)
        cost_impact = Decimal('0')
        for event in events:
            if hasattr(event.payload, 'compensation_amount') and event.payload.compensation_amount:
                if event.payload.event_type == 'hire':
                    cost_impact += Decimal(str(event.payload.compensation_amount))
                elif event.payload.event_type == 'termination':
                    cost_impact -= Decimal(str(event.payload.compensation_amount))
                elif event.payload.event_type in ['promotion', 'merit']:
                    if hasattr(event.payload, 'previous_compensation') and event.payload.previous_compensation:
                        cost_impact += (Decimal(str(event.payload.compensation_amount)) - 
                                      Decimal(str(event.payload.previous_compensation)))
        
        new_total_cost = current_metrics.total_compensation_cost + cost_impact
        new_avg_compensation = new_total_cost / Decimal(str(max(new_active, 1)))
        
        # Calculate growth rate
        if current_metrics.active_employees > 0:
            growth_rate = (Decimal(str(new_active)) - Decimal(str(current_metrics.active_employees))) / Decimal(str(current_metrics.active_employees))
        else:
            growth_rate = Decimal('0')
        
        return WorkforceMetrics(
            total_employees=new_active + new_terminated,
            active_employees=new_active,
            terminated_employees=new_terminated,
            new_hires_ytd=new_hires_ytd,
            terminations_ytd=new_terminations_ytd,
            total_compensation_cost=new_total_cost,
            average_compensation=new_avg_compensation,
            median_compensation=current_metrics.median_compensation,  # Simplified
            growth_rate_ytd=growth_rate,
            target_growth_rate=current_metrics.target_growth_rate,
            level_distribution=current_metrics.level_distribution.copy(),
            age_band_distribution=current_metrics.age_band_distribution.copy(),
            tenure_band_distribution=current_metrics.tenure_band_distribution.copy()
        )
    
    def _create_event_summary(
        self,
        events: List[SimulationEvent],
        start_time: datetime
    ) -> EventSummary:
        """Create summary of processed events."""
        # Count events by type
        hire_events = sum(1 for e in events if e.payload.event_type == 'hire')
        termination_events = sum(1 for e in events if e.payload.event_type == 'termination')
        promotion_events = sum(1 for e in events if e.payload.event_type == 'promotion')
        merit_events = sum(1 for e in events if e.payload.event_type == 'merit')
        eligibility_events = sum(1 for e in events if e.payload.event_type == 'eligibility')
        enrollment_events = sum(1 for e in events if e.payload.event_type == 'enrollment')
        
        # Calculate processing metrics
        duration = (datetime.utcnow() - start_time).total_seconds()
        events_per_second = Decimal(str(len(events))) / Decimal(str(max(duration, 0.001)))
        
        # Calculate cost impact
        total_cost_impact = Decimal('0')
        for event in events:
            if hasattr(event.payload, 'compensation_amount') and event.payload.compensation_amount:
                if event.payload.event_type == 'hire':
                    total_cost_impact += Decimal(str(event.payload.compensation_amount))
                elif event.payload.event_type in ['promotion', 'merit']:
                    if hasattr(event.payload, 'previous_compensation') and event.payload.previous_compensation:
                        total_cost_impact += (Decimal(str(event.payload.compensation_amount)) - 
                                            Decimal(str(event.payload.previous_compensation)))
        
        avg_cost_impact = total_cost_impact / Decimal(str(max(len(events), 1)))
        
        return EventSummary(
            hire_events=hire_events,
            termination_events=termination_events,
            promotion_events=promotion_events,
            merit_events=merit_events,
            eligibility_events=eligibility_events,
            enrollment_events=enrollment_events,
            total_events_processed=len(events),
            processing_duration_seconds=Decimal(str(duration)).quantize(Decimal('0.001')),
            events_per_second=events_per_second.quantize(Decimal('0.01')),
            total_cost_impact=total_cost_impact,
            average_cost_impact_per_event=avg_cost_impact
        )


class StatePersistence:
    """
    Checkpoint/resume functionality with compression and integrity verification.
    
    Provides enterprise-grade persistence for simulation states with:
    - Compressed checkpoint storage
    - Data integrity verification
    - Resume from checkpoint capability
    - Audit trail preservation
    """
    
    def __init__(
        self,
        storage_path: Path,
        enable_compression: bool = True,
        compression_level: int = 6
    ):
        """
        Initialize state persistence manager.
        
        Args:
            storage_path: Path for checkpoint storage
            enable_compression: Enable gzip compression
            compression_level: Compression level (1-9)
        """
        self.storage_path = Path(storage_path)
        self.enable_compression = enable_compression
        self.compression_level = compression_level
        
        # Ensure storage directory exists
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Initialized StatePersistence with storage at {storage_path}")
    
    def save_checkpoint(
        self,
        checkpoint: EventSourcingCheckpoint
    ) -> Path:
        """
        Save checkpoint to persistent storage.
        
        Args:
            checkpoint: Checkpoint to save
            
        Returns:
            Path to saved checkpoint file
        """
        checkpoint_filename = f"checkpoint_{checkpoint.simulation_state.simulation_year}_{checkpoint.checkpoint_id}.pkl"
        checkpoint_path = self.storage_path / checkpoint_filename
        
        try:
            # Serialize checkpoint
            checkpoint_data = checkpoint.model_dump()
            serialized_data = pickle.dumps(checkpoint_data)
            
            if self.enable_compression:
                # Compress data
                with gzip.open(checkpoint_path, 'wb', compresslevel=self.compression_level) as f:
                    f.write(serialized_data)
                
                # Update checkpoint with compression info
                compressed_size = checkpoint_path.stat().st_size
                checkpoint_data['compression_enabled'] = True
                checkpoint_data['compressed_size_bytes'] = compressed_size
            else:
                # Save uncompressed
                with open(checkpoint_path, 'wb') as f:
                    f.write(serialized_data)
            
            logger.info(f"Saved checkpoint {checkpoint.checkpoint_name} to {checkpoint_path}")
            
            return checkpoint_path
            
        except Exception as e:
            logger.error(f"Failed to save checkpoint {checkpoint.checkpoint_id}: {str(e)}")
            raise
    
    def load_checkpoint(
        self,
        checkpoint_path: Path
    ) -> EventSourcingCheckpoint:
        """
        Load checkpoint from persistent storage.
        
        Args:
            checkpoint_path: Path to checkpoint file
            
        Returns:
            Loaded EventSourcingCheckpoint
            
        Raises:
            FileNotFoundError: If checkpoint file not found
            ValueError: If checkpoint data is corrupted
        """
        if not checkpoint_path.exists():
            raise FileNotFoundError(f"Checkpoint file not found: {checkpoint_path}")
        
        try:
            # Determine if file is compressed
            is_compressed = checkpoint_path.suffix == '.gz' or self._is_gzip_file(checkpoint_path)
            
            if is_compressed:
                with gzip.open(checkpoint_path, 'rb') as f:
                    serialized_data = f.read()
            else:
                with open(checkpoint_path, 'rb') as f:
                    serialized_data = f.read()
            
            # Deserialize checkpoint
            checkpoint_data = pickle.loads(serialized_data)
            checkpoint = EventSourcingCheckpoint.model_validate(checkpoint_data)
            
            # Verify integrity
            is_valid, issues = checkpoint.verify_integrity()
            if not is_valid:
                raise ValueError(f"Checkpoint integrity verification failed: {issues}")
            
            logger.info(f"Loaded checkpoint {checkpoint.checkpoint_name} from {checkpoint_path}")
            
            return checkpoint
            
        except Exception as e:
            logger.error(f"Failed to load checkpoint from {checkpoint_path}: {str(e)}")
            raise
    
    def find_latest_checkpoint(
        self,
        simulation_year: int
    ) -> Optional[Path]:
        """
        Find the latest checkpoint for a simulation year.
        
        Args:
            simulation_year: Year to find checkpoint for
            
        Returns:
            Path to latest checkpoint file, or None if not found
        """
        pattern = f"checkpoint_{simulation_year}_*.pkl"
        checkpoint_files = list(self.storage_path.glob(pattern))
        
        if not checkpoint_files:
            return None
        
        # Sort by modification time, return latest
        latest_file = max(checkpoint_files, key=lambda p: p.stat().st_mtime)
        
        logger.info(f"Found latest checkpoint for year {simulation_year}: {latest_file}")
        
        return latest_file
    
    def cleanup_old_checkpoints(
        self,
        simulation_year: int,
        keep_latest: int = 3
    ) -> int:
        """
        Clean up old checkpoints, keeping only the most recent ones.
        
        Args:
            simulation_year: Year to clean up checkpoints for
            keep_latest: Number of latest checkpoints to keep
            
        Returns:
            Number of checkpoints removed
        """
        pattern = f"checkpoint_{simulation_year}_*.pkl"
        checkpoint_files = list(self.storage_path.glob(pattern))
        
        if len(checkpoint_files) <= keep_latest:
            return 0
        
        # Sort by modification time, keep latest N
        checkpoint_files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        files_to_remove = checkpoint_files[keep_latest:]
        
        removed_count = 0
        for file_path in files_to_remove:
            try:
                file_path.unlink()
                removed_count += 1
            except Exception as e:
                logger.warning(f"Failed to remove checkpoint file {file_path}: {str(e)}")
        
        logger.info(f"Cleaned up {removed_count} old checkpoints for year {simulation_year}")
        
        return removed_count
    
    def _is_gzip_file(self, file_path: Path) -> bool:
        """Check if file is gzip compressed by reading magic bytes."""
        try:
            with open(file_path, 'rb') as f:
                magic = f.read(2)
                return magic == b'\x1f\x8b'
        except Exception:
            return False


# Factory functions for easier instantiation
def create_initial_workforce_metrics(
    active_employees: int,
    total_compensation_cost: Decimal,
    target_growth_rate: Decimal = Decimal('0.03')
) -> WorkforceMetrics:
    """Create initial workforce metrics for simulation start."""
    avg_compensation = total_compensation_cost / Decimal(str(max(active_employees, 1)))
    
    return WorkforceMetrics(
        total_employees=active_employees,
        active_employees=active_employees,
        total_compensation_cost=total_compensation_cost,
        average_compensation=avg_compensation,
        median_compensation=avg_compensation,  # Simplified
        target_growth_rate=target_growth_rate
    )


def create_state_manager(
    scenario_id: str,
    plan_design_id: str,
    configuration: Dict[str, Any]
) -> WorkforceStateManager:
    """Create configured workforce state manager."""
    return WorkforceStateManager(
        scenario_id=scenario_id,
        plan_design_id=plan_design_id,
        configuration=configuration
    )


def create_persistence_manager(
    storage_path: Union[str, Path],
    enable_compression: bool = True
) -> StatePersistence:
    """Create configured state persistence manager."""
    return StatePersistence(
        storage_path=Path(storage_path),
        enable_compression=enable_compression
    )