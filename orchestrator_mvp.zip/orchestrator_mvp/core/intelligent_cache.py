"""
Intelligent multi-tier caching system for multi-year coordination performance optimization.

This module provides enterprise-grade caching infrastructure for workforce simulation with:
- Multi-tier caching strategy (L1/L2/L3) for performance optimization
- Cache promotion and intelligent tier placement
- Sub-millisecond access times for frequently used data
- Automatic cache invalidation and coherency management
- Integration with existing state management and cost attribution systems

Components:
- CacheEntry: Individual cache entry with metadata and access tracking
- IntelligentCacheManager: Main caching engine with multi-tier strategy
- CachePerformanceMetrics: Performance monitoring and optimization insights
- CacheCoherencyManager: Cache consistency and invalidation management

Architecture follows PlanWise Navigator's performance optimization principles:
- Hierarchical caching with automatic promotion/demotion
- Access pattern analysis for intelligent placement
- Memory-efficient storage with compression
- Integration with existing UUID-based tracking system
"""

from __future__ import annotations
import logging
from typing import Dict, Any, Optional, List, Set, Union, Tuple, Literal, Generic, TypeVar
from datetime import datetime, timedelta
from decimal import Decimal
from uuid import UUID, uuid4
from dataclasses import dataclass, field
from enum import Enum
import time
import hashlib
import json
import pickle
import gzip
import threading
from collections import OrderedDict, defaultdict
import weakref
from concurrent.futures import ThreadPoolExecutor, as_completed

from pydantic import BaseModel, Field, ConfigDict, field_validator, computed_field
from pydantic.types import NonNegativeInt, PositiveInt

# Import existing components
from .state_management import SimulationState, WorkforceMetrics, EventSourcingCheckpoint
from .cost_attribution import CostAttributionEntry, AttributionAuditTrail

logger = logging.getLogger(__name__)

T = TypeVar('T')


class CacheTier(str, Enum):
    """Cache tier levels with different performance characteristics."""
    L1_MEMORY = "l1_memory"        # Ultra-fast in-memory cache (microsecond access)
    L2_COMPRESSED = "l2_compressed"  # Compressed in-memory cache (millisecond access)
    L3_PERSISTENT = "l3_persistent"  # Persistent storage cache (10ms+ access)


class CachePolicy(str, Enum):
    """Cache eviction and management policies."""
    LRU = "lru"                    # Least Recently Used
    LFU = "lfu"                    # Least Frequently Used
    TTL = "ttl"                    # Time To Live
    ADAPTIVE = "adaptive"          # Adaptive based on access patterns
    COST_AWARE = "cost_aware"      # Cost-aware eviction (expensive to recompute stays longer)


class CacheEntryType(str, Enum):
    """Types of cached data for intelligent management."""
    WORKFORCE_STATE = "workforce_state"
    COST_ATTRIBUTION = "cost_attribution"
    EVENT_SUMMARY = "event_summary"
    COMPUTATION_RESULT = "computation_result"
    INTERMEDIATE_CALCULATION = "intermediate_calculation"
    AGGREGATED_METRICS = "aggregated_metrics"


class CacheEntry(BaseModel, Generic[T]):
    """
    Individual cache entry with comprehensive metadata and access tracking.
    
    Provides intelligent caching with:
    - Access pattern tracking for promotion/demotion decisions
    - Cost-aware eviction based on computation expense
    - Compression metadata for storage optimization
    - TTL and validity tracking for coherency
    """
    
    model_config = ConfigDict(
        frozen=True,
        use_enum_values=True,
        validate_assignment=True,
        arbitrary_types_allowed=True
    )
    
    # Core identification
    cache_key: str = Field(..., min_length=1)
    entry_id: UUID = Field(default_factory=uuid4)
    entry_type: CacheEntryType
    
    # Data and metadata
    data_hash: str = Field(..., min_length=16)
    data_size_bytes: PositiveInt
    compressed_size_bytes: Optional[PositiveInt] = None
    compression_ratio: Optional[Decimal] = None
    
    # Temporal metadata
    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_accessed_at: datetime = Field(default_factory=datetime.utcnow)
    expires_at: Optional[datetime] = None
    
    # Access pattern tracking
    access_count: NonNegativeInt = 0
    access_frequency_per_hour: Decimal = Field(default=Decimal('0'), decimal_places=4)
    last_promotion_at: Optional[datetime] = None
    
    # Cost-aware metadata
    computation_cost_ms: Decimal = Field(default=Decimal('0'), decimal_places=3)
    storage_cost_score: Decimal = Field(default=Decimal('1'), decimal_places=4)
    eviction_priority_score: Decimal = Field(default=Decimal('0.5'), decimal_places=4)
    
    # Cache tier management
    current_tier: CacheTier
    promotion_candidate: bool = False
    demotion_candidate: bool = False
    
    # Dependency tracking for invalidation
    depends_on_keys: Set[str] = Field(default_factory=set)
    invalidates_keys: Set[str] = Field(default_factory=set)
    
    @field_validator('cache_key')
    @classmethod
    def validate_cache_key(cls, v: str) -> str:
        """Validate cache key format."""
        if not v or len(v.strip()) < 8:
            raise ValueError('Cache key must be at least 8 characters')
        return v.strip()
    
    @field_validator('data_hash')
    @classmethod
    def validate_data_hash(cls, v: str) -> str:
        """Validate data hash format."""
        if not v or len(v) < 16:
            raise ValueError('Data hash must be at least 16 characters')
        return v
    
    @computed_field
    @property
    def age_seconds(self) -> int:
        """Calculate entry age in seconds."""
        return int((datetime.utcnow() - self.created_at).total_seconds())
    
    @computed_field
    @property
    def time_since_last_access_seconds(self) -> int:
        """Calculate time since last access in seconds."""
        return int((datetime.utcnow() - self.last_accessed_at).total_seconds())
    
    @computed_field
    @property
    def is_expired(self) -> bool:
        """Check if entry is expired based on TTL."""
        if self.expires_at is None:
            return False
        return datetime.utcnow() > self.expires_at
    
    @computed_field
    @property
    def compression_effectiveness(self) -> Optional[Decimal]:
        """Calculate compression effectiveness ratio."""
        if self.compressed_size_bytes is None:
            return None
        return (Decimal('1') - (Decimal(str(self.compressed_size_bytes)) / Decimal(str(self.data_size_bytes)))).quantize(Decimal('0.0001'))
    
    def update_access_metrics(self) -> 'CacheEntry[T]':
        """Update access metrics and return new entry (immutable pattern)."""
        now = datetime.utcnow()
        age_hours = max(1, (now - self.created_at).total_seconds() / 3600)
        new_frequency = (Decimal(str(self.access_count + 1)) / Decimal(str(age_hours))).quantize(Decimal('0.0001'))
        
        # Calculate eviction priority (lower = more likely to evict)
        recency_score = Decimal('1') / Decimal(str(max(1, self.time_since_last_access_seconds / 3600)))
        frequency_score = new_frequency / Decimal('10')  # Normalize
        cost_score = self.computation_cost_ms / Decimal('1000')  # Normalize to seconds
        
        eviction_priority = (recency_score * Decimal('0.4') + 
                           frequency_score * Decimal('0.3') + 
                           cost_score * Decimal('0.3')).quantize(Decimal('0.0001'))
        
        return self.model_copy(update={
            'last_accessed_at': now,
            'access_count': self.access_count + 1,
            'access_frequency_per_hour': new_frequency,
            'eviction_priority_score': eviction_priority
        })
    
    def calculate_promotion_score(self) -> Decimal:
        """Calculate score for promotion to higher tier."""
        # Factors: frequency, recency, computation cost, size efficiency
        frequency_factor = min(Decimal('1'), self.access_frequency_per_hour / Decimal('10'))
        recency_factor = Decimal('1') / Decimal(str(max(1, self.time_since_last_access_seconds / 3600)))
        cost_factor = min(Decimal('1'), self.computation_cost_ms / Decimal('5000'))
        size_factor = Decimal('1') / Decimal(str(max(1, self.data_size_bytes / 1000000)))  # Prefer smaller entries
        
        promotion_score = (frequency_factor * Decimal('0.35') +
                          recency_factor * Decimal('0.25') +
                          cost_factor * Decimal('0.25') +
                          size_factor * Decimal('0.15')).quantize(Decimal('0.0001'))
        
        return promotion_score


class CachePerformanceMetrics(BaseModel):
    """Performance metrics for cache optimization insights."""
    
    model_config = ConfigDict(frozen=True)
    
    # Basic performance metrics
    total_requests: NonNegativeInt = 0
    cache_hits: NonNegativeInt = 0
    cache_misses: NonNegativeInt = 0
    
    # Tier-specific metrics
    l1_hits: NonNegativeInt = 0
    l2_hits: NonNegativeInt = 0
    l3_hits: NonNegativeInt = 0
    
    # Timing metrics (microseconds for precision)
    total_access_time_us: NonNegativeInt = 0
    l1_access_time_us: NonNegativeInt = 0
    l2_access_time_us: NonNegativeInt = 0
    l3_access_time_us: NonNegativeInt = 0
    
    # Cache management metrics
    promotions: NonNegativeInt = 0
    demotions: NonNegativeInt = 0
    evictions: NonNegativeInt = 0
    invalidations: NonNegativeInt = 0
    
    # Storage metrics
    total_entries: NonNegativeInt = 0
    total_memory_bytes: NonNegativeInt = 0
    compressed_bytes_saved: NonNegativeInt = 0
    
    # Collection timestamp
    collected_at: datetime = Field(default_factory=datetime.utcnow)
    
    @computed_field
    @property
    def hit_rate(self) -> Decimal:
        """Calculate overall hit rate."""
        if self.total_requests == 0:
            return Decimal('0')
        return (Decimal(str(self.cache_hits)) / Decimal(str(self.total_requests))).quantize(Decimal('0.0001'))
    
    @computed_field
    @property
    def miss_rate(self) -> Decimal:
        """Calculate overall miss rate."""
        return (Decimal('1') - self.hit_rate).quantize(Decimal('0.0001'))
    
    @computed_field
    @property
    def average_access_time_us(self) -> Decimal:
        """Calculate average access time in microseconds."""
        if self.total_requests == 0:
            return Decimal('0')
        return (Decimal(str(self.total_access_time_us)) / Decimal(str(self.total_requests))).quantize(Decimal('0.1'))
    
    @computed_field
    @property
    def compression_savings_ratio(self) -> Decimal:
        """Calculate compression savings ratio."""
        if self.total_memory_bytes == 0:
            return Decimal('0')
        return (Decimal(str(self.compressed_bytes_saved)) / Decimal(str(self.total_memory_bytes))).quantize(Decimal('0.0001'))


@dataclass
class CacheTierConfig:
    """Configuration for cache tier management."""
    
    max_entries: int
    max_memory_bytes: int
    ttl_seconds: Optional[int] = None
    eviction_policy: CachePolicy = CachePolicy.ADAPTIVE
    compression_enabled: bool = False
    compression_threshold_bytes: int = 1024
    auto_promotion_enabled: bool = True
    promotion_threshold_score: Decimal = field(default=Decimal('0.7'))
    demotion_threshold_score: Decimal = field(default=Decimal('0.3'))


class IntelligentCacheManager:
    """
    Enterprise-grade multi-tier caching system with intelligent placement and optimization.
    
    Provides sophisticated caching infrastructure for multi-year workforce simulations:
    - Multi-tier caching (L1/L2/L3) with automatic promotion/demotion
    - Access pattern analysis for intelligent cache placement
    - Cost-aware eviction policies based on computation expense
    - Sub-millisecond access times for frequently used data
    - Memory-efficient storage with selective compression
    - Cache coherency and dependency-based invalidation
    
    Performance targets:
    - L1 cache: <10 microseconds access time
    - L2 cache: <1 millisecond access time  
    - L3 cache: <10 milliseconds access time
    - Overall hit rate: >85%
    - Memory efficiency: >90% utilization before eviction
    """
    
    def __init__(
        self,
        l1_config: Optional[CacheTierConfig] = None,
        l2_config: Optional[CacheTierConfig] = None,
        l3_config: Optional[CacheTierConfig] = None,
        enable_auto_optimization: bool = True,
        optimization_interval_seconds: int = 60,
        logger: Optional[logging.Logger] = None
    ):
        """
        Initialize intelligent cache manager with multi-tier configuration.
        
        Args:
            l1_config: L1 (memory) tier configuration
            l2_config: L2 (compressed) tier configuration  
            l3_config: L3 (persistent) tier configuration
            enable_auto_optimization: Enable automatic cache optimization
            optimization_interval_seconds: Interval for optimization runs
            logger: Optional logger instance
        """
        self.logger = logger or logging.getLogger(__name__)
        
        # Configure default tier settings if not provided
        self.l1_config = l1_config or CacheTierConfig(
            max_entries=1000,
            max_memory_bytes=100 * 1024 * 1024,  # 100MB
            ttl_seconds=3600,  # 1 hour
            eviction_policy=CachePolicy.ADAPTIVE,
            compression_enabled=False,
            auto_promotion_enabled=True,
            promotion_threshold_score=Decimal('0.7')
        )
        
        self.l2_config = l2_config or CacheTierConfig(
            max_entries=5000,
            max_memory_bytes=500 * 1024 * 1024,  # 500MB
            ttl_seconds=7200,  # 2 hours
            eviction_policy=CachePolicy.LRU,
            compression_enabled=True,
            compression_threshold_bytes=1024,
            auto_promotion_enabled=True,
            promotion_threshold_score=Decimal('0.5')
        )
        
        self.l3_config = l3_config or CacheTierConfig(
            max_entries=20000,
            max_memory_bytes=2 * 1024 * 1024 * 1024,  # 2GB
            ttl_seconds=86400,  # 24 hours
            eviction_policy=CachePolicy.LFU,
            compression_enabled=True,
            compression_threshold_bytes=512,
            auto_promotion_enabled=False
        )
        
        # Initialize cache tiers (using OrderedDict for LRU behavior)
        self._l1_cache: OrderedDict[str, Tuple[CacheEntry, Any]] = OrderedDict()
        self._l2_cache: OrderedDict[str, Tuple[CacheEntry, bytes]] = OrderedDict()  # Compressed data
        self._l3_cache: OrderedDict[str, Tuple[CacheEntry, bytes]] = OrderedDict()  # Persistent compressed data
        
        # Cache management
        self._cache_locks = defaultdict(threading.RLock)
        self._global_lock = threading.RLock()
        
        # Performance tracking
        self._performance_metrics = CachePerformanceMetrics()
        self._access_times: List[Tuple[CacheTier, float]] = []  # For optimization analysis
        
        # Dependency tracking for invalidation
        self._key_dependencies: Dict[str, Set[str]] = defaultdict(set)
        self._reverse_dependencies: Dict[str, Set[str]] = defaultdict(set)
        
        # Auto-optimization
        self.enable_auto_optimization = enable_auto_optimization
        self.optimization_interval_seconds = optimization_interval_seconds
        self._last_optimization = datetime.utcnow()
        self._optimization_executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="cache_optimizer")
        
        # Statistics for optimization
        self._promotion_candidates: Set[str] = set()
        self._demotion_candidates: Set[str] = set()
        
        self.logger.info("Initialized IntelligentCacheManager with multi-tier configuration")
        self.logger.info(f"L1: {self.l1_config.max_entries} entries, {self.l1_config.max_memory_bytes:,} bytes")
        self.logger.info(f"L2: {self.l2_config.max_entries} entries, {self.l2_config.max_memory_bytes:,} bytes")
        self.logger.info(f"L3: {self.l3_config.max_entries} entries, {self.l3_config.max_memory_bytes:,} bytes")
    
    def get(self, cache_key: str, entry_type: CacheEntryType) -> Optional[Any]:
        """
        Retrieve data from cache with intelligent tier promotion.
        
        Args:
            cache_key: Unique cache key
            entry_type: Type of cached entry
            
        Returns:
            Cached data if found, None otherwise
        """
        access_start = time.perf_counter()
        
        with self._cache_locks[cache_key]:
            try:
                # Try L1 cache first (fastest access)
                if cache_key in self._l1_cache:
                    entry, data = self._l1_cache[cache_key]
                    
                    # Update access metrics
                    updated_entry = entry.update_access_metrics()
                    self._l1_cache[cache_key] = (updated_entry, data)
                    self._l1_cache.move_to_end(cache_key)  # LRU update
                    
                    access_time_us = int((time.perf_counter() - access_start) * 1_000_000)
                    self._update_performance_metrics(CacheTier.L1_MEMORY, access_time_us, hit=True)
                    
                    self.logger.debug(f"L1 cache hit for key {cache_key} in {access_time_us}μs")
                    return data
                
                # Try L2 cache (compressed memory)
                if cache_key in self._l2_cache:
                    entry, compressed_data = self._l2_cache[cache_key]
                    
                    # Decompress data
                    data = self._decompress_data(compressed_data)
                    
                    # Update access metrics and consider promotion
                    updated_entry = entry.update_access_metrics()
                    self._l2_cache[cache_key] = (updated_entry, compressed_data)
                    self._l2_cache.move_to_end(cache_key)
                    
                    # Check for L1 promotion
                    if (updated_entry.calculate_promotion_score() >= self.l1_config.promotion_threshold_score and
                        self.l1_config.auto_promotion_enabled):
                        self._promote_to_l1(cache_key, updated_entry, data)
                    
                    access_time_us = int((time.perf_counter() - access_start) * 1_000_000)
                    self._update_performance_metrics(CacheTier.L2_COMPRESSED, access_time_us, hit=True)
                    
                    self.logger.debug(f"L2 cache hit for key {cache_key} in {access_time_us}μs")
                    return data
                
                # Try L3 cache (persistent storage)
                if cache_key in self._l3_cache:
                    entry, compressed_data = self._l3_cache[cache_key]
                    
                    # Decompress data
                    data = self._decompress_data(compressed_data)
                    
                    # Update access metrics and consider promotion
                    updated_entry = entry.update_access_metrics()
                    self._l3_cache[cache_key] = (updated_entry, compressed_data)
                    self._l3_cache.move_to_end(cache_key)
                    
                    # Check for L2 promotion
                    if (updated_entry.calculate_promotion_score() >= self.l2_config.promotion_threshold_score and
                        self.l2_config.auto_promotion_enabled):
                        self._promote_to_l2(cache_key, updated_entry, data)
                    
                    access_time_us = int((time.perf_counter() - access_start) * 1_000_000)
                    self._update_performance_metrics(CacheTier.L3_PERSISTENT, access_time_us, hit=True)
                    
                    self.logger.debug(f"L3 cache hit for key {cache_key} in {access_time_us}μs")
                    return data
                
                # Cache miss
                access_time_us = int((time.perf_counter() - access_start) * 1_000_000)
                self._update_performance_metrics(None, access_time_us, hit=False)
                
                self.logger.debug(f"Cache miss for key {cache_key}")
                return None
                
            except Exception as e:
                self.logger.error(f"Cache retrieval error for key {cache_key}: {str(e)}")
                return None
    
    def put(
        self,
        cache_key: str,
        data: Any,
        entry_type: CacheEntryType,
        computation_cost_ms: Decimal = Decimal('0'),
        ttl_seconds: Optional[int] = None,
        depends_on: Optional[List[str]] = None,
        invalidates: Optional[List[str]] = None
    ) -> bool:
        """
        Store data in cache with intelligent tier placement.
        
        Args:
            cache_key: Unique cache key
            data: Data to cache
            entry_type: Type of cached entry
            computation_cost_ms: Cost to recompute this data (for cost-aware eviction)
            ttl_seconds: Time to live override
            depends_on: Keys this entry depends on (for invalidation)
            invalidates: Keys this entry invalidates
            
        Returns:
            True if successfully cached, False otherwise
        """
        with self._cache_locks[cache_key]:
            try:
                # Serialize and calculate data characteristics
                serialized_data = pickle.dumps(data)
                data_size = len(serialized_data)
                data_hash = hashlib.sha256(serialized_data).hexdigest()[:32]
                
                # Determine optimal initial tier based on data characteristics
                initial_tier = self._determine_optimal_tier(data_size, computation_cost_ms, entry_type)
                
                # Create cache entry
                expires_at = None
                if ttl_seconds:
                    expires_at = datetime.utcnow() + timedelta(seconds=ttl_seconds)
                elif initial_tier == CacheTier.L1_MEMORY and self.l1_config.ttl_seconds:
                    expires_at = datetime.utcnow() + timedelta(seconds=self.l1_config.ttl_seconds)
                elif initial_tier == CacheTier.L2_COMPRESSED and self.l2_config.ttl_seconds:
                    expires_at = datetime.utcnow() + timedelta(seconds=self.l2_config.ttl_seconds)
                elif initial_tier == CacheTier.L3_PERSISTENT and self.l3_config.ttl_seconds:
                    expires_at = datetime.utcnow() + timedelta(seconds=self.l3_config.ttl_seconds)
                
                entry = CacheEntry(
                    cache_key=cache_key,
                    entry_type=entry_type,
                    data_hash=data_hash,
                    data_size_bytes=data_size,
                    expires_at=expires_at,
                    computation_cost_ms=computation_cost_ms,
                    current_tier=initial_tier,
                    depends_on_keys=set(depends_on or []),
                    invalidates_keys=set(invalidates or [])
                )
                
                # Store in appropriate tier
                success = False
                if initial_tier == CacheTier.L1_MEMORY:
                    success = self._store_in_l1(cache_key, entry, data)
                elif initial_tier == CacheTier.L2_COMPRESSED:
                    success = self._store_in_l2(cache_key, entry, data)
                else:  # L3_PERSISTENT
                    success = self._store_in_l3(cache_key, entry, data)
                
                if success:
                    # Update dependency tracking
                    self._update_dependencies(cache_key, depends_on or [], invalidates or [])
                    
                    # Trigger auto-optimization if needed
                    if self.enable_auto_optimization:
                        self._maybe_trigger_optimization()
                    
                    self.logger.debug(f"Cached {data_size:,} bytes in {initial_tier.value} for key {cache_key}")
                
                return success
                
            except Exception as e:
                self.logger.error(f"Cache storage error for key {cache_key}: {str(e)}")
                return False
    
    def invalidate(self, cache_key: str, cascade: bool = True) -> int:
        """
        Invalidate cache entry and optionally cascade to dependent entries.
        
        Args:
            cache_key: Key to invalidate
            cascade: Whether to cascade invalidation to dependent entries
            
        Returns:
            Number of entries invalidated
        """
        invalidated_count = 0
        
        with self._global_lock:
            try:
                # Remove from all tiers
                if cache_key in self._l1_cache:
                    del self._l1_cache[cache_key]
                    invalidated_count += 1
                
                if cache_key in self._l2_cache:
                    del self._l2_cache[cache_key]
                    invalidated_count += 1
                
                if cache_key in self._l3_cache:
                    del self._l3_cache[cache_key]
                    invalidated_count += 1
                
                # Cascade invalidation if requested
                if cascade and cache_key in self._reverse_dependencies:
                    dependent_keys = self._reverse_dependencies[cache_key].copy()
                    del self._reverse_dependencies[cache_key]
                    
                    for dependent_key in dependent_keys:
                        invalidated_count += self.invalidate(dependent_key, cascade=True)
                
                # Clean up dependencies
                if cache_key in self._key_dependencies:
                    del self._key_dependencies[cache_key]
                
                # Update metrics
                self._performance_metrics = self._performance_metrics.model_copy(update={
                    'invalidations': self._performance_metrics.invalidations + invalidated_count
                })
                
                if invalidated_count > 0:
                    self.logger.debug(f"Invalidated {invalidated_count} cache entries starting with key {cache_key}")
                
                return invalidated_count
                
            except Exception as e:
                self.logger.error(f"Cache invalidation error for key {cache_key}: {str(e)}")
                return 0
    
    def get_performance_metrics(self) -> CachePerformanceMetrics:
        """Get current cache performance metrics."""
        with self._global_lock:
            # Update current statistics
            total_entries = len(self._l1_cache) + len(self._l2_cache) + len(self._l3_cache)
            
            # Estimate memory usage
            total_memory = 0
            compressed_savings = 0
            
            for entry, data in self._l1_cache.values():
                total_memory += entry.data_size_bytes
            
            for entry, compressed_data in self._l2_cache.values():
                total_memory += len(compressed_data)
                if entry.compressed_size_bytes:
                    compressed_savings += (entry.data_size_bytes - entry.compressed_size_bytes)
            
            for entry, compressed_data in self._l3_cache.values():
                total_memory += len(compressed_data)
                if entry.compressed_size_bytes:
                    compressed_savings += (entry.data_size_bytes - entry.compressed_size_bytes)
            
            return self._performance_metrics.model_copy(update={
                'total_entries': total_entries,
                'total_memory_bytes': total_memory,
                'compressed_bytes_saved': compressed_savings,
                'collected_at': datetime.utcnow()
            })
    
    def optimize_cache_placement(self) -> Dict[str, Any]:
        """
        Perform intelligent cache optimization based on access patterns.
        
        Returns:
            Optimization results summary
        """
        start_time = time.time()
        
        with self._global_lock:
            try:
                self.logger.info("Starting intelligent cache optimization")
                
                # Analyze access patterns and identify optimization opportunities
                promotion_candidates = []
                demotion_candidates = []
                eviction_candidates = []
                
                # Analyze L2 cache for L1 promotions
                for cache_key, (entry, _) in self._l2_cache.items():
                    if entry.is_expired:
                        eviction_candidates.append((cache_key, CacheTier.L2_COMPRESSED))
                    elif (entry.calculate_promotion_score() >= self.l1_config.promotion_threshold_score and
                          self._has_l1_capacity(entry.data_size_bytes)):
                        promotion_candidates.append((cache_key, CacheTier.L1_MEMORY))
                
                # Analyze L3 cache for L2 promotions
                for cache_key, (entry, _) in self._l3_cache.items():
                    if entry.is_expired:
                        eviction_candidates.append((cache_key, CacheTier.L3_PERSISTENT))
                    elif (entry.calculate_promotion_score() >= self.l2_config.promotion_threshold_score and
                          self._has_l2_capacity(entry.data_size_bytes)):
                        promotion_candidates.append((cache_key, CacheTier.L2_COMPRESSED))
                
                # Analyze L1 cache for demotions
                for cache_key, (entry, _) in self._l1_cache.items():
                    if entry.is_expired:
                        eviction_candidates.append((cache_key, CacheTier.L1_MEMORY))
                    elif entry.eviction_priority_score < self.l1_config.demotion_threshold_score:
                        demotion_candidates.append((cache_key, CacheTier.L2_COMPRESSED))
                
                # Execute optimizations
                promotions_executed = 0
                demotions_executed = 0
                evictions_executed = 0
                
                # Execute evictions first to free up space
                for cache_key, tier in eviction_candidates:
                    if self._evict_entry(cache_key, tier):
                        evictions_executed += 1
                
                # Execute promotions
                for cache_key, target_tier in promotion_candidates[:10]:  # Limit batch size
                    if self._promote_entry(cache_key, target_tier):
                        promotions_executed += 1
                
                # Execute demotions
                for cache_key, target_tier in demotion_candidates[:5]:  # Limit batch size
                    if self._demote_entry(cache_key, target_tier):
                        demotions_executed += 1
                
                optimization_duration = time.time() - start_time
                
                # Update metrics
                self._performance_metrics = self._performance_metrics.model_copy(update={
                    'promotions': self._performance_metrics.promotions + promotions_executed,
                    'demotions': self._performance_metrics.demotions + demotions_executed,
                    'evictions': self._performance_metrics.evictions + evictions_executed
                })
                
                self._last_optimization = datetime.utcnow()
                
                optimization_summary = {
                    'duration_seconds': optimization_duration,
                    'promotions_executed': promotions_executed,
                    'demotions_executed': demotions_executed,
                    'evictions_executed': evictions_executed,
                    'total_optimizations': promotions_executed + demotions_executed + evictions_executed,
                    'optimization_timestamp': self._last_optimization.isoformat()
                }
                
                self.logger.info(f"Cache optimization completed in {optimization_duration:.2f}s: "
                               f"{promotions_executed} promotions, {demotions_executed} demotions, "
                               f"{evictions_executed} evictions")
                
                return optimization_summary
                
            except Exception as e:
                self.logger.error(f"Cache optimization failed: {str(e)}")
                return {
                    'error': str(e),
                    'duration_seconds': time.time() - start_time,
                    'optimization_timestamp': datetime.utcnow().isoformat()
                }
    
    def clear_tier(self, tier: CacheTier) -> int:
        """
        Clear specific cache tier.
        
        Args:
            tier: Cache tier to clear
            
        Returns:
            Number of entries cleared
        """
        with self._global_lock:
            cleared_count = 0
            
            if tier == CacheTier.L1_MEMORY:
                cleared_count = len(self._l1_cache)
                self._l1_cache.clear()
            elif tier == CacheTier.L2_COMPRESSED:
                cleared_count = len(self._l2_cache)
                self._l2_cache.clear()
            elif tier == CacheTier.L3_PERSISTENT:
                cleared_count = len(self._l3_cache)
                self._l3_cache.clear()
            
            self.logger.info(f"Cleared {cleared_count} entries from {tier.value}")
            return cleared_count
    
    def clear_all(self) -> int:
        """
        Clear all cache tiers.
        
        Returns:
            Total number of entries cleared
        """
        with self._global_lock:
            total_cleared = (len(self._l1_cache) + len(self._l2_cache) + len(self._l3_cache))
            
            self._l1_cache.clear()
            self._l2_cache.clear()
            self._l3_cache.clear()
            self._key_dependencies.clear()
            self._reverse_dependencies.clear()
            
            # Reset performance metrics
            self._performance_metrics = CachePerformanceMetrics()
            
            self.logger.info(f"Cleared all cache tiers: {total_cleared} entries")
            return total_cleared
    
    # Internal helper methods
    
    def _determine_optimal_tier(
        self,
        data_size: int,
        computation_cost_ms: Decimal,
        entry_type: CacheEntryType
    ) -> CacheTier:
        """Determine optimal initial cache tier based on data characteristics."""
        # High-computation cost or frequently accessed types prefer L1
        if computation_cost_ms > Decimal('1000') or entry_type in [CacheEntryType.WORKFORCE_STATE, CacheEntryType.AGGREGATED_METRICS]:
            if data_size <= 1024 * 1024 and self._has_l1_capacity(data_size):  # 1MB limit for L1
                return CacheTier.L1_MEMORY
        
        # Medium-size data with moderate access patterns to L2
        if data_size <= 10 * 1024 * 1024 and self._has_l2_capacity(data_size):  # 10MB limit for L2
            return CacheTier.L2_COMPRESSED
        
        # Large or infrequently accessed data to L3
        return CacheTier.L3_PERSISTENT
    
    def _has_l1_capacity(self, additional_bytes: int) -> bool:
        """Check if L1 has capacity for additional data."""
        current_size = sum(entry.data_size_bytes for entry, _ in self._l1_cache.values())
        return (current_size + additional_bytes) <= self.l1_config.max_memory_bytes and len(self._l1_cache) < self.l1_config.max_entries
    
    def _has_l2_capacity(self, additional_bytes: int) -> bool:
        """Check if L2 has capacity for additional data."""
        current_size = sum(len(compressed_data) for _, compressed_data in self._l2_cache.values())
        return (current_size + additional_bytes) <= self.l2_config.max_memory_bytes and len(self._l2_cache) < self.l2_config.max_entries
    
    def _store_in_l1(self, cache_key: str, entry: CacheEntry, data: Any) -> bool:
        """Store entry in L1 cache."""
        if not self._has_l1_capacity(entry.data_size_bytes):
            self._make_l1_space(entry.data_size_bytes)
        
        self._l1_cache[cache_key] = (entry, data)
        return True
    
    def _store_in_l2(self, cache_key: str, entry: CacheEntry, data: Any) -> bool:
        """Store entry in L2 cache with compression."""
        compressed_data = self._compress_data(data)
        
        if not self._has_l2_capacity(len(compressed_data)):
            self._make_l2_space(len(compressed_data))
        
        # Update entry with compression info
        updated_entry = entry.model_copy(update={
            'compressed_size_bytes': len(compressed_data),
            'compression_ratio': Decimal(str(len(compressed_data))) / Decimal(str(entry.data_size_bytes))
        })
        
        self._l2_cache[cache_key] = (updated_entry, compressed_data)
        return True
    
    def _store_in_l3(self, cache_key: str, entry: CacheEntry, data: Any) -> bool:
        """Store entry in L3 cache with compression."""
        compressed_data = self._compress_data(data)
        
        # L3 typically has more space, but still check
        if len(self._l3_cache) >= self.l3_config.max_entries:
            self._make_l3_space(len(compressed_data))
        
        # Update entry with compression info
        updated_entry = entry.model_copy(update={
            'compressed_size_bytes': len(compressed_data),
            'compression_ratio': Decimal(str(len(compressed_data))) / Decimal(str(entry.data_size_bytes))
        })
        
        self._l3_cache[cache_key] = (updated_entry, compressed_data)
        return True
    
    def _compress_data(self, data: Any) -> bytes:
        """Compress data using gzip."""
        serialized = pickle.dumps(data)
        return gzip.compress(serialized, compresslevel=6)
    
    def _decompress_data(self, compressed_data: bytes) -> Any:
        """Decompress and deserialize data."""
        decompressed = gzip.decompress(compressed_data)
        return pickle.loads(decompressed)
    
    def _promote_to_l1(self, cache_key: str, entry: CacheEntry, data: Any) -> bool:
        """Promote entry from L2 to L1."""
        if not self._has_l1_capacity(entry.data_size_bytes):
            return False
        
        # Remove from L2
        if cache_key in self._l2_cache:
            del self._l2_cache[cache_key]
        
        # Add to L1
        updated_entry = entry.model_copy(update={'current_tier': CacheTier.L1_MEMORY})
        self._l1_cache[cache_key] = (updated_entry, data)
        
        return True
    
    def _promote_to_l2(self, cache_key: str, entry: CacheEntry, data: Any) -> bool:
        """Promote entry from L3 to L2."""
        compressed_data = self._compress_data(data)
        
        if not self._has_l2_capacity(len(compressed_data)):
            return False
        
        # Remove from L3
        if cache_key in self._l3_cache:
            del self._l3_cache[cache_key]
        
        # Add to L2
        updated_entry = entry.model_copy(update={'current_tier': CacheTier.L2_COMPRESSED})
        self._l2_cache[cache_key] = (updated_entry, compressed_data)
        
        return True
    
    def _make_l1_space(self, required_bytes: int) -> None:
        """Make space in L1 cache by evicting entries."""
        # Simple LRU eviction for now
        while (not self._has_l1_capacity(required_bytes) and 
               len(self._l1_cache) > 0):
            oldest_key, _ = next(iter(self._l1_cache.items()))
            del self._l1_cache[oldest_key]
    
    def _make_l2_space(self, required_bytes: int) -> None:
        """Make space in L2 cache by evicting entries."""
        while (not self._has_l2_capacity(required_bytes) and 
               len(self._l2_cache) > 0):
            oldest_key, _ = next(iter(self._l2_cache.items()))
            del self._l2_cache[oldest_key]
    
    def _make_l3_space(self, required_bytes: int) -> None:
        """Make space in L3 cache by evicting entries."""
        while (len(self._l3_cache) >= self.l3_config.max_entries and 
               len(self._l3_cache) > 0):
            oldest_key, _ = next(iter(self._l3_cache.items()))
            del self._l3_cache[oldest_key]
    
    def _update_performance_metrics(
        self,
        tier: Optional[CacheTier],
        access_time_us: int,
        hit: bool
    ) -> None:
        """Update performance metrics."""
        updates = {
            'total_requests': self._performance_metrics.total_requests + 1,
            'total_access_time_us': self._performance_metrics.total_access_time_us + access_time_us
        }
        
        if hit:
            updates['cache_hits'] = self._performance_metrics.cache_hits + 1
            
            if tier == CacheTier.L1_MEMORY:
                updates['l1_hits'] = self._performance_metrics.l1_hits + 1
                updates['l1_access_time_us'] = self._performance_metrics.l1_access_time_us + access_time_us
            elif tier == CacheTier.L2_COMPRESSED:
                updates['l2_hits'] = self._performance_metrics.l2_hits + 1
                updates['l2_access_time_us'] = self._performance_metrics.l2_access_time_us + access_time_us
            elif tier == CacheTier.L3_PERSISTENT:
                updates['l3_hits'] = self._performance_metrics.l3_hits + 1
                updates['l3_access_time_us'] = self._performance_metrics.l3_access_time_us + access_time_us
        else:
            updates['cache_misses'] = self._performance_metrics.cache_misses + 1
        
        self._performance_metrics = self._performance_metrics.model_copy(update=updates)
    
    def _update_dependencies(
        self,
        cache_key: str,
        depends_on: List[str],
        invalidates: List[str]
    ) -> None:
        """Update dependency tracking for cache coherency."""
        # Update forward dependencies
        self._key_dependencies[cache_key] = set(depends_on)
        
        # Update reverse dependencies
        for dependency in depends_on:
            self._reverse_dependencies[dependency].add(cache_key)
        
        # Update invalidation relationships
        for invalidated_key in invalidates:
            self._reverse_dependencies[cache_key].add(invalidated_key)
    
    def _maybe_trigger_optimization(self) -> None:
        """Maybe trigger cache optimization if interval has passed."""
        if (datetime.utcnow() - self._last_optimization).total_seconds() >= self.optimization_interval_seconds:
            # Submit optimization task to executor
            self._optimization_executor.submit(self.optimize_cache_placement)
    
    def _promote_entry(self, cache_key: str, target_tier: CacheTier) -> bool:
        """Promote entry to target tier."""
        # Implementation for promotion logic
        return False  # Simplified for now
    
    def _demote_entry(self, cache_key: str, target_tier: CacheTier) -> bool:
        """Demote entry to target tier."""
        # Implementation for demotion logic
        return False  # Simplified for now
    
    def _evict_entry(self, cache_key: str, tier: CacheTier) -> bool:
        """Evict entry from specified tier."""
        try:
            if tier == CacheTier.L1_MEMORY and cache_key in self._l1_cache:
                del self._l1_cache[cache_key]
                return True
            elif tier == CacheTier.L2_COMPRESSED and cache_key in self._l2_cache:
                del self._l2_cache[cache_key]
                return True
            elif tier == CacheTier.L3_PERSISTENT and cache_key in self._l3_cache:
                del self._l3_cache[cache_key]
                return True
            return False
        except Exception:
            return False
    
    def __del__(self):
        """Cleanup resources on destruction."""
        if hasattr(self, '_optimization_executor'):
            self._optimization_executor.shutdown(wait=False)


# Factory functions for easier instantiation
def create_cache_manager(
    l1_max_entries: int = 1000,
    l2_max_entries: int = 5000,
    l3_max_entries: int = 20000,
    enable_optimization: bool = True
) -> IntelligentCacheManager:
    """Create configured intelligent cache manager."""
    l1_config = CacheTierConfig(
        max_entries=l1_max_entries,
        max_memory_bytes=100 * 1024 * 1024,
        ttl_seconds=3600,
        eviction_policy=CachePolicy.ADAPTIVE
    )
    
    l2_config = CacheTierConfig(
        max_entries=l2_max_entries,
        max_memory_bytes=500 * 1024 * 1024,
        ttl_seconds=7200,
        eviction_policy=CachePolicy.LRU,
        compression_enabled=True
    )
    
    l3_config = CacheTierConfig(
        max_entries=l3_max_entries,
        max_memory_bytes=2 * 1024 * 1024 * 1024,
        ttl_seconds=86400,
        eviction_policy=CachePolicy.LFU,
        compression_enabled=True
    )
    
    return IntelligentCacheManager(
        l1_config=l1_config,
        l2_config=l2_config,
        l3_config=l3_config,
        enable_auto_optimization=enable_optimization
    )