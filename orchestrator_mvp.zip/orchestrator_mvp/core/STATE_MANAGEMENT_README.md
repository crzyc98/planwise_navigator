# State Management System for Multi-Year Coordination

## Overview

This comprehensive state management system provides enterprise-grade capabilities for workforce simulation with:

- **Cost modeling precision** with UUID-stamped attribution
- **Immutable audit trails** through event sourcing
- **Checkpoint/resume functionality** for multi-year simulations
- **Cross-year workforce state transitions** with dependency tracking
- **Integration with existing SimulationEvent model** in `config/events.py`

## Architecture

The state management system consists of five core components:

### 1. SimulationState (`state_management.py`)
Enhanced state management with cost modeling precision and UUID-stamped attribution.

**Key Features:**
- Immutable state objects with complete audit trail
- Cost modeling precision (18,6) for regulatory compliance
- Type-safe validation using Pydantic v2
- Dependency tracking across simulation years
- Comprehensive error and validation context

**Example:**
```python
from orchestrator_mvp.core.state_management import create_initial_workforce_metrics, create_state_manager

# Create initial workforce metrics
metrics = create_initial_workforce_metrics(
    active_employees=1000,
    total_compensation_cost=Decimal('75000000.00'),
    target_growth_rate=Decimal('0.03')
)

# Create state manager
state_manager = create_state_manager(
    scenario_id='my_scenario',
    plan_design_id='standard_plan',
    configuration=config
)

# Initialize year state
state = state_manager.initialize_year_state(
    simulation_year=2025,
    initial_workforce_metrics=metrics,
    random_seed=42
)
```

### 2. EventSourcingCheckpoint (`state_management.py`)
Immutable checkpoint system with audit trail preservation.

**Key Features:**
- Complete event audit trail preservation
- Immutable checkpoint snapshots with data integrity verification
- State reconstruction capabilities from checkpoints
- Regulatory compliance support with full event history

**Example:**
```python
from orchestrator_mvp.core.state_management import CheckpointType

# Create checkpoint
checkpoint = state_manager.create_checkpoint(
    simulation_year=2025,
    checkpoint_type=CheckpointType.YEAR_END,
    checkpoint_name="year_end_2025",
    description="Year-end checkpoint with full audit trail"
)

# Verify integrity
is_valid, issues = checkpoint.verify_integrity()
```

### 3. WorkforceStateManager (`state_management.py`)
Cross-year state transitions with dependency tracking.

**Key Features:**
- Sequential dependency validation
- Event-driven state transitions with cost impact analysis
- Workforce continuity preservation across years
- Comprehensive validation and error handling

**Example:**
```python
from orchestrator_mvp.core.state_management import StateTransitionContext

# Create transition context
transition_context = StateTransitionContext(
    source_state=current_state,
    target_year=2026,
    events_to_process=events,
    configuration=config,
    required_predecessors={2025},
    available_predecessors={2025}
)

# Execute transition
new_state = state_manager.transition_state(transition_context)
```

### 4. StateValidation (`state_validation.py`)
Comprehensive workforce continuity and integrity verification.

**Key Features:**
- Workforce continuity validation across simulation years
- Event sequence integrity verification
- Cost model accuracy validation with precision checks
- Cross-year dependency verification
- Regulatory compliance validation

**Example:**
```python
from orchestrator_mvp.core.state_validation import validate_simulation_comprehensive

# Comprehensive validation
validation_result = validate_simulation_comprehensive(
    state_manager=state_manager,
    simulation_years=[2025, 2026, 2027],
    scenario_id='my_scenario',
    plan_design_id='standard_plan',
    configuration=config,
    strict_mode=True
)

print(f"Validation result: {validation_result.is_valid}")
print(f"Issues found: {validation_result.total_issue_count}")
```

### 5. StatePersistence (`state_management.py`)
Checkpoint/resume functionality with compression and integrity verification.

**Key Features:**
- Compressed checkpoint storage with configurable compression levels
- Data integrity verification with hash validation
- Resume from checkpoint capability with corruption detection
- Audit trail preservation across save/load cycles

**Example:**
```python
from orchestrator_mvp.core.state_management import StatePersistence
from pathlib import Path

# Create persistence manager
persistence = StatePersistence(
    storage_path=Path(".dagster/checkpoints"),
    enable_compression=True,
    compression_level=6
)

# Save checkpoint
checkpoint_path = persistence.save_checkpoint(checkpoint)

# Load checkpoint
loaded_checkpoint = persistence.load_checkpoint(checkpoint_path)
```

## Integration with Existing System

### Enhanced Orchestrator (`state_integration.py`)
Seamless integration with existing `MultiYearSimulationOrchestrator`.

**Key Features:**
- Maintains backward compatibility with existing 7-step workflow
- Adds enhanced state tracking and validation
- Provides checkpoint/resume capabilities
- Integrates with existing event processing and database systems

**Example:**
```python
from orchestrator_mvp.core.state_integration import create_enhanced_orchestrator

# Create enhanced orchestrator
orchestrator = create_enhanced_orchestrator(
    start_year=2025,
    end_year=2029,
    config=config,
    enable_state_management=True,
    checkpoint_storage_path=Path(".dagster/checkpoints")
)

# Run enhanced simulation
results = orchestrator.run_enhanced_simulation(
    skip_breaks=True,
    validate_each_year=True,
    create_checkpoints=True
)
```

## Integration Points

### With Existing Event Model
The state management system seamlessly integrates with the existing `SimulationEvent` model in `config/events.py`:

```python
from config.events import WorkforceEventFactory, SimulationEvent

# Create events using existing factories
hire_event = WorkforceEventFactory.create_hire_event(
    employee_id="EMP_2025_001",
    scenario_id=scenario_id,
    plan_design_id=plan_design_id,
    hire_date=date(2025, 3, 15),
    department="Engineering",
    job_level=3,
    annual_compensation=Decimal('85000.00')
)

# Process events through state management
transition_context = StateTransitionContext(
    source_state=current_state,
    target_year=2025,
    events_to_process=[hire_event],
    configuration=config
)
```

### With Database Manager
Integrates with existing `database_manager.py` for data persistence:

```python
from orchestrator_mvp.core.database_manager import get_connection

# State manager automatically uses existing database connections
# No changes required to existing database configuration
```

### With Multi-Year Orchestrator
Extends existing orchestrator capabilities without breaking changes:

```python
# Existing workflow enhanced with state management
# All existing functionality preserved
# Additional state management features available optionally
```

## Usage Examples

### Basic Usage
```python
# 1. Create state manager
state_manager = create_state_manager(
    scenario_id='production_scenario',
    plan_design_id='standard_401k',
    configuration=simulation_config
)

# 2. Initialize baseline year
baseline_metrics = create_initial_workforce_metrics(
    active_employees=5000,
    total_compensation_cost=Decimal('375000000.00'),
    target_growth_rate=Decimal('0.03')
)

initial_state = state_manager.initialize_year_state(
    simulation_year=2025,
    initial_workforce_metrics=baseline_metrics,
    random_seed=42
)

# 3. Process events and transition state
events = generate_simulation_events()  # Your event generation
transition_context = StateTransitionContext(
    source_state=initial_state,
    target_year=2025,
    events_to_process=events,
    configuration=simulation_config
)

new_state = state_manager.transition_state(transition_context)

# 4. Create checkpoint
checkpoint = state_manager.create_checkpoint(
    simulation_year=2025,
    checkpoint_type=CheckpointType.YEAR_END,
    checkpoint_name="production_2025_complete"
)
```

### Advanced Usage with Enhanced Orchestrator
```python
# Create enhanced orchestrator
orchestrator = create_enhanced_orchestrator(
    start_year=2025,
    end_year=2029,
    config=production_config,
    enable_state_management=True
)

# Run with full state management features
results = orchestrator.run_enhanced_simulation(
    skip_breaks=True,
    validate_each_year=True,
    create_checkpoints=True
)

# Validate results
validation_result = orchestrator.validate_simulation_state(
    years_to_validate=[2025, 2026, 2027, 2028, 2029],
    strict_mode=True
)

if not validation_result.is_valid:
    print(f"Validation issues: {validation_result.total_issue_count}")
    for issue in validation_result.issues:
        if issue.is_blocking:
            print(f"BLOCKING: {issue.title} - {issue.description}")
```

## Configuration

### State Management Configuration
Add to your `simulation_config.yaml`:

```yaml
# Enhanced state management configuration
state_management:
  enabled: true
  scenario_id: "production_scenario_2025"
  plan_design_id: "standard_401k_plan"
  
  # Checkpointing configuration
  checkpointing:
    enabled: true
    storage_path: ".dagster/state_checkpoints"
    compression: true
    compression_level: 6
    auto_cleanup: true
    keep_latest: 5
    
  # Validation configuration
  validation:
    strict_mode: true
    validate_each_year: true
    validate_cross_year_dependencies: true
    validate_regulatory_compliance: true
    
  # Performance configuration
  performance:
    enable_state_compression: true
    batch_processing_size: 10000
    parallel_validation: true
    max_validation_workers: 4
```

### Integration Configuration
The system automatically detects and uses existing configuration:

```yaml
# Existing configuration automatically used
simulation:
  start_year: 2025
  end_year: 2029
  random_seed: 42
  target_growth_rate: 0.03

workforce:
  total_termination_rate: 0.12
  new_hire_termination_rate: 0.25

# No changes required to existing configuration
```

## Error Handling

### Validation Errors
```python
try:
    validation_result = validate_simulation_comprehensive(...)
    
    if not validation_result.is_valid:
        # Handle validation issues
        critical_issues = validation_result.get_issues_by_severity(ValidationSeverity.CRITICAL)
        for issue in critical_issues:
            logger.critical(f"Critical issue: {issue.title}")
            logger.critical(f"Recommendation: {issue.recommendation}")
            
        # Decide whether to proceed based on issue severity
        if validation_result.blocking_issue_count > 0:
            raise ValueError("Cannot proceed with blocking validation issues")
            
except Exception as e:
    logger.error(f"Validation failed: {str(e)}")
    # Handle appropriately
```

### State Transition Errors
```python
try:
    new_state = state_manager.transition_state(transition_context)
except ValueError as e:
    if "dependencies not satisfied" in str(e):
        # Handle dependency issues
        missing_deps = transition_context.missing_dependencies
        logger.error(f"Missing dependencies: {missing_deps}")
        # Retry after resolving dependencies
    else:
        # Handle other validation errors
        logger.error(f"State transition failed: {str(e)}")
        raise
```

### Checkpoint Recovery
```python
try:
    checkpoint = persistence.load_checkpoint(checkpoint_path)
    is_valid, issues = checkpoint.verify_integrity()
    
    if not is_valid:
        logger.warning(f"Checkpoint integrity issues: {issues}")
        # Decide whether to proceed or find alternative checkpoint
        
except FileNotFoundError:
    logger.info("No checkpoint found, starting fresh simulation")
    # Initialize from baseline
    
except Exception as e:
    logger.error(f"Checkpoint recovery failed: {str(e)}")
    # Fallback to fresh initialization
```

## Performance Considerations

### Memory Usage
- **SimulationState**: ~100KB per year per state
- **EventSourcingCheckpoint**: ~50KB base + event audit trail size
- **WorkforceStateManager**: ~1MB base + states
- **Compressed checkpoints**: 60-80% size reduction typical

### Processing Speed
- **State transitions**: <1ms for small workforces, <100ms for 50K+ employees
- **Validation**: ~10ms per year for basic validation, ~100ms for comprehensive
- **Checkpoint save/load**: <1s for compressed checkpoints up to 10MB

### Optimization Tips
1. **Enable compression** for checkpoint storage
2. **Use batch processing** for large workforce simulations
3. **Enable parallel validation** for multi-year scenarios
4. **Cache workforce snapshots** for repeated access
5. **Set memory limits** for large-scale simulations

## Testing

### Run Examples
```bash
cd orchestrator_mvp/core
python state_examples.py
```

### Unit Testing
```python
# Test basic state management
from orchestrator_mvp.core.state_management import SimulationState, WorkforceMetrics

def test_state_creation():
    metrics = create_initial_workforce_metrics(
        active_employees=100,
        total_compensation_cost=Decimal('7500000'),
        target_growth_rate=Decimal('0.03')
    )
    
    state = SimulationState(
        scenario_id='test',
        plan_design_id='test_plan',
        simulation_year=2025,
        workforce_metrics=metrics,
        configuration_hash='test_hash'
    )
    
    assert state.is_valid
    assert state.workforce_metrics.active_employees == 100
```

## Migration Guide

### From Existing Orchestrator
1. **No Breaking Changes**: Existing code continues to work unchanged
2. **Gradual Adoption**: Enable state management features incrementally
3. **Configuration**: Add state management config sections as needed
4. **Testing**: Use examples to verify integration in your environment

### Migration Steps
1. **Add configuration** for state management (optional)
2. **Replace orchestrator** with enhanced version:
   ```python
   # Before
   orchestrator = MultiYearSimulationOrchestrator(...)
   
   # After  
   orchestrator = create_enhanced_orchestrator(..., enable_state_management=True)
   ```
3. **Test with existing workflows** to ensure compatibility
4. **Gradually enable features** (checkpointing, validation, etc.)
5. **Monitor performance** and adjust configuration as needed

## Support and Troubleshooting

### Common Issues

1. **"State management must be enabled"**
   - Solution: Set `enable_state_management=True` when creating orchestrator

2. **"Missing prerequisite years"**
   - Solution: Ensure sequential year processing and proper dependency tracking

3. **"Checkpoint integrity verification failed"**
   - Solution: Check for file corruption, use backup checkpoints if available

4. **Memory usage too high**
   - Solution: Enable compression, reduce batch sizes, increase memory limits

### Debug Logging
```python
import logging
logging.basicConfig(level=logging.DEBUG)

# Enables detailed logging for state management operations
```

### Performance Monitoring
```python
# Monitor state management performance
results = orchestrator.run_enhanced_simulation(...)

print(f"State summaries: {results['state_summaries']}")
print(f"Validation timing: {results.get('validation_timing', 'N/A')}")
```

## Future Enhancements

### Planned Features
- **Distributed state management** for large-scale simulations
- **Advanced compression algorithms** for checkpoint optimization
- **Real-time validation** during event processing
- **State visualization dashboard** for monitoring
- **Custom validation rule framework** for domain-specific checks

### Extension Points
The system is designed for extensibility:
- **Custom validation rules** via `ValidationIssue` framework
- **Additional checkpoint types** via `CheckpointType` enum
- **Custom state metrics** via `WorkforceMetrics` extension
- **Integration connectors** for external systems

---

For complete examples and integration patterns, see `state_examples.py` in this directory.