"""
Comprehensive error handling framework with circuit breaker patterns and retry mechanisms.

This module provides enterprise-grade error handling capabilities for the multi-year simulation system,
including circuit breakers, retry mechanisms with exponential backoff, error classification, and
recovery strategies.
"""

from __future__ import annotations
import time
import random
import logging
import threading
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, Callable, Type, Union, List, Tuple
from enum import Enum
from dataclasses import dataclass, field
from contextlib import contextmanager
import json
import traceback
import functools

logger = logging.getLogger(__name__)


class CircuitState(Enum):
    """Circuit breaker states."""
    CLOSED = "closed"      # Normal operation - requests allowed
    OPEN = "open"          # Circuit is open - requests blocked
    HALF_OPEN = "half_open"  # Testing state - limited requests allowed


class ErrorSeverity(Enum):
    """Error severity levels for classification."""
    LOW = "low"           # Minor issues, continue processing
    MEDIUM = "medium"     # Significant issues, retry with caution
    HIGH = "high"         # Major issues, circuit breaker consideration
    CRITICAL = "critical" # System-level failures, immediate attention


class ErrorCategory(Enum):
    """Error category classification."""
    TRANSIENT = "transient"         # Temporary issues (network, timeouts)
    PERSISTENT = "persistent"       # Configuration or logic errors
    RESOURCE = "resource"           # Memory, disk, CPU issues
    DATA_QUALITY = "data_quality"   # Invalid or corrupted data
    DEPENDENCY = "dependency"       # External service failures
    VALIDATION = "validation"       # Business rule violations


@dataclass
class ErrorContext:
    """Context information for error handling decisions."""
    operation_name: str
    attempt_number: int
    total_attempts: int
    error_type: str
    error_message: str
    severity: ErrorSeverity
    category: ErrorCategory
    timestamp: datetime
    additional_context: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for logging and storage."""
        return {
            'operation_name': self.operation_name,
            'attempt_number': self.attempt_number,
            'total_attempts': self.total_attempts,
            'error_type': self.error_type,
            'error_message': self.error_message,
            'severity': self.severity.value,
            'category': self.category.value,
            'timestamp': self.timestamp.isoformat(),
            'additional_context': self.additional_context
        }


@dataclass
class CircuitBreakerConfig:
    """Configuration for circuit breaker behavior."""
    failure_threshold: int = 5          # Failures before opening circuit
    recovery_timeout_seconds: int = 60  # Time before trying half-open
    success_threshold: int = 3          # Successes in half-open before closing
    timeout_seconds: int = 30           # Operation timeout
    
    # Advanced configuration
    failure_rate_threshold: float = 0.5  # Failure rate (0.0-1.0) to open circuit
    minimum_requests: int = 10           # Minimum requests before calculating failure rate
    sliding_window_size: int = 100       # Size of sliding window for failure rate


@dataclass
class RetryConfig:
    """Configuration for retry behavior."""
    max_attempts: int = 3
    base_delay_seconds: float = 1.0
    max_delay_seconds: float = 60.0
    exponential_backoff_multiplier: float = 2.0
    jitter_enabled: bool = True
    jitter_max_seconds: float = 1.0
    
    # Retry strategy configuration
    retry_on_exceptions: Tuple[Type[Exception], ...] = (Exception,)
    no_retry_on_exceptions: Tuple[Type[Exception], ...] = (KeyboardInterrupt, SystemExit)


class ErrorClassifier:
    """Classifies errors for appropriate handling strategies."""
    
    # Error patterns and their classifications
    ERROR_PATTERNS = {
        # Transient errors - retry appropriate
        'connection': (ErrorSeverity.MEDIUM, ErrorCategory.TRANSIENT),
        'timeout': (ErrorSeverity.MEDIUM, ErrorCategory.TRANSIENT),
        'network': (ErrorSeverity.MEDIUM, ErrorCategory.TRANSIENT),
        'temporary': (ErrorSeverity.LOW, ErrorCategory.TRANSIENT),
        'lock': (ErrorSeverity.MEDIUM, ErrorCategory.TRANSIENT),
        'busy': (ErrorSeverity.LOW, ErrorCategory.TRANSIENT),
        
        # Resource errors - may need circuit breaker
        'memory': (ErrorSeverity.HIGH, ErrorCategory.RESOURCE),
        'disk': (ErrorSeverity.HIGH, ErrorCategory.RESOURCE),
        'cpu': (ErrorSeverity.HIGH, ErrorCategory.RESOURCE),
        'quota': (ErrorSeverity.HIGH, ErrorCategory.RESOURCE),
        
        # Persistent errors - don't retry
        'syntax': (ErrorSeverity.HIGH, ErrorCategory.PERSISTENT),
        'configuration': (ErrorSeverity.HIGH, ErrorCategory.PERSISTENT),
        'permission': (ErrorSeverity.HIGH, ErrorCategory.PERSISTENT),
        'authentication': (ErrorSeverity.HIGH, ErrorCategory.PERSISTENT),
        'authorization': (ErrorSeverity.HIGH, ErrorCategory.PERSISTENT),
        
        # Data quality errors - handle with data recovery
        'validation': (ErrorSeverity.MEDIUM, ErrorCategory.DATA_QUALITY),
        'constraint': (ErrorSeverity.MEDIUM, ErrorCategory.DATA_QUALITY),
        'integrity': (ErrorSeverity.HIGH, ErrorCategory.DATA_QUALITY),
        'corruption': (ErrorSeverity.CRITICAL, ErrorCategory.DATA_QUALITY),
        
        # Dependency errors - circuit breaker appropriate
        'service': (ErrorSeverity.MEDIUM, ErrorCategory.DEPENDENCY),
        'api': (ErrorSeverity.MEDIUM, ErrorCategory.DEPENDENCY),
        'database': (ErrorSeverity.HIGH, ErrorCategory.DEPENDENCY),
        'dbt': (ErrorSeverity.MEDIUM, ErrorCategory.DEPENDENCY),
    }
    
    @classmethod
    def classify_error(cls, error: Exception, operation_name: str = "") -> Tuple[ErrorSeverity, ErrorCategory]:
        """
        Classify an error based on its type and message.
        
        Args:
            error: The exception to classify
            operation_name: Name of the operation that failed (for context)
            
        Returns:
            Tuple of (severity, category)
        """
        error_message = str(error).lower()
        error_type = type(error).__name__.lower()
        
        # Check error message for patterns
        for pattern, (severity, category) in cls.ERROR_PATTERNS.items():
            if pattern in error_message or pattern in error_type:
                return severity, category
        
        # Special handling for specific exception types
        if isinstance(error, (ConnectionError, TimeoutError)):
            return ErrorSeverity.MEDIUM, ErrorCategory.TRANSIENT
        elif isinstance(error, (MemoryError, OSError)):
            return ErrorSeverity.HIGH, ErrorCategory.RESOURCE
        elif isinstance(error, (ValueError, TypeError)):
            return ErrorSeverity.MEDIUM, ErrorCategory.VALIDATION
        elif isinstance(error, (PermissionError, FileNotFoundError)):
            return ErrorSeverity.HIGH, ErrorCategory.PERSISTENT
        
        # Default classification for unknown errors
        return ErrorSeverity.MEDIUM, ErrorCategory.TRANSIENT
    
    @classmethod
    def is_retryable(cls, error: Exception, operation_name: str = "") -> bool:
        """
        Determine if an error should be retried.
        
        Args:
            error: The exception to evaluate
            operation_name: Name of the operation that failed
            
        Returns:
            True if the error is retryable, False otherwise
        """
        severity, category = cls.classify_error(error, operation_name)
        
        # Don't retry persistent errors or critical data quality issues
        if category in (ErrorCategory.PERSISTENT, ErrorCategory.VALIDATION):
            return False
        
        if category == ErrorCategory.DATA_QUALITY and severity == ErrorSeverity.CRITICAL:
            return False
        
        # Don't retry certain exception types
        if isinstance(error, (KeyboardInterrupt, SystemExit, SystemError)):
            return False
        
        return True


class CircuitBreaker:
    """
    Circuit breaker implementation with comprehensive failure detection and recovery.
    
    Features:
    - Three states: CLOSED, OPEN, HALF_OPEN
    - Failure rate and count-based thresholds
    - Sliding window for failure rate calculation
    - Automatic recovery attempts
    - Comprehensive monitoring and logging
    """
    
    def __init__(self, name: str, config: CircuitBreakerConfig):
        self.name = name
        self.config = config
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.last_failure_time: Optional[datetime] = None
        self.next_attempt_time: Optional[datetime] = None
        
        # Sliding window for failure rate calculation
        self.request_history: List[Tuple[datetime, bool]] = []  # (timestamp, success)
        self._lock = threading.RLock()
        
        logger.info(f"Circuit breaker '{name}' initialized with config: {config}")
    
    def _cleanup_history(self) -> None:
        """Clean up old entries from request history."""
        cutoff_time = datetime.now() - timedelta(minutes=5)  # Keep 5 minutes of history
        self.request_history = [
            (timestamp, success) for timestamp, success in self.request_history
            if timestamp > cutoff_time
        ]
    
    def _calculate_failure_rate(self) -> float:
        """Calculate current failure rate from sliding window."""
        if len(self.request_history) < self.config.minimum_requests:
            return 0.0
        
        # Use sliding window of recent requests
        recent_requests = self.request_history[-self.config.sliding_window_size:]
        if not recent_requests:
            return 0.0
        
        failures = sum(1 for _, success in recent_requests if not success)
        return failures / len(recent_requests)
    
    def _should_open_circuit(self) -> bool:
        """Determine if circuit should be opened based on failure criteria."""
        # Count-based threshold
        if self.failure_count >= self.config.failure_threshold:
            return True
        
        # Rate-based threshold
        failure_rate = self._calculate_failure_rate()
        if (len(self.request_history) >= self.config.minimum_requests and
            failure_rate >= self.config.failure_rate_threshold):
            return True
        
        return False
    
    def _can_attempt_recovery(self) -> bool:
        """Check if recovery attempt is allowed."""
        if self.next_attempt_time is None:
            return True
        return datetime.now() >= self.next_attempt_time
    
    def call(self, func: Callable, *args, **kwargs) -> Any:
        """
        Execute a function through the circuit breaker.
        
        Args:
            func: Function to execute
            *args: Positional arguments for the function
            **kwargs: Keyword arguments for the function
            
        Returns:
            Result of the function call
            
        Raises:
            CircuitBreakerOpenError: If circuit is open and not ready for recovery
            Any exception raised by the function
        """
        with self._lock:
            self._cleanup_history()
            
            # Check circuit state
            if self.state == CircuitState.OPEN:
                if not self._can_attempt_recovery():
                    raise CircuitBreakerOpenError(
                        f"Circuit breaker '{self.name}' is OPEN. "
                        f"Next attempt allowed at {self.next_attempt_time}"
                    )
                else:
                    # Transition to half-open for recovery attempt
                    self.state = CircuitState.HALF_OPEN
                    self.success_count = 0
                    logger.info(f"Circuit breaker '{self.name}' transitioning to HALF_OPEN for recovery attempt")
        
        # Execute the function
        start_time = time.time()
        try:
            result = func(*args, **kwargs)
            execution_time = time.time() - start_time
            
            # Record success
            with self._lock:
                self.request_history.append((datetime.now(), True))
                self._on_success(execution_time)
            
            return result
        
        except Exception as error:
            execution_time = time.time() - start_time
            
            # Record failure
            with self._lock:
                self.request_history.append((datetime.now(), False))
                self._on_failure(error, execution_time)
            
            raise
    
    def _on_success(self, execution_time: float) -> None:
        """Handle successful execution."""
        if self.state == CircuitState.HALF_OPEN:
            self.success_count += 1
            logger.info(f"Circuit breaker '{self.name}' success in HALF_OPEN: {self.success_count}/{self.config.success_threshold}")
            
            if self.success_count >= self.config.success_threshold:
                # Recovery successful - close circuit
                self.state = CircuitState.CLOSED
                self.failure_count = 0
                self.success_count = 0
                self.last_failure_time = None
                self.next_attempt_time = None
                logger.info(f"Circuit breaker '{self.name}' recovered - transitioning to CLOSED")
        
        elif self.state == CircuitState.CLOSED:
            # Reset failure count on success
            self.failure_count = max(0, self.failure_count - 1)
    
    def _on_failure(self, error: Exception, execution_time: float) -> None:
        """Handle failed execution."""
        self.failure_count += 1
        self.last_failure_time = datetime.now()
        
        error_severity, error_category = ErrorClassifier.classify_error(error, self.name)
        
        logger.warning(f"Circuit breaker '{self.name}' failure #{self.failure_count}: {error} (severity: {error_severity.value}, category: {error_category.value})")
        
        if self.state == CircuitState.HALF_OPEN:
            # Failure during recovery - back to open
            self.state = CircuitState.OPEN
            self.next_attempt_time = datetime.now() + timedelta(seconds=self.config.recovery_timeout_seconds)
            logger.warning(f"Circuit breaker '{self.name}' failed during recovery - back to OPEN until {self.next_attempt_time}")
        
        elif self.state == CircuitState.CLOSED:
            # Check if we should open the circuit
            if self._should_open_circuit():
                self.state = CircuitState.OPEN
                self.next_attempt_time = datetime.now() + timedelta(seconds=self.config.recovery_timeout_seconds)
                failure_rate = self._calculate_failure_rate()
                logger.error(f"Circuit breaker '{self.name}' OPENED - failure count: {self.failure_count}, failure rate: {failure_rate:.2%}, next attempt: {self.next_attempt_time}")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get current circuit breaker statistics."""
        with self._lock:
            return {
                'name': self.name,
                'state': self.state.value,
                'failure_count': self.failure_count,
                'success_count': self.success_count,
                'failure_rate': self._calculate_failure_rate(),
                'last_failure_time': self.last_failure_time.isoformat() if self.last_failure_time else None,
                'next_attempt_time': self.next_attempt_time.isoformat() if self.next_attempt_time else None,
                'total_requests': len(self.request_history),
                'config': {
                    'failure_threshold': self.config.failure_threshold,
                    'recovery_timeout_seconds': self.config.recovery_timeout_seconds,
                    'success_threshold': self.config.success_threshold,
                    'failure_rate_threshold': self.config.failure_rate_threshold
                }
            }
    
    def reset(self) -> None:
        """Reset circuit breaker to initial state."""
        with self._lock:
            self.state = CircuitState.CLOSED
            self.failure_count = 0
            self.success_count = 0
            self.last_failure_time = None
            self.next_attempt_time = None
            self.request_history.clear()
            logger.info(f"Circuit breaker '{self.name}' reset to initial state")


class RetryHandler:
    """
    Retry mechanism with exponential backoff and jitter.
    
    Features:
    - Exponential backoff with configurable multiplier
    - Jitter to prevent thundering herd
    - Error classification for retry decisions
    - Comprehensive logging and monitoring
    - Integration with circuit breakers
    """
    
    def __init__(self, name: str, config: RetryConfig):
        self.name = name
        self.config = config
        
        logger.info(f"Retry handler '{name}' initialized with config: max_attempts={config.max_attempts}, base_delay={config.base_delay_seconds}s")
    
    def _calculate_delay(self, attempt: int) -> float:
        """Calculate delay for the given attempt number."""
        # Exponential backoff
        delay = self.config.base_delay_seconds * (self.config.exponential_backoff_multiplier ** (attempt - 1))
        
        # Cap at maximum delay
        delay = min(delay, self.config.max_delay_seconds)
        
        # Add jitter if enabled
        if self.config.jitter_enabled:
            jitter = random.uniform(0, self.config.jitter_max_seconds)
            delay += jitter
        
        return delay
    
    def _should_retry(self, error: Exception, attempt: int) -> bool:
        """Determine if we should retry after this error."""
        # Check attempt limit
        if attempt >= self.config.max_attempts:
            return False
        
        # Check no-retry exceptions
        if isinstance(error, self.config.no_retry_on_exceptions):
            return False
        
        # Check if error type is retryable
        if not isinstance(error, self.config.retry_on_exceptions):
            return False
        
        # Use error classifier
        return ErrorClassifier.is_retryable(error, self.name)
    
    def execute(self, func: Callable, *args, **kwargs) -> Any:
        """
        Execute a function with retry logic.
        
        Args:
            func: Function to execute
            *args: Positional arguments for the function
            **kwargs: Keyword arguments for the function
            
        Returns:
            Result of the function call
            
        Raises:
            The last exception if all retries are exhausted
        """
        last_error = None
        
        for attempt in range(1, self.config.max_attempts + 1):
            try:
                logger.debug(f"Retry handler '{self.name}' attempt {attempt}/{self.config.max_attempts}")
                result = func(*args, **kwargs)
                
                if attempt > 1:
                    logger.info(f"Retry handler '{self.name}' succeeded on attempt {attempt}")
                
                return result
            
            except Exception as error:
                last_error = error
                
                # Classify error for context
                severity, category = ErrorClassifier.classify_error(error, self.name)
                
                error_context = ErrorContext(
                    operation_name=self.name,
                    attempt_number=attempt,
                    total_attempts=self.config.max_attempts,
                    error_type=type(error).__name__,
                    error_message=str(error),
                    severity=severity,
                    category=category,
                    timestamp=datetime.now()
                )
                
                # Log the error
                logger.warning(f"Retry handler '{self.name}' attempt {attempt} failed: {error} (severity: {severity.value}, category: {category.value})")
                
                # Check if we should retry
                if not self._should_retry(error, attempt):
                    logger.error(f"Retry handler '{self.name}' giving up after {attempt} attempts - error not retryable: {error}")
                    raise error
                
                # Calculate and wait for delay (unless last attempt)
                if attempt < self.config.max_attempts:
                    delay = self._calculate_delay(attempt)
                    logger.info(f"Retry handler '{self.name}' waiting {delay:.2f}s before attempt {attempt + 1}")
                    time.sleep(delay)
        
        # All retries exhausted
        logger.error(f"Retry handler '{self.name}' exhausted all {self.config.max_attempts} attempts")
        raise last_error


class CircuitBreakerOpenError(Exception):
    """Exception raised when circuit breaker is open."""
    pass


class ErrorRecoveryManager:
    """
    Manages error recovery strategies for different types of failures.
    
    Features:
    - Automatic recovery strategy selection based on error classification
    - Graceful degradation from optimized to fallback processing
    - State recovery mechanisms for interrupted operations
    - Integration with circuit breakers and retry handlers
    """
    
    def __init__(self):
        self.recovery_strategies: Dict[str, Callable] = {}
        self.fallback_strategies: Dict[str, Callable] = {}
        
    def register_recovery_strategy(self, operation_name: str, strategy: Callable) -> None:
        """Register a recovery strategy for a specific operation."""
        self.recovery_strategies[operation_name] = strategy
        logger.info(f"Registered recovery strategy for operation: {operation_name}")
    
    def register_fallback_strategy(self, operation_name: str, strategy: Callable) -> None:
        """Register a fallback strategy for a specific operation."""
        self.fallback_strategies[operation_name] = strategy
        logger.info(f"Registered fallback strategy for operation: {operation_name}")
    
    def attempt_recovery(self, error_context: ErrorContext) -> bool:
        """
        Attempt to recover from an error using registered strategies.
        
        Args:
            error_context: Context information about the error
            
        Returns:
            True if recovery was successful, False otherwise
        """
        operation_name = error_context.operation_name
        
        # Try specific recovery strategy first
        if operation_name in self.recovery_strategies:
            try:
                logger.info(f"Attempting recovery for operation '{operation_name}' using registered strategy")
                recovery_func = self.recovery_strategies[operation_name]
                recovery_func(error_context)
                logger.info(f"Recovery successful for operation '{operation_name}'")
                return True
            except Exception as recovery_error:
                logger.warning(f"Recovery strategy failed for operation '{operation_name}': {recovery_error}")
        
        # Try fallback strategy
        if operation_name in self.fallback_strategies:
            try:
                logger.info(f"Attempting fallback for operation '{operation_name}'")
                fallback_func = self.fallback_strategies[operation_name]
                fallback_func(error_context)
                logger.info(f"Fallback successful for operation '{operation_name}'")
                return True
            except Exception as fallback_error:
                logger.warning(f"Fallback strategy failed for operation '{operation_name}': {fallback_error}")
        
        # No recovery possible
        logger.error(f"No recovery strategy available for operation '{operation_name}'")
        return False


# Global instances
_circuit_breakers: Dict[str, CircuitBreaker] = {}
_retry_handlers: Dict[str, RetryHandler] = {}
_recovery_manager = ErrorRecoveryManager()


def get_circuit_breaker(name: str, config: Optional[CircuitBreakerConfig] = None) -> CircuitBreaker:
    """Get or create a circuit breaker with the given name."""
    if name not in _circuit_breakers:
        if config is None:
            config = CircuitBreakerConfig()
        _circuit_breakers[name] = CircuitBreaker(name, config)
    return _circuit_breakers[name]


def get_retry_handler(name: str, config: Optional[RetryConfig] = None) -> RetryHandler:
    """Get or create a retry handler with the given name."""
    if name not in _retry_handlers:
        if config is None:
            config = RetryConfig()
        _retry_handlers[name] = RetryHandler(name, config)
    return _retry_handlers[name]


def get_recovery_manager() -> ErrorRecoveryManager:
    """Get the global error recovery manager."""
    return _recovery_manager


def with_circuit_breaker(name: str, config: Optional[CircuitBreakerConfig] = None):
    """Decorator to add circuit breaker protection to a function."""
    def decorator(func: Callable) -> Callable:
        breaker = get_circuit_breaker(name, config)
        
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return breaker.call(func, *args, **kwargs)
        
        return wrapper
    return decorator


def with_retry(name: str, config: Optional[RetryConfig] = None):
    """Decorator to add retry logic to a function."""
    def decorator(func: Callable) -> Callable:
        handler = get_retry_handler(name, config)
        
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return handler.execute(func, *args, **kwargs)
        
        return wrapper
    return decorator


def with_error_handling(
    operation_name: str,
    circuit_breaker_config: Optional[CircuitBreakerConfig] = None,
    retry_config: Optional[RetryConfig] = None,
    enable_circuit_breaker: bool = True,
    enable_retry: bool = True
):
    """
    Comprehensive decorator that combines circuit breaker and retry logic.
    
    Args:
        operation_name: Name of the operation (used for logging and metrics)
        circuit_breaker_config: Configuration for circuit breaker
        retry_config: Configuration for retry logic
        enable_circuit_breaker: Whether to enable circuit breaker protection
        enable_retry: Whether to enable retry logic
    """
    def decorator(func: Callable) -> Callable:
        # Create circuit breaker and retry handler
        breaker = get_circuit_breaker(f"{operation_name}_cb", circuit_breaker_config) if enable_circuit_breaker else None
        handler = get_retry_handler(f"{operation_name}_retry", retry_config) if enable_retry else None
        
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Create execution function that may include circuit breaker
            if breaker:
                exec_func = lambda: breaker.call(func, *args, **kwargs)
            else:
                exec_func = lambda: func(*args, **kwargs)
            
            # Execute with retry if enabled
            if handler:
                return handler.execute(exec_func)
            else:
                return exec_func()
        
        return wrapper
    return decorator


@contextmanager
def error_handling_context(operation_name: str, additional_context: Optional[Dict[str, Any]] = None):
    """
    Context manager for comprehensive error handling and logging.
    
    Args:
        operation_name: Name of the operation
        additional_context: Additional context information for error reporting
    """
    start_time = time.time()
    logger.info(f"Starting operation: {operation_name}")
    
    try:
        yield
        
        execution_time = time.time() - start_time
        logger.info(f"Operation '{operation_name}' completed successfully in {execution_time:.2f}s")
        
    except Exception as error:
        execution_time = time.time() - start_time
        severity, category = ErrorClassifier.classify_error(error, operation_name)
        
        error_context = ErrorContext(
            operation_name=operation_name,
            attempt_number=1,
            total_attempts=1,
            error_type=type(error).__name__,
            error_message=str(error),
            severity=severity,
            category=category,
            timestamp=datetime.now(),
            additional_context=additional_context or {}
        )
        
        logger.error(f"Operation '{operation_name}' failed after {execution_time:.2f}s: {error} (severity: {severity.value}, category: {category.value})")
        logger.error(f"Error context: {json.dumps(error_context.to_dict(), indent=2)}")
        
        # Attempt recovery if possible
        recovery_manager = get_recovery_manager()
        if recovery_manager.attempt_recovery(error_context):
            logger.info(f"Recovery successful for operation '{operation_name}'")
        else:
            logger.error(f"Recovery failed for operation '{operation_name}'")
        
        raise


def get_all_circuit_breaker_stats() -> Dict[str, Dict[str, Any]]:
    """Get statistics for all circuit breakers."""
    return {name: breaker.get_stats() for name, breaker in _circuit_breakers.items()}


def reset_all_circuit_breakers() -> None:
    """Reset all circuit breakers to initial state."""
    for breaker in _circuit_breakers.values():
        breaker.reset()
    logger.info("All circuit breakers reset")


def log_error_summary() -> None:
    """Log a summary of all error handling components."""
    logger.info("=== ERROR HANDLING SUMMARY ===")
    logger.info(f"Circuit breakers: {len(_circuit_breakers)}")
    logger.info(f"Retry handlers: {len(_retry_handlers)}")
    
    for name, breaker in _circuit_breakers.items():
        stats = breaker.get_stats()
        logger.info(f"  {name}: {stats['state']}, failures: {stats['failure_count']}, rate: {stats['failure_rate']:.2%}")