"""
Advanced dbt Batch Execution System for Multi-Year Simulations.

This module provides intelligent batch processing for dbt operations with:
- Dependency graph analysis and parallel execution
- Performance optimization for multi-year workflows
- Intelligent resource management and load balancing
- Integration with the advanced optimization engine
"""

import asyncio
import json
import os
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Set, Optional, Tuple, Any
import networkx as nx

from ..core.advanced_optimizations import PerformanceMonitor


@dataclass
class DbtModel:
    """Represents a dbt model with metadata."""
    name: str
    path: str
    depends_on: List[str] = field(default_factory=list)
    materialization: str = "table"
    estimated_runtime_seconds: float = 30.0
    priority: int = 1  # 1=high, 2=medium, 3=low
    tags: List[str] = field(default_factory=list)


@dataclass
class BatchExecutionResult:
    """Results from batch execution."""
    batch_id: str
    models: List[str]
    success: bool
    execution_time_ms: float
    error_message: Optional[str] = None
    warnings: List[str] = field(default_factory=list)


class DbtDependencyAnalyzer:
    """Analyzes dbt project dependencies for optimal execution planning."""
    
    def __init__(self, dbt_project_path: str):
        self.dbt_project_path = Path(dbt_project_path)
        self.dependency_graph = nx.DiGraph()
        self.models: Dict[str, DbtModel] = {}
        
    def analyze_project_dependencies(self) -> Dict[str, Any]:
        """Analyze dbt project structure and build dependency graph."""
        try:
            # Run dbt ls to get model information
            result = subprocess.run([
                "dbt", "ls", "--output", "json", "--resource-type", "model"
            ], cwd=self.dbt_project_path, capture_output=True, text=True, check=True)
            
            model_data = []
            for line in result.stdout.strip().split('\n'):
                if line.strip():
                    try:
                        model_data.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
            
            return self._build_dependency_graph(model_data)
            
        except subprocess.CalledProcessError as e:
            return {"error": f"Failed to analyze dbt project: {e}"}
    
    def _build_dependency_graph(self, model_data: List[Dict]) -> Dict[str, Any]:
        """Build dependency graph from dbt model data."""
        analysis_results = {
            "total_models": len(model_data),
            "dependency_levels": 0,
            "parallel_batches": [],
            "critical_path": [],
            "models_by_materialization": {}
        }
        
        # Create DbtModel objects and dependency graph
        for model_info in model_data:
            model_name = model_info.get("name", "")
            depends_on = model_info.get("depends_on", {}).get("nodes", [])
            
            # Clean dependency names (remove resource type prefixes)
            clean_dependencies = [dep.split(".")[-1] for dep in depends_on if "model." in dep]
            
            dbt_model = DbtModel(
                name=model_name,
                path=model_info.get("original_file_path", ""),
                depends_on=clean_dependencies,
                materialization=model_info.get("config", {}).get("materialized", "table"),
                tags=model_info.get("tags", [])
            )
            
            self.models[model_name] = dbt_model
            self.dependency_graph.add_node(model_name)
            
            # Add edges for dependencies
            for dep in clean_dependencies:
                if dep in self.models or any(dep in existing_model for existing_model in self.models):
                    self.dependency_graph.add_edge(dep, model_name)
        
        # Analyze graph structure
        try:
            analysis_results["dependency_levels"] = len(list(nx.topological_generations(self.dependency_graph)))
            analysis_results["parallel_batches"] = self._create_parallel_batches()
            analysis_results["critical_path"] = self._find_critical_path()
            analysis_results["models_by_materialization"] = self._group_by_materialization()
        except nx.NetworkXError:
            analysis_results["error"] = "Circular dependency detected in dbt models"
        
        return analysis_results
    
    def _create_parallel_batches(self) -> List[List[str]]:
        """Create parallel execution batches based on dependency levels."""
        try:
            batches = []
            for generation in nx.topological_generations(self.dependency_graph):
                batches.append(list(generation))
            return batches
        except nx.NetworkXError:
            return []
    
    def _find_critical_path(self) -> List[str]:
        """Find the critical path (longest dependency chain)."""
        try:
            # Find longest path in DAG
            longest_path = []
            for node in nx.topological_sort(self.dependency_graph):
                if not list(self.dependency_graph.predecessors(node)):  # Source node
                    path = nx.dag_longest_path(self.dependency_graph, source=node)
                    if len(path) > len(longest_path):
                        longest_path = path
            return longest_path
        except nx.NetworkXError:
            return []
    
    def _group_by_materialization(self) -> Dict[str, List[str]]:
        """Group models by materialization type for optimization."""
        groups = {}
        for model_name, model in self.models.items():
            mat_type = model.materialization
            if mat_type not in groups:
                groups[mat_type] = []
            groups[mat_type].append(model_name)
        return groups


class OptimizedDbtExecutor:
    """High-performance dbt executor with intelligent batch processing."""
    
    def __init__(self, dbt_project_path: str, max_parallel_jobs: int = 4):
        self.dbt_project_path = Path(dbt_project_path)
        self.max_parallel_jobs = max_parallel_jobs
        self.dependency_analyzer = DbtDependencyAnalyzer(str(dbt_project_path))
        self.performance_monitor = PerformanceMonitor()
        self.execution_results: List[BatchExecutionResult] = []
        self._lock = threading.Lock()
        
        # Environment optimization for dbt execution
        self._optimize_dbt_environment()
    
    def _optimize_dbt_environment(self):
        """Optimize environment variables for dbt performance."""
        import psutil
        
        cpu_count = os.cpu_count() or 4
        memory_gb = psutil.virtual_memory().total / (1024**3)
        
        optimal_threads = min(cpu_count, 8)
        memory_percent = "85%" if memory_gb > 16 else "75%" if memory_gb > 8 else "60%"
        
        # Set dbt-specific environment variables
        performance_env = {
            "DBT_PROFILES_DIR": os.path.expanduser("~/.dbt"),
            "DBT_PARTIAL_PARSE": "true",
            "DBT_USE_COLORS": "false",
            "DBT_LOG_FORMAT": "json",
            "DUCKDB_MEMORY_LIMIT": memory_percent,
            "DUCKDB_THREADS": str(optimal_threads),
            "PYTHONUNBUFFERED": "1"
        }
        
        for key, value in performance_env.items():
            os.environ[key] = value
        
        print(f"🔧 Optimized dbt environment: {optimal_threads} threads, {memory_percent} memory")
    
    def execute_models_optimized(self, 
                                models: Optional[List[str]] = None,
                                strategy: str = "parallel",
                                full_refresh: bool = False) -> Dict[str, Any]:
        """Execute dbt models with optimized strategy."""
        
        with self.performance_monitor.monitor_operation("dbt_execution_optimized", len(models) if models else 0) as metric:
            # Analyze dependencies
            print("📊 Analyzing dbt project dependencies...")
            dependency_analysis = self.dependency_analyzer.analyze_project_dependencies()
            
            if "error" in dependency_analysis:
                return {"success": False, "error": dependency_analysis["error"]}
            
            execution_plan = self._create_execution_plan(models, strategy, dependency_analysis)
            
            print(f"🚀 Executing {len(execution_plan['batches'])} batches with {strategy} strategy")
            
            # Execute based on strategy
            if strategy == "parallel":
                results = self._execute_parallel_batches(execution_plan, full_refresh)
            else:
                results = self._execute_sequential_batches(execution_plan, full_refresh)
            
            # Calculate performance metrics
            total_time = sum(r.execution_time_ms for r in self.execution_results)
            success_rate = sum(1 for r in self.execution_results if r.success) / len(self.execution_results) if self.execution_results else 0
            
            return {
                "success": success_rate == 1.0,
                "total_batches": len(execution_plan['batches']),
                "total_execution_time_ms": total_time,
                "success_rate": success_rate,
                "dependency_analysis": dependency_analysis,
                "execution_results": [
                    {
                        "batch_id": r.batch_id,
                        "models": r.models,
                        "success": r.success,
                        "execution_time_ms": r.execution_time_ms,
                        "error": r.error_message
                    } for r in self.execution_results
                ],
                "performance_summary": self.performance_monitor.get_performance_summary()
            }
    
    def _create_execution_plan(self, models: Optional[List[str]], strategy: str, dependency_analysis: Dict) -> Dict[str, Any]:
        """Create optimized execution plan based on strategy and dependencies."""
        if strategy == "parallel" and "parallel_batches" in dependency_analysis:
            batches = dependency_analysis["parallel_batches"]
            
            # Filter batches if specific models requested
            if models:
                model_set = set(models)
                filtered_batches = []
                for batch in batches:
                    filtered_batch = [model for model in batch if model in model_set]
                    if filtered_batch:
                        filtered_batches.append(filtered_batch)
                batches = filtered_batches
        else:
            # Sequential execution - all models in one batch
            all_models = models if models else list(self.dependency_analyzer.models.keys())
            batches = [all_models]
        
        return {
            "strategy": strategy,  
            "batches": batches,
            "total_models": sum(len(batch) for batch in batches),
            "estimated_time_seconds": self._estimate_execution_time(batches)
        }
    
    def _estimate_execution_time(self, batches: List[List[str]]) -> float:
        """Estimate total execution time for batches."""
        if not batches:
            return 0.0
            
        # Parallel batches: time is max of each batch
        total_time = 0.0
        for batch in batches:
            batch_time = sum(
                self.dependency_analyzer.models.get(model, DbtModel(model, "")).estimated_runtime_seconds 
                for model in batch
            )
            total_time += batch_time  # Sequential batch execution
        
        return total_time
    
    def _execute_parallel_batches(self, execution_plan: Dict, full_refresh: bool) -> List[BatchExecutionResult]:
        """Execute batches in parallel where possible."""
        results = []
        
        print(f"⚡ Starting parallel execution of {len(execution_plan['batches'])} batches")
        
        for batch_index, batch_models in enumerate(execution_plan['batches']):
            if not batch_models:
                continue
                
            batch_id = f"batch_{batch_index + 1}"
            print(f"  🚀 Executing batch {batch_index + 1}/{len(execution_plan['batches'])}: {len(batch_models)} models")
            
            # Execute batch
            result = self._execute_single_batch(batch_id, batch_models, full_refresh)
            results.append(result)
            
            # Store results
            with self._lock:
                self.execution_results.append(result)
            
            # Stop on critical failure
            if not result.success and batch_index < len(execution_plan['batches']) - 1:
                print(f"  ❌ Batch {batch_id} failed, stopping execution")
                break
        
        return results
    
    def _execute_sequential_batches(self, execution_plan: Dict, full_refresh: bool) -> List[BatchExecutionResult]:
        """Execute batches sequentially."""
        results = []
        
        print(f"🔄 Starting sequential execution of {execution_plan['total_models']} models")
        
        for batch_index, batch_models in enumerate(execution_plan['batches']):
            if not batch_models:
                continue
                
            batch_id = f"sequential_batch_{batch_index + 1}"
            print(f"  📊 Processing batch {batch_index + 1}: {batch_models}")
            
            result = self._execute_single_batch(batch_id, batch_models, full_refresh)
            results.append(result)
            
            with self._lock:
                self.execution_results.append(result)
            
            if not result.success:
                print(f"  ❌ Batch {batch_id} failed")
                break
        
        return results
    
    def _execute_single_batch(self, batch_id: str, models: List[str], full_refresh: bool) -> BatchExecutionResult:
        """Execute a single batch of dbt models."""
        start_time = time.perf_counter()
        
        try:
            # Build dbt command
            cmd = ["dbt", "run", "--models"] + models
            
            if full_refresh:
                cmd.append("--full-refresh")
            
            # Add performance flags
            cmd.extend([
                "--threads", str(self.max_parallel_jobs),
                "--no-write-json"  # Reduce I/O overhead
            ])
            
            print(f"    🔧 Command: {' '.join(cmd)}")
            
            # Execute dbt command
            result = subprocess.run(
                cmd,
                cwd=self.dbt_project_path,
                capture_output=True,
                text=True,
                timeout=1800  # 30 minute timeout
            )
            
            execution_time_ms = (time.perf_counter() - start_time) * 1000
            
            if result.returncode == 0:
                print(f"    ✅ Batch {batch_id} completed in {execution_time_ms:.0f}ms")
                return BatchExecutionResult(
                    batch_id=batch_id,
                    models=models,
                    success=True,
                    execution_time_ms=execution_time_ms
                )
            else:
                error_msg = result.stderr or result.stdout
                print(f"    ❌ Batch {batch_id} failed: {error_msg}")
                return BatchExecutionResult(
                    batch_id=batch_id,
                    models=models,
                    success=False,
                    execution_time_ms=execution_time_ms,
                    error_message=error_msg
                )
                
        except subprocess.TimeoutExpired:
            execution_time_ms = (time.perf_counter() - start_time) * 1000
            return BatchExecutionResult(
                batch_id=batch_id,
                models=models,
                success=False,
                execution_time_ms=execution_time_ms,
                error_message="Execution timeout after 30 minutes"
            )
        except Exception as e:
            execution_time_ms = (time.perf_counter() - start_time) * 1000
            return BatchExecutionResult(
                batch_id=batch_id,
                models=models,
                success=False,
                execution_time_ms=execution_time_ms,
                error_message=str(e)
            )
    
    def optimize_model_materialization(self) -> Dict[str, Any]:
        """Analyze and suggest optimal materialization strategies."""
        optimization_suggestions = {
            "current_materializations": {},
            "suggested_changes": [],
            "performance_impact": {}
        }
        
        # Analyze current materializations
        dependency_analysis = self.dependency_analyzer.analyze_project_dependencies()
        models_by_materialization = dependency_analysis.get("models_by_materialization", {})
        
        optimization_suggestions["current_materializations"] = models_by_materialization
        
        # Generate suggestions based on model characteristics
        for model_name, model in self.dependency_analyzer.models.items():
            suggestions = []
            
            # Large fact tables should be materialized as tables
            if "fct_" in model_name and model.materialization != "table":
                suggestions.append({
                    "model": model_name,
                    "current": model.materialization,
                    "suggested": "table",  
                    "reason": "Fact tables benefit from table materialization for query performance"
                })
            
            # Intermediate models with complex logic should be tables
            if "int_" in model_name and len(model.depends_on) > 2 and model.materialization == "view":
                suggestions.append({
                    "model": model_name,
                    "current": model.materialization,
                    "suggested": "table",
                    "reason": "Complex intermediate models with multiple dependencies benefit from materialization"
                })
            
            # Simple staging models can remain as views
            if "stg_" in model_name and model.materialization == "table" and len(model.depends_on) <= 1:
                suggestions.append({
                    "model": model_name,
                    "current": model.materialization,
                    "suggested": "view",
                    "reason": "Simple staging models can use view materialization to save storage"
                })
            
            optimization_suggestions["suggested_changes"].extend(suggestions)
        
        return optimization_suggestions
    
    def generate_execution_report(self) -> str:
        """Generate comprehensive execution report."""
        if not self.execution_results:
            return "No execution results available."
        
        total_batches = len(self.execution_results)
        successful_batches = sum(1 for r in self.execution_results if r.success)
        total_time_ms = sum(r.execution_time_ms for r in self.execution_results)
        total_models = sum(len(r.models) for r in self.execution_results)
        
        report = [
            "🚀 dbt Batch Execution Report",
            "=" * 40,
            f"📊 Total Batches: {total_batches}",
            f"✅ Successful: {successful_batches}",
            f"❌ Failed: {total_batches - successful_batches}",
            f"📈 Success Rate: {(successful_batches / total_batches * 100):.1f}%",
            f"⏱️  Total Time: {total_time_ms:.0f}ms ({total_time_ms / 1000:.1f}s)",
            f"📋 Total Models: {total_models}",
            f"⚡ Avg Time/Model: {total_time_ms / total_models:.0f}ms" if total_models > 0 else "⚡ Avg Time/Model: N/A",
            "",
            "🔍 Batch Details:",
            "-" * 20
        ]
        
        for result in self.execution_results:
            status = "✅" if result.success else "❌"
            report.append(f"{status} {result.batch_id}: {len(result.models)} models, {result.execution_time_ms:.0f}ms")
            if result.error_message:
                report.append(f"    Error: {result.error_message[:100]}...")
        
        return "\n".join(report)


# Factory function for easy integration
def create_optimized_dbt_executor(dbt_project_path: str, max_parallel_jobs: int = 4) -> OptimizedDbtExecutor:
    """Create optimized dbt executor with performance tuning."""
    print(f"🏗️  Creating optimized dbt executor")
    print(f"  📁 Project path: {dbt_project_path}")
    print(f"  ⚡ Max parallel jobs: {max_parallel_jobs}")
    
    executor = OptimizedDbtExecutor(dbt_project_path, max_parallel_jobs)
    
    print(f"  ✅ dbt executor ready for high-performance batch processing")
    return executor