"""
ResourceOptimizer component for Story S031-04 Multi-Year Coordination.

This module provides memory and I/O optimization for large multi-year simulations,
implementing streaming and chunking strategies for efficient resource utilization.

Key Features:
- Memory optimization with streaming and chunking strategies
- I/O optimization for checkpointing and result persistence  
- Batching and compression strategies
- Support for simulations with large workforce sizes
- Integration with existing simulation pipeline
- Performance monitoring and resource tracking
- Adaptive optimization based on simulation size and available resources

Components:
- ResourceOptimizer: Main optimization coordinator
- MemoryManager: Memory optimization strategies
- IOOptimizer: I/O optimization for persistence operations
- ResourceMonitor: Resource usage tracking and metrics
- OptimizationStrategies: Streaming vs in-memory approaches
- Performance monitoring and adaptive resource management

Usage:
    # Initialize optimizer for large simulation
    optimizer = ResourceOptimizer()
    
    # Optimize memory usage for workforce simulation
    memory_config = optimizer.optimize_memory_usage(
        simulation_years=[2024, 2025, 2026],
        workforce_size=50000
    )
    
    # Optimize I/O operations for checkpointing
    io_config = optimizer.optimize_io_operations(
        checkpoint_frequency=10,
        result_persistence_level=PersistenceLevel.FULL
    )
    
    # Monitor resource usage during simulation
    with optimizer.resource_monitor.monitor_context("multi_year_simulation"):
        # Run simulation with optimized resource usage
        pass
"""

from __future__ import annotations
import os
import sys
import gc
import gzip
import pickle
import threading
import time
import logging
import psutil
from typing import Dict, Any, Optional, List, Union, Tuple, Protocol, Callable
from datetime import datetime, timedelta
from pathlib import Path
from decimal import Decimal
from dataclasses import dataclass, field
from enum import Enum
from contextlib import contextmanager
from abc import ABC, abstractmethod

from pydantic import BaseModel, Field, ConfigDict, field_validator, computed_field
from pydantic.types import NonNegativeInt, PositiveInt, NonNegativeFloat

# Import existing components for integration
from orchestrator_mvp.utils.error_handling import (
    with_error_handling, 
    error_handling_context,
    ErrorSeverity,
    ErrorCategory
)

logger = logging.getLogger(__name__)


class PersistenceLevel(str, Enum):
    """Levels of persistence for optimization strategies."""
    MINIMAL = "minimal"     # Only essential data
    STANDARD = "standard"   # Standard checkpoint data
    FULL = "full"          # Complete state with audit trail
    COMPREHENSIVE = "comprehensive"  # Full data plus metadata and validation


class OptimizationStrategy(str, Enum):
    """Available optimization strategies."""
    STREAMING = "streaming"        # Stream processing for large datasets
    IN_MEMORY = "in_memory"       # In-memory processing for smaller datasets
    HYBRID = "hybrid"             # Adaptive hybrid approach
    CHUNKED = "chunked"           # Chunked processing with disk spillover


class ResourceType(str, Enum):
    """Types of system resources to monitor."""
    MEMORY = "memory"
    CPU = "cpu"
    DISK_IO = "disk_io"
    NETWORK_IO = "network_io"
    DATABASE = "database"


class CompressionType(str, Enum):
    """Compression types for I/O optimization."""
    NONE = "none"
    GZIP = "gzip"
    LZMA = "lzma"
    PICKLE_PROTOCOL_5 = "pickle_protocol_5"


# Pydantic v2 Data Models
class ResourceLimits(BaseModel):
    """Resource limits configuration."""
    
    model_config = ConfigDict(
        frozen=True,
        use_enum_values=True,
        validate_assignment=True
    )
    
    max_memory_gb: NonNegativeFloat = Field(default=8.0, description="Maximum memory usage in GB")
    max_memory_percentage: NonNegativeFloat = Field(default=0.8, le=1.0, description="Maximum memory as percentage of available")
    max_disk_space_gb: NonNegativeFloat = Field(default=50.0, description="Maximum disk space for checkpoints")
    chunk_size_mb: PositiveInt = Field(default=100, description="Chunk size in MB for streaming")
    io_batch_size: PositiveInt = Field(default=1000, description="Batch size for I/O operations")
    
    @field_validator('max_memory_percentage')
    @classmethod
    def validate_memory_percentage(cls, v: float) -> float:
        """Validate memory percentage is reasonable."""
        if v < 0.1 or v > 0.95:
            raise ValueError('Memory percentage should be between 0.1 and 0.95')
        return v


class MemoryRequirements(BaseModel):
    """Memory requirements calculation results."""
    
    model_config = ConfigDict(frozen=True)
    
    total_gb: NonNegativeFloat = Field(description="Total memory required")
    peak_gb: NonNegativeFloat = Field(description="Peak memory usage estimate")
    baseline_gb: NonNegativeFloat = Field(description="Baseline memory for operation")
    buffer_gb: NonNegativeFloat = Field(default=1.0, description="Safety buffer")
    workforce_data_gb: NonNegativeFloat = Field(description="Memory for workforce data")
    event_data_gb: NonNegativeFloat = Field(description="Memory for event processing")
    
    @computed_field
    @property
    def is_large_simulation(self) -> bool:
        """Determine if this represents a large simulation."""
        return self.total_gb > 4.0


class OptimizationConfig(BaseModel):
    """Configuration for optimization strategies."""
    
    model_config = ConfigDict(
        frozen=True,
        use_enum_values=True
    )
    
    strategy_type: OptimizationStrategy
    memory_usage_gb: NonNegativeFloat
    chunk_size_employees: PositiveInt = Field(default=10000)
    overlap_buffer_percentage: NonNegativeFloat = Field(default=0.1, le=0.5)
    preload_years: NonNegativeInt = Field(default=2)
    enable_caching: bool = Field(default=True)
    cache_size_mb: NonNegativeInt = Field(default=500)
    
    @field_validator('overlap_buffer_percentage')
    @classmethod
    def validate_overlap_buffer(cls, v: float) -> float:
        """Validate overlap buffer is reasonable."""
        if v < 0.0 or v > 0.5:
            raise ValueError('Overlap buffer should be between 0.0 and 0.5')
        return v


class MemoryOptimizationResult(BaseModel):
    """Results from memory optimization analysis."""
    
    model_config = ConfigDict(frozen=True)
    
    strategy_type: str
    memory_savings_gb: NonNegativeFloat
    config: OptimizationConfig
    performance_impact: str = Field(description="Estimated performance impact")
    recommended_chunk_size: PositiveInt
    estimated_processing_time_minutes: NonNegativeFloat
    
    @computed_field
    @property 
    def efficiency_rating(self) -> str:
        """Calculate efficiency rating based on memory savings and performance."""
        if self.memory_savings_gb > 2.0 and "minimal" in self.performance_impact.lower():
            return "excellent"
        elif self.memory_savings_gb > 1.0 and "low" in self.performance_impact.lower():
            return "good"
        elif self.memory_savings_gb > 0.5:
            return "acceptable"
        else:
            return "marginal"


class IOOptimizationResult(BaseModel):
    """Results from I/O optimization analysis."""
    
    model_config = ConfigDict(frozen=True)
    
    checkpoint_optimization: Dict[str, Any]
    persistence_optimization: Dict[str, Any]
    compression_optimization: Dict[str, Any]
    total_io_reduction_percentage: NonNegativeFloat
    
    @computed_field
    @property
    def is_significant_improvement(self) -> bool:
        """Determine if the optimization provides significant improvement."""
        return self.total_io_reduction_percentage > 0.2


class ResourceMetrics(BaseModel):
    """Current resource usage metrics."""
    
    model_config = ConfigDict(frozen=True)
    
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    memory_used_gb: NonNegativeFloat
    memory_available_gb: NonNegativeFloat
    memory_percentage: NonNegativeFloat
    cpu_percentage: NonNegativeFloat
    disk_io_read_mb_per_sec: NonNegativeFloat = Field(default=0.0)
    disk_io_write_mb_per_sec: NonNegativeFloat = Field(default=0.0)
    
    @computed_field
    @property
    def memory_pressure_level(self) -> str:
        """Calculate memory pressure level."""
        if self.memory_percentage > 0.9:
            return "critical"
        elif self.memory_percentage > 0.8:
            return "high"
        elif self.memory_percentage > 0.6:
            return "moderate"
        else:
            return "low"


# Optimization Strategy Classes
class OptimizationStrategyProtocol(Protocol):
    """Protocol for optimization strategies."""
    
    def create_optimized_config(
        self, 
        simulation_years: List[int], 
        workforce_size: int
    ) -> OptimizationConfig:
        """Create optimized configuration for the given parameters."""
        ...
    
    def estimate_performance_impact(self) -> str:
        """Estimate the performance impact of this optimization strategy."""
        ...


class StreamingOptimizationStrategy:
    """Streaming optimization strategy for large simulations."""
    
    def __init__(self, chunk_size: int, overlap_buffer: float = 0.1):
        """
        Initialize streaming optimization strategy.
        
        Args:
            chunk_size: Number of employees to process in each chunk
            overlap_buffer: Buffer percentage for chunk overlap
        """
        self.chunk_size = chunk_size
        self.overlap_buffer = overlap_buffer
        
        logger.info(f"Initialized StreamingOptimizationStrategy with chunk_size={chunk_size}")
    
    def create_optimized_config(
        self, 
        simulation_years: List[int], 
        workforce_size: int
    ) -> OptimizationConfig:
        """Create streaming-optimized configuration."""
        # Calculate optimal chunk size based on workforce size
        optimal_chunk_size = max(1000, min(self.chunk_size, workforce_size // 10))
        
        # Estimate memory usage (streaming uses minimal memory)
        base_memory = 0.5  # Base overhead
        chunk_memory = (optimal_chunk_size * 0.001)  # Rough estimate: 1KB per employee
        memory_usage = base_memory + chunk_memory
        
        return OptimizationConfig(
            strategy_type=OptimizationStrategy.STREAMING,
            memory_usage_gb=memory_usage,
            chunk_size_employees=optimal_chunk_size,
            overlap_buffer_percentage=self.overlap_buffer,
            preload_years=1,  # Minimal preloading for streaming
            enable_caching=False,  # Caching conflicts with streaming
            cache_size_mb=0
        )
    
    def estimate_performance_impact(self) -> str:
        """Estimate performance impact of streaming strategy."""
        return "Low to moderate impact - streaming reduces memory usage but may increase processing time due to I/O overhead"


class InMemoryOptimizationStrategy:
    """In-memory optimization strategy for smaller simulations."""
    
    def __init__(self, preload_years: int = 3):
        """
        Initialize in-memory optimization strategy.
        
        Args:
            preload_years: Number of years to preload into memory
        """
        self.preload_years = preload_years
        
        logger.info(f"Initialized InMemoryOptimizationStrategy with preload_years={preload_years}")
    
    def create_optimized_config(
        self, 
        simulation_years: List[int], 
        workforce_size: int
    ) -> OptimizationConfig:
        """Create in-memory optimized configuration."""
        # Calculate memory usage for in-memory processing
        base_memory = 1.0  # Base overhead
        workforce_memory = workforce_size * 0.002  # 2KB per employee
        years_memory = len(simulation_years) * 0.5  # 0.5GB per year
        cache_memory = 1.0  # Cache overhead
        
        memory_usage = base_memory + workforce_memory + years_memory + cache_memory
        
        return OptimizationConfig(
            strategy_type=OptimizationStrategy.IN_MEMORY,
            memory_usage_gb=memory_usage,
            chunk_size_employees=workforce_size,  # Process all at once
            overlap_buffer_percentage=0.0,  # No chunking overlap needed
            preload_years=min(self.preload_years, len(simulation_years)),
            enable_caching=True,
            cache_size_mb=1000
        )
    
    def estimate_performance_impact(self) -> str:
        """Estimate performance impact of in-memory strategy."""
        return "Minimal impact - in-memory processing provides optimal performance but requires sufficient RAM"


# Resource Management Classes
class MemoryManager:
    """Memory optimization strategies for multi-year simulations."""
    
    def __init__(self, limits: ResourceLimits):
        """
        Initialize memory manager with resource limits.
        
        Args:
            limits: Resource limits configuration
        """
        self.limits = limits
        self._memory_monitor = psutil.virtual_memory()
        
        logger.info(f"Initialized MemoryManager with max_memory_gb={limits.max_memory_gb}")
    
    def calculate_memory_requirements(
        self, 
        simulation_years: List[int], 
        workforce_size: int
    ) -> MemoryRequirements:
        """
        Calculate memory requirements for simulation parameters.
        
        Args:
            simulation_years: List of years to simulate
            workforce_size: Number of employees in workforce
            
        Returns:
            MemoryRequirements with detailed breakdown
        """
        # Base memory for system operations
        baseline_gb = 0.5
        
        # Memory for workforce data (employee records, attributes)
        workforce_data_gb = workforce_size * 0.002  # ~2KB per employee
        
        # Memory for event processing (events, state transitions)
        events_per_employee_per_year = 5  # Average events
        total_events = workforce_size * len(simulation_years) * events_per_employee_per_year
        event_data_gb = total_events * 0.001  # ~1KB per event
        
        # Peak memory includes temporary buffers and processing overhead
        processing_overhead = 0.3  # 30% overhead for processing
        buffer_gb = 1.0  # Safety buffer
        
        total_gb = baseline_gb + workforce_data_gb + event_data_gb
        peak_gb = total_gb * (1 + processing_overhead) + buffer_gb
        
        return MemoryRequirements(
            total_gb=round(total_gb, 2), 
            peak_gb=round(peak_gb, 2),
            baseline_gb=baseline_gb,
            buffer_gb=buffer_gb,
            workforce_data_gb=round(workforce_data_gb, 2),
            event_data_gb=round(event_data_gb, 2)
        )
    
    def select_optimal_strategy(
        self, 
        memory_requirements: MemoryRequirements
    ) -> OptimizationStrategyProtocol:
        """
        Select optimal optimization strategy based on memory requirements.
        
        Args:
            memory_requirements: Calculated memory requirements
            
        Returns:
            Optimal optimization strategy
        """
        available_memory_gb = psutil.virtual_memory().available / (1024**3)
        max_usable_memory = min(
            self.limits.max_memory_gb,
            available_memory_gb * self.limits.max_memory_percentage
        )
        
        if memory_requirements.peak_gb > max_usable_memory:
            # Use streaming for large simulations
            optimal_chunk_size = int(self.limits.chunk_size_mb * 1024 / 2)  # Convert MB to employee count
            logger.info(f"Selected streaming strategy due to high memory requirements: {memory_requirements.peak_gb:.1f}GB > {max_usable_memory:.1f}GB")
            return StreamingOptimizationStrategy(chunk_size=optimal_chunk_size)
        else:
            # Use in-memory for smaller simulations
            logger.info(f"Selected in-memory strategy: {memory_requirements.peak_gb:.1f}GB <= {max_usable_memory:.1f}GB")
            return InMemoryOptimizationStrategy()
    
    @contextmanager
    def memory_management_context(self, operation_name: str):
        """
        Context manager for memory management during operations.
        
        Args:
            operation_name: Name of the operation for logging
        """
        initial_memory = psutil.Process().memory_info().rss / (1024**3)
        logger.info(f"Starting memory-managed operation '{operation_name}' - initial memory: {initial_memory:.2f}GB")
        
        try:
            yield
        finally:
            # Force garbage collection
            gc.collect()
            
            final_memory = psutil.Process().memory_info().rss / (1024**3)
            memory_change = final_memory - initial_memory
            
            logger.info(f"Completed memory-managed operation '{operation_name}' - final memory: {final_memory:.2f}GB (change: {memory_change:+.2f}GB)")
            
            # Log warning if memory usage is high
            if final_memory > self.limits.max_memory_gb * 0.8:
                logger.warning(f"High memory usage detected: {final_memory:.2f}GB (>{self.limits.max_memory_gb * 0.8:.1f}GB threshold)")


class IOOptimizer:
    """I/O optimization for checkpointing and result persistence."""
    
    def __init__(self, limits: ResourceLimits):
        """
        Initialize I/O optimizer with resource limits.
        
        Args:
            limits: Resource limits configuration
        """
        self.limits = limits
        self.compression_types = {
            CompressionType.GZIP: (gzip.open, 'wb', {'compresslevel': 6}),
            CompressionType.LZMA: (self._lzma_open, 'wb', {'preset': 6}),
        }
        
        logger.info(f"Initialized IOOptimizer with batch_size={limits.io_batch_size}")
    
    def _lzma_open(self, filename: Path, mode: str, **kwargs):
        """Open LZMA file with fallback if not available."""
        try:
            import lzma
            return lzma.open(filename, mode, **kwargs)
        except ImportError:
            logger.warning("LZMA not available, falling back to gzip")
            return gzip.open(filename, mode, compresslevel=6)
    
    def analyze_io_patterns(
        self, 
        checkpoint_frequency: int,
        result_persistence_level: PersistenceLevel
    ) -> Dict[str, Any]:
        """
        Analyze I/O patterns for optimization opportunities.
        
        Args:
            checkpoint_frequency: How often checkpoints are created
            result_persistence_level: Level of data persistence required
            
        Returns:
            Analysis results with optimization recommendations
        """
        # Estimate I/O volumes based on persistence level
        base_checkpoint_size_mb = {
            PersistenceLevel.MINIMAL: 10,
            PersistenceLevel.STANDARD: 50,
            PersistenceLevel.FULL: 200,
            PersistenceLevel.COMPREHENSIVE: 500
        }.get(result_persistence_level, 100)
        
        # Calculate I/O patterns
        checkpoints_per_year = max(1, 12 // checkpoint_frequency)  # Monthly checkpoints
        total_checkpoint_data_mb = base_checkpoint_size_mb * checkpoints_per_year
        
        return {
            'checkpoint_frequency': checkpoint_frequency,
            'persistence_level': result_persistence_level.value,
            'estimated_checkpoint_size_mb': base_checkpoint_size_mb,
            'checkpoints_per_year': checkpoints_per_year,
            'total_checkpoint_data_mb': total_checkpoint_data_mb,
            'compression_potential': 0.6 if result_persistence_level != PersistenceLevel.MINIMAL else 0.3,
            'batching_potential': 0.3 if checkpoint_frequency < 6 else 0.1
        }
    
    def optimize_compression(self, data_size_mb: float) -> Dict[str, Any]:
        """
        Determine optimal compression strategy.
        
        Args:
            data_size_mb: Size of data to compress in MB
            
        Returns:
            Compression optimization recommendations
        """
        if data_size_mb < 10:
            # Small data - compression overhead not worth it
            compression_type = CompressionType.NONE
            estimated_savings = 0.0
            performance_impact = "none"
        elif data_size_mb < 100:
            # Medium data - use fast compression
            compression_type = CompressionType.GZIP
            estimated_savings = 0.4  # 40% compression
            performance_impact = "low"
        else:
            # Large data - use better compression
            compression_type = CompressionType.LZMA
            estimated_savings = 0.6  # 60% compression
            performance_impact = "moderate"
        
        return {
            'recommended_compression': compression_type.value,
            'estimated_savings_percentage': estimated_savings,
            'performance_impact': performance_impact,
            'original_size_mb': data_size_mb,
            'compressed_size_mb': data_size_mb * (1 - estimated_savings)
        }
    
    @with_error_handling("io_optimization", enable_retry=True, enable_circuit_breaker=False)
    def compress_and_save(
        self, 
        data: Any, 
        file_path: Path, 
        compression_type: CompressionType = CompressionType.GZIP
    ) -> Dict[str, Any]:
        """
        Compress and save data with optimization.
        
        Args:
            data: Data to save
            file_path: Path to save to
            compression_type: Type of compression to use
            
        Returns:
            Save operation results
        """
        start_time = time.time()
        
        # Serialize data
        serialized_data = pickle.dumps(data, protocol=pickle.HIGHEST_PROTOCOL)
        original_size = len(serialized_data)
        
        if compression_type == CompressionType.NONE:
            # Save without compression
            with open(file_path, 'wb') as f:
                f.write(serialized_data)
            compressed_size = original_size
        else:
            # Save with compression
            open_func, mode, kwargs = self.compression_types[compression_type]
            with open_func(file_path, mode, **kwargs) as f:
                f.write(serialized_data)
            compressed_size = file_path.stat().st_size
        
        duration = time.time() - start_time
        compression_ratio = compressed_size / original_size if original_size > 0 else 1.0
        
        result = {
            'file_path': str(file_path),
            'original_size_bytes': original_size,
            'compressed_size_bytes': compressed_size,
            'compression_ratio': compression_ratio,
            'compression_percentage': (1 - compression_ratio) * 100,
            'compression_type': compression_type.value,
            'save_duration_seconds': duration,
            'throughput_mb_per_sec': (original_size / (1024**2)) / max(duration, 0.001)
        }
        
        logger.info(f"Saved data with {compression_type.value} compression: {original_size/1024/1024:.1f}MB -> {compressed_size/1024/1024:.1f}MB ({compression_ratio:.1%}) in {duration:.2f}s")
        
        return result


class ResourceMonitor:
    """Resource usage tracking and performance monitoring."""
    
    def __init__(self, sampling_interval_seconds: float = 1.0):
        """
        Initialize resource monitor.
        
        Args:
            sampling_interval_seconds: How often to sample resource usage
        """
        self.sampling_interval = sampling_interval_seconds
        self._monitoring_active = False
        self._monitor_thread: Optional[threading.Thread] = None
        self._metrics_history: List[ResourceMetrics] = []
        self._metrics_lock = threading.RLock()
        
        logger.info(f"Initialized ResourceMonitor with sampling_interval={sampling_interval_seconds}s")
    
    def get_current_metrics(self) -> ResourceMetrics:
        """Get current resource usage metrics."""
        memory = psutil.virtual_memory()
        cpu_percent = psutil.cpu_percent(interval=0.1)
        
        # Get disk I/O if available
        try:
            disk_io = psutil.disk_io_counters()
            disk_read_mb_per_sec = (disk_io.read_bytes / (1024**2)) if disk_io else 0.0
            disk_write_mb_per_sec = (disk_io.write_bytes / (1024**2)) if disk_io else 0.0
        except (AttributeError, OSError):
            disk_read_mb_per_sec = 0.0
            disk_write_mb_per_sec = 0.0
        
        return ResourceMetrics(
            memory_used_gb=round((memory.total - memory.available) / (1024**3), 2),
            memory_available_gb=round(memory.available / (1024**3), 2),
            memory_percentage=round(memory.percent / 100, 3),
            cpu_percentage=round(cpu_percent / 100, 3),
            disk_io_read_mb_per_sec=round(disk_read_mb_per_sec, 2),
            disk_io_write_mb_per_sec=round(disk_write_mb_per_sec, 2)
        )
    
    def start_monitoring(self) -> None:
        """Start continuous resource monitoring."""
        if self._monitoring_active:
            logger.warning("Resource monitoring already active")
            return
        
        self._monitoring_active = True
        self._monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._monitor_thread.start()
        
        logger.info("Started resource monitoring")
    
    def stop_monitoring(self) -> None:
        """Stop continuous resource monitoring."""
        if not self._monitoring_active:
            return
        
        self._monitoring_active = False
        if self._monitor_thread:
            self._monitor_thread.join(timeout=2.0)
        
        logger.info("Stopped resource monitoring")
    
    def _monitor_loop(self) -> None:
        """Main monitoring loop (runs in separate thread)."""
        while self._monitoring_active:
            try:
                current_metrics = self.get_current_metrics()
                
                with self._metrics_lock:
                    self._metrics_history.append(current_metrics)
                    
                    # Keep only recent history (last hour)
                    cutoff_time = datetime.utcnow() - timedelta(hours=1)
                    self._metrics_history = [
                        m for m in self._metrics_history 
                        if m.timestamp > cutoff_time
                    ]
                
                # Log warnings for high resource usage  
                if current_metrics.memory_percentage > 0.9:
                    logger.warning(f"High memory usage: {current_metrics.memory_percentage:.1%}")
                
                time.sleep(self.sampling_interval)
                
            except Exception as e:
                logger.error(f"Error in resource monitoring loop: {e}")
                time.sleep(self.sampling_interval)
    
    def get_metrics_summary(self, minutes: int = 10) -> Dict[str, Any]:
        """
        Get summary of resource metrics over the specified time period.
        
        Args:
            minutes: Number of minutes to summarize
            
        Returns:
            Summary statistics for resource usage
        """
        cutoff_time = datetime.utcnow() - timedelta(minutes=minutes)
        
        with self._metrics_lock:
            recent_metrics = [
                m for m in self._metrics_history
                if m.timestamp > cutoff_time
            ]
        
        if not recent_metrics:
            return {'error': 'No metrics available for the specified time period'}
        
        # Calculate statistics
        memory_percentages = [m.memory_percentage for m in recent_metrics]
        cpu_percentages = [m.cpu_percentage for m in recent_metrics]
        
        return {
            'time_period_minutes': minutes,
            'sample_count': len(recent_metrics),
            'memory_usage': {
                'current_percentage': recent_metrics[-1].memory_percentage,
                'average_percentage': sum(memory_percentages) / len(memory_percentages),
                'peak_percentage': max(memory_percentages),
                'current_gb': recent_metrics[-1].memory_used_gb,
                'pressure_level': recent_metrics[-1].memory_pressure_level
            },
            'cpu_usage': {
                'current_percentage': recent_metrics[-1].cpu_percentage,
                'average_percentage': sum(cpu_percentages) / len(cpu_percentages),
                'peak_percentage': max(cpu_percentages)
            },
            'disk_io': {
                'current_read_mb_per_sec': recent_metrics[-1].disk_io_read_mb_per_sec,
                'current_write_mb_per_sec': recent_metrics[-1].disk_io_write_mb_per_sec
            }
        }
    
    @contextmanager
    def monitor_context(self, operation_name: str):
        """
        Context manager for monitoring resource usage during an operation.
        
        Args:
            operation_name: Name of the operation being monitored
        """
        start_metrics = self.get_current_metrics()
        start_time = time.time()
        
        logger.info(f"Starting monitored operation '{operation_name}' - memory: {start_metrics.memory_used_gb:.1f}GB ({start_metrics.memory_percentage:.1%})")
        
        try:
            yield
        finally:
            end_metrics = self.get_current_metrics()
            duration = time.time() - start_time
            
            memory_change = end_metrics.memory_used_gb - start_metrics.memory_used_gb
            
            logger.info(f"Completed monitored operation '{operation_name}' in {duration:.1f}s - memory change: {memory_change:+.1f}GB")
            
            # Log resource usage summary
            if duration > 10:  # Only for operations longer than 10 seconds
                summary = self.get_metrics_summary(minutes=max(1, int(duration / 60)))
                logger.info(f"Resource summary for '{operation_name}': {summary}")


# Main ResourceOptimizer Class
class ResourceOptimizer:
    """
    Main coordinator for memory and I/O optimization in multi-year simulations.
    
    This class provides the primary interface for resource optimization, combining
    memory management, I/O optimization, and resource monitoring to provide optimal
    performance for both large and small workforce simulations.
    """
    
    def __init__(
        self, 
        resource_limits: Optional[ResourceLimits] = None,
        enable_monitoring: bool = True
    ):
        """
        Initialize resource optimizer.
        
        Args:
            resource_limits: Resource limits configuration
            enable_monitoring: Whether to enable resource monitoring
        """
        self.resource_limits = resource_limits or ResourceLimits()
        self.memory_manager = MemoryManager(self.resource_limits)
        self.io_optimizer = IOOptimizer(self.resource_limits)
        self.resource_monitor = ResourceMonitor()
        
        if enable_monitoring:
            self.resource_monitor.start_monitoring()
        
        logger.info("Initialized ResourceOptimizer with comprehensive optimization capabilities")
    
    @with_error_handling("memory_optimization", enable_retry=True)
    def optimize_memory_usage(
        self,
        simulation_years: List[int],
        workforce_size: int
    ) -> MemoryOptimizationResult:
        """
        Optimize memory usage for large multi-year simulations.
        
        Implements streaming and chunking strategies based on simulation size
        and available system resources.
        
        Args:
            simulation_years: List of years to simulate
            workforce_size: Number of employees in workforce
            
        Returns:
            MemoryOptimizationResult with optimization strategy and configuration
        """
        logger.info(f"Optimizing memory usage for {len(simulation_years)} years, {workforce_size:,} employees")
        
        with self.memory_manager.memory_management_context("memory_optimization"):
            # Calculate memory requirements
            memory_requirements = self.memory_manager.calculate_memory_requirements(
                simulation_years, workforce_size
            )
            
            # Select optimal strategy
            optimization_strategy = self.memory_manager.select_optimal_strategy(memory_requirements)
            
            # Create optimized configuration
            optimized_config = optimization_strategy.create_optimized_config(
                simulation_years, workforce_size
            )
            
            # Calculate memory savings
            baseline_memory = memory_requirements.peak_gb
            optimized_memory = optimized_config.memory_usage_gb
            memory_savings = max(0, baseline_memory - optimized_memory)
            
            # Estimate processing time based on strategy
            if optimized_config.strategy_type == OptimizationStrategy.STREAMING:
                # Streaming takes longer due to I/O overhead
                base_time = len(simulation_years) * 5  # 5 minutes per year baseline
                processing_time = base_time * 1.3  # 30% overhead for streaming
            else:
                # In-memory processing is faster
                base_time = len(simulation_years) * 3  # 3 minutes per year baseline
                processing_time = base_time * 0.9  # 10% speedup for in-memory
            
            result = MemoryOptimizationResult(
                strategy_type=optimized_config.strategy_type,
                memory_savings_gb=round(memory_savings, 2),
                config=optimized_config,
                performance_impact=optimization_strategy.estimate_performance_impact(),
                recommended_chunk_size=optimized_config.chunk_size_employees,
                estimated_processing_time_minutes=round(processing_time, 1)
            )
            
            logger.info(f"Memory optimization complete: {result.strategy_type} strategy, {result.memory_savings_gb:.1f}GB savings, {result.efficiency_rating} efficiency")
            
            return result
    
    @with_error_handling("io_optimization", enable_retry=True)
    def optimize_io_operations(
        self,
        checkpoint_frequency: int,
        result_persistence_level: PersistenceLevel
    ) -> IOOptimizationResult:
        """
        Optimize I/O operations for checkpointing and result persistence.
        
        Implements batching and compression strategies to minimize I/O overhead
        and improve checkpoint/resume performance.
        
        Args:
            checkpoint_frequency: How often checkpoints are created (in events)
            result_persistence_level: Level of persistence required
            
        Returns:
            IOOptimizationResult with I/O optimization strategies
        """
        logger.info(f"Optimizing I/O operations: checkpoint_freq={checkpoint_frequency}, persistence={result_persistence_level.value}")
        
        with error_handling_context("io_optimization"):
            # Analyze I/O patterns
            io_analysis = self.io_optimizer.analyze_io_patterns(
                checkpoint_frequency, result_persistence_level
            )
            
            # Optimize checkpoint I/O
            checkpoint_optimization = self._optimize_checkpoint_io(io_analysis)
            
            # Optimize result persistence I/O
            persistence_optimization = self._optimize_persistence_io(io_analysis)
            
            # Evaluate compression benefit
            compression_optimization = self.io_optimizer.optimize_compression(
                io_analysis['estimated_checkpoint_size_mb']
            )
            
            # Calculate total I/O reduction
            checkpoint_reduction = checkpoint_optimization.get('io_reduction_percentage', 0.0)
            persistence_reduction = persistence_optimization.get('io_reduction_percentage', 0.0)
            compression_reduction = compression_optimization.get('estimated_savings_percentage', 0.0)
            
            # Weight the reductions by their relative impact
            total_reduction = (
                checkpoint_reduction * 0.4 +
                persistence_reduction * 0.3 +
                compression_reduction * 0.3
            )
            
            result = IOOptimizationResult(
                checkpoint_optimization=checkpoint_optimization,
                persistence_optimization=persistence_optimization,
                compression_optimization=compression_optimization,
                total_io_reduction_percentage=round(total_reduction, 3)
            )
            
            logger.info(f"I/O optimization complete: {result.total_io_reduction_percentage:.1%} total reduction, significant={result.is_significant_improvement}")
            
            return result
    
    def _optimize_checkpoint_io(self, io_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Optimize checkpoint I/O operations."""
        frequency = io_analysis['checkpoint_frequency']
        
        if frequency < 3:
            # High frequency checkpoints - use batching
            strategy = "batching"
            batch_size = self.resource_limits.io_batch_size
            io_reduction = 0.25  # 25% reduction through batching
        elif frequency < 10:
            # Medium frequency - use buffering
            strategy = "buffering"
            batch_size = max(100, self.resource_limits.io_batch_size // 2)
            io_reduction = 0.15  # 15% reduction through buffering
        else:
            # Low frequency - minimal optimization needed
            strategy = "direct"
            batch_size = 1
            io_reduction = 0.05  # 5% reduction through direct optimization
        
        return {
            'strategy': strategy,
            'batch_size': batch_size,
            'io_reduction_percentage': io_reduction,
            'checkpoint_frequency': frequency
        }
    
    def _optimize_persistence_io(self, io_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Optimize result persistence I/O operations."""  
        persistence_level = io_analysis['persistence_level']
        data_size = io_analysis['total_checkpoint_data_mb']
        
        if persistence_level in ['comprehensive', 'full']:
            # High persistence requirements - use streaming writes
            strategy = "streaming_write"
            buffer_size_mb = min(100, self.resource_limits.chunk_size_mb)
            io_reduction = 0.20  # 20% reduction through streaming
        elif persistence_level == 'standard':
            # Standard persistence - use buffered writes
            strategy = "buffered_write"
            buffer_size_mb = min(50, self.resource_limits.chunk_size_mb)
            io_reduction = 0.15  # 15% reduction through buffering  
        else:
            # Minimal persistence - direct writes are fine
            strategy = "direct_write"
            buffer_size_mb = 10
            io_reduction = 0.05  # 5% reduction through direct optimization
        
        return {
            'strategy': strategy,
            'buffer_size_mb': buffer_size_mb,
            'io_reduction_percentage': io_reduction,
            'data_size_mb': data_size
        }
    
    def get_optimization_recommendations(
        self,
        simulation_years: List[int],
        workforce_size: int,
        checkpoint_frequency: int = 5,
        persistence_level: PersistenceLevel = PersistenceLevel.STANDARD
    ) -> Dict[str, Any]:
        """
        Get comprehensive optimization recommendations for a simulation scenario.
        
        Args:
            simulation_years: Years to simulate
            workforce_size: Number of employees
            checkpoint_frequency: Checkpoint frequency
            persistence_level: Required persistence level
            
        Returns:
            Comprehensive optimization recommendations
        """
        logger.info(f"Generating optimization recommendations for {len(simulation_years)} years, {workforce_size:,} employees")
        
        try:
            # Get memory optimization
            memory_result = self.optimize_memory_usage(simulation_years, workforce_size)
            
            # Get I/O optimization  
            io_result = self.optimize_io_operations(checkpoint_frequency, persistence_level)
            
            # Get current resource status
            current_metrics = self.resource_monitor.get_current_metrics()
            
            # Generate overall recommendations
            recommendations = {
                'simulation_parameters': {
                    'years': len(simulation_years),
                    'workforce_size': workforce_size,
                    'checkpoint_frequency': checkpoint_frequency,
                    'persistence_level': persistence_level.value
                },
                'memory_optimization': {
                    'strategy': memory_result.strategy_type,
                    'savings_gb': memory_result.memory_savings_gb,
                    'efficiency_rating': memory_result.efficiency_rating,
                    'recommended_chunk_size': memory_result.recommended_chunk_size,
                    'estimated_time_minutes': memory_result.estimated_processing_time_minutes
                },
                'io_optimization': {
                    'total_reduction_percentage': io_result.total_io_reduction_percentage,
                    'significant_improvement': io_result.is_significant_improvement,
                    'compression_strategy': io_result.compression_optimization['recommended_compression'],
                    'checkpoint_strategy': io_result.checkpoint_optimization['strategy']
                },
                'current_system_status': {
                    'memory_used_gb': current_metrics.memory_used_gb,
                    'memory_available_gb': current_metrics.memory_available_gb,
                    'memory_pressure': current_metrics.memory_pressure_level,
                    'cpu_percentage': current_metrics.cpu_percentage
                },
                'overall_recommendation': self._generate_overall_recommendation(
                    memory_result, io_result, current_metrics
                )
            }
            
            logger.info(f"Generated comprehensive optimization recommendations: {recommendations['overall_recommendation']['summary']}")
            
            return recommendations
            
        except Exception as e:
            logger.error(f"Failed to generate optimization recommendations: {e}")
            raise
    
    def _generate_overall_recommendation(
        self,
        memory_result: MemoryOptimizationResult,
        io_result: IOOptimizationResult,
        current_metrics: ResourceMetrics
    ) -> Dict[str, Any]:
        """Generate overall optimization recommendation."""
        # Assess memory situation
        if memory_result.efficiency_rating in ['excellent', 'good']:
            memory_recommendation = "optimal"
        elif memory_result.efficiency_rating == 'acceptable':
            memory_recommendation = "adequate"
        else:
            memory_recommendation = "concerning"
        
        # Assess I/O situation
        if io_result.is_significant_improvement:
            io_recommendation = "beneficial"
        else:
            io_recommendation = "minimal_benefit"
        
        # Assess current system status
        if current_metrics.memory_pressure_level in ['critical', 'high']:
            system_status = "stressed"
        elif current_metrics.memory_pressure_level == 'moderate':
            system_status = "moderate"
        else:
            system_status = "healthy"
        
        # Generate overall recommendation
        if memory_recommendation == "optimal" and io_recommendation == "beneficial" and system_status == "healthy":
            overall_rating = "excellent"
            summary = "System is well-optimized for simulation requirements"
        elif memory_recommendation in ["optimal", "adequate"] and system_status in ["healthy", "moderate"]:
            overall_rating = "good"
            summary = "System should handle simulation well with recommended optimizations"
        elif system_status == "stressed" or memory_recommendation == "concerning":
            overall_rating = "caution"
            summary = "System may struggle with simulation - consider reducing scope or upgrading resources"
        else:
            overall_rating = "acceptable"
            summary = "System should handle simulation with recommended optimizations"
        
        return {
            'overall_rating': overall_rating,
            'summary': summary,
            'memory_assessment': memory_recommendation,
            'io_assessment': io_recommendation,
            'system_assessment': system_status,
            'key_recommendations': self._generate_key_recommendations(
                memory_result, io_result, current_metrics, overall_rating
            )
        }
    
    def _generate_key_recommendations(
        self,
        memory_result: MemoryOptimizationResult,
        io_result: IOOptimizationResult,
        current_metrics: ResourceMetrics,
        overall_rating: str
    ) -> List[str]:
        """Generate key recommendations based on analysis."""
        recommendations = []
        
        # Memory recommendations
        if memory_result.strategy_type == "streaming":
            recommendations.append(f"Use streaming processing with {memory_result.recommended_chunk_size:,} employee chunks")
        else:
            recommendations.append("Use in-memory processing for optimal performance")
        
        # I/O recommendations
        if io_result.is_significant_improvement:
            compression_type = io_result.compression_optimization['recommended_compression']
            recommendations.append(f"Enable {compression_type} compression for {io_result.total_io_reduction_percentage:.0%} I/O reduction")
        
        # System-specific recommendations
        if current_metrics.memory_pressure_level in ['high', 'critical']:
            recommendations.append("Consider increasing available memory or reducing workforce size")
        
        if overall_rating == "caution":
            recommendations.append("Monitor resource usage closely during simulation")
            recommendations.append("Consider running simulation in smaller batches")
        
        # Performance recommendations
        if memory_result.estimated_processing_time_minutes > 60:
            recommendations.append("Long processing time expected - ensure adequate runtime allocation")
        
        return recommendations
    
    def cleanup(self) -> None:
        """Clean up resources and stop monitoring."""
        try:
            self.resource_monitor.stop_monitoring()
            logger.info("ResourceOptimizer cleanup completed")
        except Exception as e:
            logger.error(f"Error during ResourceOptimizer cleanup: {e}")
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit with cleanup."""
        self.cleanup()


# Factory Functions
def create_resource_optimizer(
    max_memory_gb: float = 8.0,
    max_memory_percentage: float = 0.8,
    enable_monitoring: bool = True
) -> ResourceOptimizer:
    """
    Create a configured ResourceOptimizer instance.
    
    Args:
        max_memory_gb: Maximum memory usage in GB
        max_memory_percentage: Maximum memory as percentage of available
        enable_monitoring: Whether to enable resource monitoring
        
    Returns:
        Configured ResourceOptimizer instance
    """
    limits = ResourceLimits(
        max_memory_gb=max_memory_gb,
        max_memory_percentage=max_memory_percentage
    )
    
    return ResourceOptimizer(
        resource_limits=limits,
        enable_monitoring=enable_monitoring
    )


def get_system_resource_status() -> Dict[str, Any]:
    """
    Get current system resource status for optimization planning.
    
    Returns:
        System resource status information
    """
    memory = psutil.virtual_memory()
    cpu_count = psutil.cpu_count()
    
    return {
        'memory': {
            'total_gb': round(memory.total / (1024**3), 1),
            'available_gb': round(memory.available / (1024**3), 1),
            'used_percentage': round(memory.percent, 1),
            'pressure_level': 'high' if memory.percent > 80 else 'moderate' if memory.percent > 60 else 'low'
        },
        'cpu': {
            'logical_cores': cpu_count,
            'current_usage_percentage': psutil.cpu_percent(interval=1.0)
        },
        'disk': {
            'free_space_gb': round(psutil.disk_usage('/').free / (1024**3), 1)
        },
        'recommendations': {
            'suitable_for_large_simulation': memory.available > 4 * (1024**3),  # 4GB available
            'recommended_max_memory_gb': round(memory.available / (1024**3) * 0.8, 1),
            'streaming_recommended': memory.available < 6 * (1024**3)  # Less than 6GB available
        }
    }