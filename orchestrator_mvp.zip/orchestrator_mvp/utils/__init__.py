"""
Utility modules for the orchestrator_mvp system.

Contains performance benchmarking, optimization utilities, and comprehensive
error handling and resilience patterns for multi-year simulations.
"""

from .performance_benchmark import PerformanceBenchmark, benchmark_dbt_optimizations, BenchmarkResult
from .error_handling import (
    CircuitBreaker, CircuitBreakerConfig, RetryHandler, RetryConfig,
    ErrorClassifier, with_circuit_breaker, with_retry, with_error_handling,
    error_handling_context, get_all_circuit_breaker_stats, reset_all_circuit_breakers
)
from .multi_year_error_handling import (
    CheckpointManager, CheckpointType, MultiYearStateRecovery,
    get_checkpoint_manager, get_state_recovery, create_multi_year_error_context
)
from .simulation_resilience import (
    ResilientDbtExecutor, ResilientDatabaseManager, MultiYearOrchestrationResilience,
    get_resilient_dbt_executor, get_resilient_db_manager, get_orchestration_resilience
)
from .resource_optimizer import (
    ResourceOptimizer, MemoryManager, IOOptimizer, ResourceMonitor,
    ResourceLimits, MemoryRequirements, OptimizationConfig,
    MemoryOptimizationResult, IOOptimizationResult, PersistenceLevel,
    OptimizationStrategy, create_resource_optimizer, get_system_resource_status
)

__all__ = [
    # Performance benchmarking
    "PerformanceBenchmark",
    "benchmark_dbt_optimizations", 
    "BenchmarkResult",
    
    # Core error handling
    "CircuitBreaker",
    "CircuitBreakerConfig", 
    "RetryHandler",
    "RetryConfig",
    "ErrorClassifier",
    "with_circuit_breaker",
    "with_retry", 
    "with_error_handling",
    "error_handling_context",
    "get_all_circuit_breaker_stats",
    "reset_all_circuit_breakers",
    
    # Multi-year error handling
    "CheckpointManager",
    "CheckpointType",
    "MultiYearStateRecovery",
    "get_checkpoint_manager",
    "get_state_recovery",
    "create_multi_year_error_context",
    
    # Simulation resilience
    "ResilientDbtExecutor",
    "ResilientDatabaseManager", 
    "MultiYearOrchestrationResilience",
    "get_resilient_dbt_executor",
    "get_resilient_db_manager",
    "get_orchestration_resilience",
    
    # Resource optimization (S031-04)
    "ResourceOptimizer",
    "MemoryManager",
    "IOOptimizer",
    "ResourceMonitor", 
    "ResourceLimits",
    "MemoryRequirements",
    "OptimizationConfig",
    "MemoryOptimizationResult",
    "IOOptimizationResult",
    "PersistenceLevel",
    "OptimizationStrategy",
    "create_resource_optimizer",
    "get_system_resource_status",
]