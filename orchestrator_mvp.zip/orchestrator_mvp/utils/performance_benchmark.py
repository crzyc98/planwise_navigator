"""
Performance benchmarking utilities for the orchestrator_dbt system.

This module provides comprehensive benchmarking tools to measure and compare
the performance improvements of various optimization strategies.
"""

import time
import statistics
from typing import Dict, List, Any, Callable, Optional
from contextlib import contextmanager
from dataclasses import dataclass
import json
from datetime import datetime


@dataclass
class BenchmarkResult:
    """Result of a performance benchmark."""
    name: str
    execution_time: float
    success: bool
    error_message: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class PerformanceBenchmark:
    """Comprehensive performance benchmarking suite for dbt operations."""
    
    def __init__(self):
        self.results: List[BenchmarkResult] = []
        self.session_start = time.time()
    
    @contextmanager
    def measure(self, operation_name: str, metadata: Optional[Dict[str, Any]] = None):
        """Context manager to measure operation performance."""
        start_time = time.time()
        error_message = None
        success = True
        
        try:
            print(f"⏱️ Starting benchmark: {operation_name}")
            yield
        except Exception as e:
            success = False
            error_message = str(e)
            print(f"❌ Benchmark failed: {operation_name} - {error_message}")
            raise
        finally:
            execution_time = time.time() - start_time
            result = BenchmarkResult(
                name=operation_name,
                execution_time=execution_time,
                success=success,
                error_message=error_message,
                metadata=metadata
            )
            self.results.append(result)
            
            if success:
                print(f"✅ Benchmark completed: {operation_name} - {execution_time:.2f}s")
    
    def benchmark_function(self, func: Callable, name: str, *args, **kwargs) -> BenchmarkResult:
        """Benchmark a specific function."""
        with self.measure(name):
            return func(*args, **kwargs)
    
    def benchmark_multiple_runs(self, func: Callable, name: str, runs: int = 3, *args, **kwargs) -> Dict[str, float]:
        """Benchmark a function multiple times and return statistics."""
        execution_times = []
        
        print(f"🔄 Running {runs} benchmark iterations for: {name}")
        
        for i in range(runs):
            with self.measure(f"{name}_run_{i+1}"):
                func(*args, **kwargs)
                execution_times.append(self.results[-1].execution_time)
        
        stats = {
            "mean": statistics.mean(execution_times),
            "median": statistics.median(execution_times),
            "min": min(execution_times),
            "max": max(execution_times),
            "stdev": statistics.stdev(execution_times) if len(execution_times) > 1 else 0
        }
        
        print(f"📊 Statistics for {name}:")
        print(f"  • Mean: {stats['mean']:.2f}s")
        print(f"  • Median: {stats['median']:.2f}s") 
        print(f"  • Range: {stats['min']:.2f}s - {stats['max']:.2f}s")
        
        return stats
    
    def compare_approaches(self, approaches: Dict[str, Callable], *args, **kwargs) -> Dict[str, BenchmarkResult]:
        """Compare multiple approaches to the same task."""
        results = {}
        
        print(f"🏁 Comparing {len(approaches)} approaches...")
        
        for name, func in approaches.items():
            try:
                with self.measure(f"comparison_{name}"):
                    func(*args, **kwargs)
                results[name] = self.results[-1]
            except Exception as e:
                print(f"❌ Approach {name} failed: {str(e)}")
                results[name] = BenchmarkResult(
                    name=f"comparison_{name}",
                    execution_time=float('inf'),
                    success=False,
                    error_message=str(e)
                )
        
        # Find fastest successful approach
        successful_results = {k: v for k, v in results.items() if v.success}
        if successful_results:
            fastest = min(successful_results.items(), key=lambda x: x[1].execution_time)
            print(f"🏆 Fastest approach: {fastest[0]} ({fastest[1].execution_time:.2f}s)")
            
            # Show performance comparison
            print("📈 Performance comparison:")
            for name, result in sorted(successful_results.items(), key=lambda x: x[1].execution_time):
                speedup = fastest[1].execution_time / result.execution_time
                print(f"  • {name}: {result.execution_time:.2f}s ({speedup:.1f}x slower than fastest)")
        
        return results
    
    def get_summary(self) -> Dict[str, Any]:
        """Get comprehensive benchmark summary."""
        successful_results = [r for r in self.results if r.success]
        failed_results = [r for r in self.results if not r.success]
        
        summary = {
            "session_duration": time.time() - self.session_start,
            "total_operations": len(self.results),
            "successful_operations": len(successful_results),
            "failed_operations": len(failed_results),
            "results": []
        }
        
        if successful_results:
            execution_times = [r.execution_time for r in successful_results]
            summary.update({
                "total_execution_time": sum(execution_times),
                "average_execution_time": statistics.mean(execution_times),
                "fastest_operation": min(successful_results, key=lambda x: x.execution_time),
                "slowest_operation": max(successful_results, key=lambda x: x.execution_time)
            })
        
        # Add detailed results
        for result in self.results:
            summary["results"].append({
                "name": result.name,
                "execution_time": result.execution_time,
                "success": result.success,
                "error_message": result.error_message,
                "metadata": result.metadata
            })
        
        return summary
    
    def print_summary(self):
        """Print formatted benchmark summary."""
        summary = self.get_summary()
        
        print("\n" + "="*80)
        print("📊 PERFORMANCE BENCHMARK SUMMARY")
        print("="*80)
        print(f"Session Duration: {summary['session_duration']:.2f}s")
        print(f"Total Operations: {summary['total_operations']}")
        print(f"Successful: {summary['successful_operations']} | Failed: {summary['failed_operations']}")
        
        if summary['successful_operations'] > 0:
            print(f"Total Execution Time: {summary['total_execution_time']:.2f}s")
            print(f"Average Operation Time: {summary['average_execution_time']:.2f}s")
            print(f"Fastest Operation: {summary['fastest_operation'].name} ({summary['fastest_operation'].execution_time:.2f}s)")
            print(f"Slowest Operation: {summary['slowest_operation'].name} ({summary['slowest_operation'].execution_time:.2f}s)")
        
        if summary['failed_operations'] > 0:
            print("\n❌ Failed Operations:")
            failed_results = [r for r in self.results if not r.success]
            for result in failed_results:
                print(f"  • {result.name}: {result.error_message}")
        
        print("="*80)
    
    def save_results(self, filename: str):
        """Save benchmark results to JSON file."""
        summary = self.get_summary()
        summary['timestamp'] = datetime.now().isoformat()
        
        # Convert BenchmarkResult objects to dictionaries for JSON serialization
        summary['fastest_operation'] = {
            'name': summary['fastest_operation'].name,
            'execution_time': summary['fastest_operation'].execution_time,
            'success': summary['fastest_operation'].success
        } if 'fastest_operation' in summary else None
        
        summary['slowest_operation'] = {
            'name': summary['slowest_operation'].name,
            'execution_time': summary['slowest_operation'].execution_time,
            'success': summary['slowest_operation'].success
        } if 'slowest_operation' in summary else None
        
        with open(filename, 'w') as f:
            json.dump(summary, f, indent=2)
        
        print(f"📁 Benchmark results saved to: {filename}")


def benchmark_dbt_optimizations():
    """
    Comprehensive benchmark comparing different dbt execution strategies.
    
    This function tests:
    1. Sequential execution (current approach)
    2. Batch execution (new approach)
    3. Parallel execution (new approach)
    4. Mixed optimization strategies
    """
    from ..core.common_workflow import load_seed_data, create_staging_tables, build_foundation_models
    from ..core.common_workflow import load_seed_data_and_build_staging_optimized, run_full_optimized_setup
    from ..loaders import run_dbt_seed, run_dbt_batch_seeds, run_dbt_model, run_dbt_batch_models
    
    benchmark = PerformanceBenchmark()
    
    print("🚀 Starting comprehensive dbt optimization benchmark...")
    print("This will compare sequential vs optimized execution strategies")
    
    # Test 1: Individual seed loading vs batch loading
    print("\n" + "="*60)
    print("TEST 1: SEED LOADING STRATEGIES")
    print("="*60)
    
    def individual_seed_loading():
        """Load seeds individually (current approach).""" 
        seeds = ["config_job_levels", "comp_levers", "config_cola_by_year"]
        for seed in seeds:
            run_dbt_seed(seed)
    
    def batch_seed_loading():
        """Load seeds in batch (optimized approach)."""
        seeds = ["config_job_levels", "comp_levers", "config_cola_by_year"]
        run_dbt_batch_seeds(seeds)
    
    seed_approaches = {
        "individual_seeds": individual_seed_loading,
        "batch_seeds": batch_seed_loading
    }
    
    benchmark.compare_approaches(seed_approaches)
    
    # Test 2: Individual model execution vs batch execution
    print("\n" + "="*60)
    print("TEST 2: MODEL EXECUTION STRATEGIES")
    print("="*60)
    
    def individual_model_execution():
        """Run models individually (current approach)."""
        models = ["stg_config_job_levels", "stg_comp_levers", "stg_config_cola_by_year"]
        for model in models:
            run_dbt_model(model)
    
    def batch_model_execution():
        """Run models in batch (optimized approach)."""
        models = ["stg_config_job_levels", "stg_comp_levers", "stg_config_cola_by_year"] 
        run_dbt_batch_models(models)
    
    model_approaches = {
        "individual_models": individual_model_execution,
        "batch_models": batch_model_execution
    }
    
    benchmark.compare_approaches(model_approaches)
    
    # Test 3: Full workflow comparison
    print("\n" + "="*60)
    print("TEST 3: FULL WORKFLOW COMPARISON")
    print("="*60)
    
    def traditional_workflow():
        """Traditional sequential workflow."""
        load_seed_data()
        create_staging_tables()
        build_foundation_models()
    
    def optimized_workflow():
        """Optimized parallel workflow."""
        load_seed_data_and_build_staging_optimized()
    
    workflow_approaches = {
        "traditional_workflow": traditional_workflow,
        "optimized_workflow": optimized_workflow
    }
    
    benchmark.compare_approaches(workflow_approaches)
    
    # Test 4: Multiple runs for statistical significance
    print("\n" + "="*60)
    print("TEST 4: STATISTICAL ANALYSIS (3 RUNS EACH)")
    print("="*60)
    
    traditional_stats = benchmark.benchmark_multiple_runs(
        traditional_workflow, "traditional_workflow_stats", runs=3
    )
    
    optimized_stats = benchmark.benchmark_multiple_runs(
        optimized_workflow, "optimized_workflow_stats", runs=3
    )
    
    # Calculate performance improvement
    improvement = ((traditional_stats["mean"] - optimized_stats["mean"]) / traditional_stats["mean"]) * 100
    
    print(f"\n🎯 PERFORMANCE IMPROVEMENT ANALYSIS:")
    print(f"  • Traditional approach: {traditional_stats['mean']:.2f}s ± {traditional_stats['stdev']:.2f}s")
    print(f"  • Optimized approach: {optimized_stats['mean']:.2f}s ± {optimized_stats['stdev']:.2f}s") 
    print(f"  • Performance improvement: {improvement:.1f}% faster")
    print(f"  • Time saved: {traditional_stats['mean'] - optimized_stats['mean']:.2f}s")
    
    # Generate final report
    benchmark.print_summary()
    
    # Save results
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    benchmark.save_results(f"dbt_optimization_benchmark_{timestamp}.json")
    
    return benchmark


if __name__ == "__main__":
    # Run benchmark when executed directly
    benchmark_dbt_optimizations()