"""
Simulation resilience utilities for robust error handling and recovery.

This module provides utilities for making simulations more resilient to failures,
including enhanced dbt execution with error handling, database operation wrappers,
and multi-year coordination with comprehensive error recovery.
"""

from __future__ import annotations
import time
import logging
from typing import Dict, Any, Optional, List, Callable, Tuple
from contextlib import contextmanager
from datetime import datetime
import json

from .error_handling import (
    CircuitBreakerConfig, RetryConfig, with_error_handling,
    error_handling_context, get_circuit_breaker, get_retry_handler
)
from .multi_year_error_handling import (
    CheckpointType, get_checkpoint_manager, get_state_recovery,
    create_multi_year_error_context, MultiYearCircuitBreaker
)

logger = logging.getLogger(__name__)


class ResilientDbtExecutor:
    """
    Enhanced dbt executor with comprehensive error handling and recovery.
    
    Features:
    - Circuit breaker protection for dbt operations
    - Retry logic with exponential backoff
    - Fallback strategies for different failure types
    - Performance monitoring and optimization
    """
    
    def __init__(self, name: str = "dbt_executor"):
        self.name = name
        
        # Circuit breaker configurations for different dbt operations
        self.model_config = CircuitBreakerConfig(
            failure_threshold=3,
            recovery_timeout_seconds=60,
            success_threshold=2
        )
        
        self.seed_config = CircuitBreakerConfig(
            failure_threshold=2,
            recovery_timeout_seconds=30,
            success_threshold=1
        )
        
        self.test_config = CircuitBreakerConfig(
            failure_threshold=5,
            recovery_timeout_seconds=45,
            success_threshold=2
        )
        
        # Retry configurations
        self.retry_config = RetryConfig(
            max_attempts=3,
            base_delay_seconds=2.0,
            max_delay_seconds=120.0,
            exponential_backoff_multiplier=2.0
        )
        
        self.fallback_strategies: Dict[str, Callable] = {}
        self._register_fallback_strategies()
    
    def _register_fallback_strategies(self):
        """Register fallback strategies for different types of dbt failures."""
        
        def compilation_fallback(operation: str, error: Exception, context: Dict[str, Any]) -> Dict[str, Any]:
            """Fallback for dbt compilation errors."""
            logger.info(f"Attempting compilation fallback for {operation}")
            # Try clearing dbt cache and retrying
            try:
                from ..loaders.staging_loader import run_dbt_command
                cache_result = run_dbt_command(["clean"])
                if cache_result.get("success", False):
                    logger.info("dbt cache cleared successfully")
                    return {"fallback_applied": True, "strategy": "cache_clear"}
            except Exception as e:
                logger.warning(f"Cache clear fallback failed: {e}")
            
            return {"fallback_applied": False}
        
        def dependency_fallback(operation: str, error: Exception, context: Dict[str, Any]) -> Dict[str, Any]:
            """Fallback for dbt dependency errors."""
            logger.info(f"Attempting dependency fallback for {operation}")
            # Try deps command
            try:
                from ..loaders.staging_loader import run_dbt_command
                deps_result = run_dbt_command(["deps"])
                if deps_result.get("success", False):
                    logger.info("dbt dependencies resolved")
                    return {"fallback_applied": True, "strategy": "deps_resolution"}
            except Exception as e:
                logger.warning(f"Dependency fallback failed: {e}")
            
            return {"fallback_applied": False}
        
        def resource_fallback(operation: str, error: Exception, context: Dict[str, Any]) -> Dict[str, Any]:
            """Fallback for resource-related errors."""
            logger.info(f"Attempting resource fallback for {operation}")
            # Add delay and retry with single-threaded execution
            time.sleep(5)  # Brief pause to let resources recover
            return {"fallback_applied": True, "strategy": "resource_pause", "use_single_thread": True}
        
        self.fallback_strategies.update({
            "compilation": compilation_fallback,
            "dependency": dependency_fallback,
            "resource": resource_fallback
        })
    
    def _classify_dbt_error(self, error: Exception, operation: str) -> str:
        """Classify dbt error to determine appropriate fallback strategy."""
        error_message = str(error).lower()
        
        if any(keyword in error_message for keyword in ["compilation", "parse", "syntax"]):
            return "compilation"
        elif any(keyword in error_message for keyword in ["dependency", "missing", "not found"]):
            return "dependency"
        elif any(keyword in error_message for keyword in ["memory", "resource", "timeout"]):
            return "resource"
        else:
            return "unknown"
    
    @with_error_handling(
        operation_name="dbt_model_execution",
        circuit_breaker_config=None,  # Will be set dynamically
        retry_config=None,  # Will be set dynamically
        enable_circuit_breaker=True,
        enable_retry=True
    )
    def run_model_with_resilience(
        self,
        model_name: str,
        vars_dict: Optional[Dict[str, Any]] = None,
        full_refresh: bool = False
    ) -> Dict[str, Any]:
        """
        Run a dbt model with comprehensive error handling and recovery.
        
        Args:
            model_name: Name of the dbt model to run
            vars_dict: Variables to pass to dbt
            full_refresh: Whether to perform full refresh
            
        Returns:
            Dictionary with execution results
        """
        operation_context = {
            "model_name": model_name,
            "vars_dict": vars_dict,
            "full_refresh": full_refresh,
            "start_time": datetime.now()
        }
        
        with error_handling_context(f"dbt_model_{model_name}", operation_context):
            # Get circuit breaker for this operation
            breaker = get_circuit_breaker(f"dbt_model_{model_name}", self.model_config)
            
            def execute_model():
                from ..loaders.staging_loader import run_dbt_model_with_vars, run_dbt_model
                
                if vars_dict:
                    return run_dbt_model_with_vars(model_name, vars_dict, full_refresh)
                else:
                    # For models without variables, use regular run_dbt_model
                    run_dbt_model(model_name)
                    return {"success": True}
            
            try:
                result = breaker.call(execute_model)
                
                # Log success metrics
                execution_time = (datetime.now() - operation_context["start_time"]).total_seconds()
                logger.info(f"dbt model '{model_name}' executed successfully in {execution_time:.2f}s")
                
                return result
                
            except Exception as error:
                # Attempt fallback strategies
                error_type = self._classify_dbt_error(error, f"model_{model_name}")
                
                if error_type in self.fallback_strategies:
                    logger.info(f"Attempting fallback strategy '{error_type}' for model '{model_name}'")
                    fallback_result = self.fallback_strategies[error_type](f"model_{model_name}", error, operation_context)
                    
                    if fallback_result.get("fallback_applied", False):
                        # Retry with fallback applied
                        try:
                            result = execute_model()
                            logger.info(f"Fallback strategy '{error_type}' successful for model '{model_name}'")
                            return result
                        except Exception as fallback_error:
                            logger.error(f"Fallback strategy '{error_type}' failed for model '{model_name}': {fallback_error}")
                
                # If all strategies fail, re-raise the original error
                raise error
    
    @with_error_handling(
        operation_name="dbt_seed_execution",
        circuit_breaker_config=None,  # Will use seed_config
        retry_config=None,  # Will use retry_config
        enable_circuit_breaker=True,
        enable_retry=True
    )
    def run_seeds_with_resilience(self, seed_names: List[str]) -> Dict[str, Any]:
        """
        Run dbt seeds with comprehensive error handling.
        
        Args:
            seed_names: List of seed names to run
            
        Returns:
            Dictionary with execution results
        """
        operation_context = {
            "seed_names": seed_names,
            "start_time": datetime.now()
        }
        
        with error_handling_context(f"dbt_seeds", operation_context):
            breaker = get_circuit_breaker("dbt_seeds", self.seed_config)
            
            def execute_seeds():
                from ..loaders.staging_loader import run_dbt_batch_seeds
                return run_dbt_batch_seeds(seed_names)
            
            try:
                result = breaker.call(execute_seeds)
                
                execution_time = (datetime.now() - operation_context["start_time"]).total_seconds()
                logger.info(f"dbt seeds executed successfully in {execution_time:.2f}s")
                
                return result
                
            except Exception as error:
                # Attempt fallback to individual seed loading
                logger.warning(f"Batch seed loading failed, attempting individual loading: {error}")
                
                try:
                    from ..loaders.staging_loader import run_dbt_seed
                    for seed_name in seed_names:
                        run_dbt_seed(seed_name)
                    
                    logger.info("Individual seed loading fallback successful")
                    return {"success": True, "fallback_used": "individual_loading"}
                    
                except Exception as fallback_error:
                    logger.error(f"Individual seed loading fallback failed: {fallback_error}")
                    raise error
    
    def get_execution_stats(self) -> Dict[str, Any]:
        """Get execution statistics for all dbt operations."""
        from .error_handling import get_all_circuit_breaker_stats
        
        stats = get_all_circuit_breaker_stats()
        dbt_stats = {name: stat for name, stat in stats.items() if name.startswith("dbt_")}
        
        return {
            "total_dbt_operations": len(dbt_stats),
            "circuit_breaker_stats": dbt_stats,
            "overall_health": "healthy" if all(stat["state"] == "closed" for stat in dbt_stats.values()) else "degraded"
        }


class ResilientDatabaseManager:
    """
    Database manager with comprehensive error handling and recovery.
    
    Features:
    - Connection pool management with circuit breakers
    - Automatic retry for transient database errors
    - Data consistency validation
    - Deadlock detection and recovery
    """
    
    def __init__(self, name: str = "database_manager"):
        self.name = name
        
        # Database-specific circuit breaker configuration
        self.db_config = CircuitBreakerConfig(
            failure_threshold=5,
            recovery_timeout_seconds=30,
            success_threshold=3,
            failure_rate_threshold=0.3,
            minimum_requests=5
        )
        
        # Retry configuration for database operations
        self.retry_config = RetryConfig(
            max_attempts=3,
            base_delay_seconds=1.0,
            max_delay_seconds=30.0,
            exponential_backoff_multiplier=1.5
        )
    
    @with_error_handling(
        operation_name="database_query",
        circuit_breaker_config=None,  # Will use db_config
        retry_config=None,  # Will use retry_config
        enable_circuit_breaker=True, 
        enable_retry=True
    )
    def execute_query_with_resilience(
        self,
        query: str,
        params: Optional[List[Any]] = None,
        operation_name: str = "query"
    ) -> Any:
        """
        Execute database query with comprehensive error handling.
        
        Args:
            query: SQL query to execute
            params: Query parameters
            operation_name: Name of the operation for logging
            
        Returns:
            Query result
        """
        from ..core.database_manager import get_connection
        
        operation_context = {
            "query": query[:100] + "..." if len(query) > 100 else query,
            "params": params,
            "operation_name": operation_name,
            "start_time": datetime.now()
        }
        
        with error_handling_context(f"db_{operation_name}", operation_context):
            breaker = get_circuit_breaker(f"db_{operation_name}", self.db_config)
            
            def execute_query():
                conn = get_connection()
                try:
                    if params:
                        return conn.execute(query, params)
                    else:
                        return conn.execute(query)
                finally:
                    conn.close()
            
            result = breaker.call(execute_query)
            
            execution_time = (datetime.now() - operation_context["start_time"]).total_seconds()
            logger.debug(f"Database query '{operation_name}' executed successfully in {execution_time:.3f}s")
            
            return result
    
    def validate_data_consistency(self, table_name: str, year: int) -> Dict[str, Any]:
        """
        Validate data consistency for a specific table and year.
        
        Args:
            table_name: Name of the table to validate
            year: Simulation year to validate
            
        Returns:
            Validation results
        """
        validation_result = {
            "table_name": table_name,
            "year": year,
            "consistent": True,
            "issues": [],
            "metrics": {}
        }
        
        try:
            # Basic row count validation
            result = self.execute_query_with_resilience(
                f"SELECT COUNT(*) FROM {table_name} WHERE simulation_year = ?",
                [year],
                f"validate_{table_name}_count"
            )
            
            row_count = result.fetchone()[0] if result else 0
            validation_result["metrics"]["row_count"] = row_count
            
            if row_count == 0:
                validation_result["consistent"] = False
                validation_result["issues"].append(f"No data found for year {year}")
            
            # Data quality validation (if applicable)
            if "fct_yearly_events" in table_name:
                quality_result = self.execute_query_with_resilience(
                    f"SELECT COUNT(*) FROM {table_name} WHERE simulation_year = ? AND data_quality_flag != 'VALID'",
                    [year],
                    f"validate_{table_name}_quality"
                )
                
                invalid_count = quality_result.fetchone()[0] if quality_result else 0
                validation_result["metrics"]["invalid_records"] = invalid_count
                
                if invalid_count > 0:
                    validation_result["issues"].append(f"{invalid_count} invalid records found")
            
            logger.info(f"Data consistency validation for {table_name} year {year}: {validation_result}")
            return validation_result
            
        except Exception as e:
            validation_result["consistent"] = False
            validation_result["issues"].append(f"Validation error: {str(e)}")
            logger.error(f"Data consistency validation failed for {table_name} year {year}: {e}")
            return validation_result


class MultiYearOrchestrationResilience:
    """
    Resilience utilities specifically for multi-year simulation orchestration.
    
    Features:
    - Year transition validation and recovery
    - Step-level checkpointing
    - Graceful degradation for partial failures
    - Resume capability with state validation
    """
    
    def __init__(self, orchestrator_name: str = "multi_year_orchestrator"):
        self.orchestrator_name = orchestrator_name
        self.checkpoint_manager = get_checkpoint_manager()
        self.state_recovery = get_state_recovery()
        self.circuit_breaker = MultiYearCircuitBreaker(orchestrator_name)
        
        # Resilience configurations
        self.year_transition_config = CircuitBreakerConfig(
            failure_threshold=2,
            recovery_timeout_seconds=60,
            success_threshold=1
        )
        
        self.step_execution_config = RetryConfig(
            max_attempts=2,
            base_delay_seconds=5.0,
            max_delay_seconds=60.0
        )
    
    @contextmanager
    def resilient_year_execution(self, year: int, total_years: int):
        """
        Context manager for resilient execution of a simulation year.
        
        Args:
            year: Current simulation year
            total_years: Total number of years in simulation
        """
        # Create checkpoint at year start
        year_start_checkpoint = self.checkpoint_manager.create_checkpoint(
            CheckpointType.YEAR_START,
            year,
            {"year": year, "status": "starting", "timestamp": datetime.now().isoformat()},
            metadata={"total_years": total_years}
        )
        
        logger.info(f"Created year start checkpoint: {year_start_checkpoint.checkpoint_id}")
        
        try:
            yield
            
            # Create checkpoint at year completion
            year_complete_checkpoint = self.checkpoint_manager.create_checkpoint(
                CheckpointType.YEAR_COMPLETE,
                year,
                {"year": year, "status": "completed", "timestamp": datetime.now().isoformat()},
                metadata={"total_years": total_years}
            )
            
            logger.info(f"Year {year} completed successfully. Checkpoint: {year_complete_checkpoint.checkpoint_id}")
            
        except Exception as error:
            # Create error checkpoint for recovery
            error_checkpoint = self.checkpoint_manager.create_checkpoint(
                CheckpointType.ERROR_CHECKPOINT,
                year,
                {
                    "year": year,
                    "status": "failed",
                    "error": str(error),
                    "error_type": type(error).__name__,
                    "timestamp": datetime.now().isoformat()
                },
                metadata={"total_years": total_years, "error_details": str(error)[:500]}
            )
            
            logger.error(f"Year {year} failed. Error checkpoint: {error_checkpoint.checkpoint_id}")
            
            # Attempt recovery if possible
            recovery_attempted = self._attempt_year_recovery(year, error, total_years)
            if not recovery_attempted:
                logger.error(f"Recovery not possible for year {year}")
            
            raise
    
    @contextmanager
    def resilient_step_execution(self, step_name: str, year: int):
        """
        Context manager for resilient execution of a simulation step.
        
        Args:
            step_name: Name of the simulation step
            year: Current simulation year
        """
        step_start_time = datetime.now()
        
        try:
            logger.info(f"Starting step '{step_name}' for year {year}")
            yield
            
            # Create step completion checkpoint
            execution_time = (datetime.now() - step_start_time).total_seconds()
            step_checkpoint = self.checkpoint_manager.create_checkpoint(
                CheckpointType.STEP_COMPLETE,
                year,
                {
                    "step_name": step_name,
                    "year": year,
                    "status": "completed",
                    "execution_time_seconds": execution_time,
                    "timestamp": datetime.now().isoformat()
                },
                step_name=step_name
            )
            
            logger.info(f"Step '{step_name}' completed successfully in {execution_time:.2f}s. Checkpoint: {step_checkpoint.checkpoint_id}")
            
        except Exception as error:
            execution_time = (datetime.now() - step_start_time).total_seconds()
            
            # Create error checkpoint for step
            error_checkpoint = self.checkpoint_manager.create_checkpoint(
                CheckpointType.ERROR_CHECKPOINT,
                year,
                {
                    "step_name": step_name,
                    "year": year,
                    "status": "failed",
                    "error": str(error),
                    "error_type": type(error).__name__,
                    "execution_time_seconds": execution_time,
                    "timestamp": datetime.now().isoformat()
                },
                step_name=step_name,
                metadata={"error_details": str(error)[:500]}
            )
            
            logger.error(f"Step '{step_name}' failed after {execution_time:.2f}s. Error checkpoint: {error_checkpoint.checkpoint_id}")
            
            # Attempt step-level recovery
            recovery_attempted = self._attempt_step_recovery(step_name, year, error)
            if not recovery_attempted:
                logger.error(f"Recovery not possible for step '{step_name}' in year {year}")
            
            raise
    
    def _attempt_year_recovery(self, year: int, error: Exception, total_years: int) -> bool:
        """
        Attempt to recover from a year-level failure.
        
        Args:
            year: Failed simulation year
            error: The error that occurred
            total_years: Total simulation years
            
        Returns:
            True if recovery was attempted, False otherwise
        """
        try:
            # Check if previous year data is intact
            if year > 1:  # Assuming years start from 1
                validation_result = self.state_recovery.validate_multi_year_consistency(1, year - 1)
                if validation_result["consistent"]:
                    logger.info(f"Previous year data is consistent - year {year} can be retried")
                    
                    # Clear failed year data
                    from ..core.database_manager import get_connection
                    conn = get_connection()
                    try:
                        events_deleted = conn.execute(
                            "DELETE FROM fct_yearly_events WHERE simulation_year = ?", [year]
                        ).rowcount
                        
                        snapshots_deleted = conn.execute(
                            "DELETE FROM fct_workforce_snapshot WHERE simulation_year = ?", [year]
                        ).rowcount
                        
                        logger.info(f"Cleared failed year {year} data: {events_deleted} events, {snapshots_deleted} snapshots")
                        
                    finally:
                        conn.close()
                    
                    return True
            
            return False
            
        except Exception as recovery_error:
            logger.error(f"Year recovery attempt failed: {recovery_error}")
            return False
    
    def _attempt_step_recovery(self, step_name: str, year: int, error: Exception) -> bool:
        """
        Attempt to recover from a step-level failure.
        
        Args:
            step_name: Name of the failed step
            year: Simulation year
            error: The error that occurred
            
        Returns:
            True if recovery was attempted, False otherwise
        """
        try:
            # Step-specific recovery strategies
            if "dbt" in step_name.lower():
                # For dbt steps, try clearing cache
                logger.info(f"Attempting dbt recovery for step '{step_name}'")
                try:
                    from ..loaders.staging_loader import run_dbt_command
                    cache_result = run_dbt_command(["clean"])
                    if cache_result.get("success", False):
                        logger.info("dbt cache cleared for recovery")
                        return True
                except Exception as e:
                    logger.warning(f"dbt cache clear failed: {e}")
            
            elif "database" in step_name.lower() or "validation" in step_name.lower():
                # For database steps, add a brief delay to let locks clear
                logger.info(f"Attempting database recovery for step '{step_name}'")
                time.sleep(5)
                return True
            
            return False
            
        except Exception as recovery_error:
            logger.error(f"Step recovery attempt failed: {recovery_error}")
            return False
    
    def validate_resume_conditions(self, start_year: int, end_year: int) -> Dict[str, Any]:
        """
        Validate conditions for resuming a multi-year simulation.
        
        Args:
            start_year: Start year of simulation
            end_year: End year of simulation
            
        Returns:
            Validation results with resume recommendations
        """
        logger.info(f"Validating resume conditions for simulation years {start_year}-{end_year}")
        
        # Check for incomplete simulation
        detection_result = self.state_recovery.detect_incomplete_simulation(start_year, end_year)
        
        # Validate data consistency
        consistency_result = self.state_recovery.validate_multi_year_consistency(start_year, end_year)
        
        # Check checkpoint availability
        checkpoint_summary = self.checkpoint_manager.get_checkpoint_summary()
        
        resume_validation = {
            "can_resume": False,
            "resume_year": None,
            "resume_strategy": None,
            "validation_results": {
                "incomplete_detection": detection_result,
                "data_consistency": consistency_result,
                "checkpoints": checkpoint_summary
            },
            "recommendations": []
        }
        
        # Determine resume strategy
        if detection_result["incomplete_simulation_detected"]:
            if detection_result["resume_recommendation"]:
                resume_validation["can_resume"] = True
                resume_validation["resume_year"] = detection_result["resume_recommendation"]
                resume_validation["resume_strategy"] = "resume_from_last_completed"
                resume_validation["recommendations"].append(
                    f"Resume simulation from year {detection_result['resume_recommendation']}"
                )
            
            # Check for checkpoint-based resume
            resume_info = self.checkpoint_manager.get_resume_checkpoint(start_year, end_year)
            if resume_info:
                resume_year, checkpoint = resume_info
                if not resume_validation["can_resume"] or resume_year < resume_validation["resume_year"]:
                    resume_validation["can_resume"] = True
                    resume_validation["resume_year"] = resume_year
                    resume_validation["resume_strategy"] = "resume_from_checkpoint"
                    resume_validation["recommendations"].append(
                        f"Resume from checkpoint at year {resume_year}: {checkpoint.checkpoint_id}"
                    )
        
        else:
            resume_validation["recommendations"].append("No incomplete simulation detected - full run required")
        
        # Add data consistency recommendations
        if not consistency_result["consistent"]:
            resume_validation["recommendations"].append("Data consistency issues detected - repair required before resume")
            resume_validation["recommendations"].extend([
                f"Inconsistency: {issue}" for issue in consistency_result["inconsistencies"][:3]
            ])
        
        logger.info(f"Resume validation completed: can_resume={resume_validation['can_resume']}, resume_year={resume_validation['resume_year']}")
        return resume_validation


# Global instances
_dbt_executor: Optional[ResilientDbtExecutor] = None
_db_manager: Optional[ResilientDatabaseManager] = None
_orchestration_resilience: Optional[MultiYearOrchestrationResilience] = None


def get_resilient_dbt_executor() -> ResilientDbtExecutor:
    """Get or create the global resilient dbt executor."""
    global _dbt_executor
    if _dbt_executor is None:
        _dbt_executor = ResilientDbtExecutor()
    return _dbt_executor


def get_resilient_db_manager() -> ResilientDatabaseManager:
    """Get or create the global resilient database manager."""
    global _db_manager
    if _db_manager is None:
        _db_manager = ResilientDatabaseManager()
    return _db_manager


def get_orchestration_resilience(orchestrator_name: str = "multi_year_orchestrator") -> MultiYearOrchestrationResilience:
    """Get or create the global orchestration resilience manager."""
    global _orchestration_resilience
    if _orchestration_resilience is None:
        _orchestration_resilience = MultiYearOrchestrationResilience(orchestrator_name)
    return _orchestration_resilience