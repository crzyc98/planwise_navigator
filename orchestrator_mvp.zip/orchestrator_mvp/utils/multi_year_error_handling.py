"""
Multi-year simulation specific error handling and state recovery mechanisms.

This module provides specialized error handling capabilities for multi-year simulations,
including state recovery, checkpoint management, resume capabilities, and year transition
error handling.
"""

from __future__ import annotations
import os
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Set, Tuple, Callable
from dataclasses import dataclass, field
from enum import Enum
import pickle
import hashlib
from pathlib import Path

from .error_handling import (
    ErrorContext, ErrorSeverity, ErrorCategory, ErrorClassifier,
    CircuitBreakerConfig, RetryConfig, get_circuit_breaker, get_retry_handler,
    get_recovery_manager, with_error_handling, error_handling_context
)

logger = logging.getLogger(__name__)


class SimulationState(Enum):
    """Multi-year simulation states."""
    NOT_STARTED = "not_started"
    INITIALIZING = "initializing"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    RECOVERING = "recovering"


class CheckpointType(Enum):
    """Types of checkpoints in multi-year simulation."""
    SIMULATION_START = "simulation_start"
    YEAR_START = "year_start"
    STEP_COMPLETE = "step_complete"
    YEAR_COMPLETE = "year_complete"
    SIMULATION_COMPLETE = "simulation_complete"
    ERROR_CHECKPOINT = "error_checkpoint"


@dataclass
class SimulationCheckpoint:
    """Represents a simulation checkpoint for recovery purposes."""
    checkpoint_id: str
    checkpoint_type: CheckpointType
    simulation_year: int
    step_name: Optional[str]
    timestamp: datetime
    state_data: Dict[str, Any]
    metadata: Dict[str, Any] = field(default_factory=dict)
    data_hash: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert checkpoint to dictionary for storage."""
        return {
            'checkpoint_id': self.checkpoint_id,
            'checkpoint_type': self.checkpoint_type.value,
            'simulation_year': self.simulation_year,
            'step_name': self.step_name,
            'timestamp': self.timestamp.isoformat(),
            'state_data': self.state_data,
            'metadata': self.metadata,
            'data_hash': self.data_hash
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SimulationCheckpoint':
        """Create checkpoint from dictionary."""
        return cls(
            checkpoint_id=data['checkpoint_id'],
            checkpoint_type=CheckpointType(data['checkpoint_type']),
            simulation_year=data['simulation_year'],
            step_name=data.get('step_name'),
            timestamp=datetime.fromisoformat(data['timestamp']),
            state_data=data['state_data'],
            metadata=data.get('metadata', {}),
            data_hash=data.get('data_hash')
        )


@dataclass
class MultiYearErrorContext:
    """Extended error context for multi-year simulations."""
    base_context: ErrorContext
    simulation_year: int
    step_name: Optional[str]
    total_years: int
    years_completed: List[int]
    years_failed: List[int]
    checkpoint_available: bool
    can_resume: bool
    recovery_options: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for logging and storage."""
        return {
            **self.base_context.to_dict(),
            'simulation_year': self.simulation_year,
            'step_name': self.step_name,
            'total_years': self.total_years,
            'years_completed': self.years_completed,
            'years_failed': self.years_failed,
            'checkpoint_available': self.checkpoint_available,
            'can_resume': self.can_resume,
            'recovery_options': self.recovery_options
        }


class CheckpointManager:
    """
    Manages simulation checkpoints for state recovery and resume capabilities.
    
    Features:
    - Automatic checkpoint creation at key simulation points
    - State validation and integrity checking
    - Efficient storage and retrieval of checkpoint data
    - Cleanup of old/invalid checkpoints
    """
    
    def __init__(self, checkpoint_dir: str = ".checkpoints"):
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(exist_ok=True)
        
        # Active checkpoints by simulation year
        self.checkpoints: Dict[int, List[SimulationCheckpoint]] = {}
        
        # Load existing checkpoints
        self._load_existing_checkpoints()
        
        logger.info(f"Checkpoint manager initialized with directory: {self.checkpoint_dir}")
    
    def _generate_checkpoint_id(self, checkpoint_type: CheckpointType, year: int, step: Optional[str] = None) -> str:
        """Generate unique checkpoint ID."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        if step:
            return f"{checkpoint_type.value}_{year}_{step}_{timestamp}"
        else:
            return f"{checkpoint_type.value}_{year}_{timestamp}"
    
    def _calculate_data_hash(self, data: Dict[str, Any]) -> str:
        """Calculate hash of checkpoint data for integrity checking."""
        data_str = json.dumps(data, sort_keys=True, default=str)
        return hashlib.sha256(data_str.encode()).hexdigest()
    
    def _get_checkpoint_path(self, checkpoint_id: str) -> Path:
        """Get file path for checkpoint."""
        return self.checkpoint_dir / f"{checkpoint_id}.json"
    
    def _load_existing_checkpoints(self) -> None:
        """Load existing checkpoints from disk."""
        try:
            for checkpoint_file in self.checkpoint_dir.glob("*.json"):
                try:
                    with open(checkpoint_file, 'r') as f:
                        checkpoint_data = json.load(f)
                    
                    checkpoint = SimulationCheckpoint.from_dict(checkpoint_data)
                    year = checkpoint.simulation_year
                    
                    if year not in self.checkpoints:
                        self.checkpoints[year] = []
                    
                    self.checkpoints[year].append(checkpoint)
                    logger.debug(f"Loaded checkpoint: {checkpoint.checkpoint_id}")
                    
                except Exception as e:
                    logger.warning(f"Failed to load checkpoint from {checkpoint_file}: {e}")
                    
            total_checkpoints = sum(len(cps) for cps in self.checkpoints.values())
            logger.info(f"Loaded {total_checkpoints} existing checkpoints across {len(self.checkpoints)} years")
            
        except Exception as e:
            logger.error(f"Error loading existing checkpoints: {e}")
    
    def create_checkpoint(
        self,
        checkpoint_type: CheckpointType,
        simulation_year: int,
        state_data: Dict[str, Any],
        step_name: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> SimulationCheckpoint:
        """
        Create a new simulation checkpoint.
        
        Args:
            checkpoint_type: Type of checkpoint
            simulation_year: Year of the simulation
            state_data: State data to save
            step_name: Optional step name
            metadata: Optional metadata
            
        Returns:
            Created checkpoint
        """
        checkpoint_id = self._generate_checkpoint_id(checkpoint_type, simulation_year, step_name)
        data_hash = self._calculate_data_hash(state_data)
        
        checkpoint = SimulationCheckpoint(
            checkpoint_id=checkpoint_id,
            checkpoint_type=checkpoint_type,
            simulation_year=simulation_year,
            step_name=step_name,
            timestamp=datetime.now(),
            state_data=state_data,
            metadata=metadata or {},
            data_hash=data_hash
        )
        
        # Save to disk
        try:
            checkpoint_path = self._get_checkpoint_path(checkpoint_id)
            with open(checkpoint_path, 'w') as f:
                json.dump(checkpoint.to_dict(), f, indent=2, default=str)
            
            # Add to memory
            if simulation_year not in self.checkpoints:
                self.checkpoints[simulation_year] = []
            
            self.checkpoints[simulation_year].append(checkpoint)
            
            logger.info(f"Created checkpoint: {checkpoint_id} for year {simulation_year}")
            return checkpoint
            
        except Exception as e:
            logger.error(f"Failed to create checkpoint {checkpoint_id}: {e}")
            raise
    
    def get_latest_checkpoint(self, simulation_year: int, checkpoint_type: Optional[CheckpointType] = None) -> Optional[SimulationCheckpoint]:
        """Get the latest checkpoint for a simulation year."""
        if simulation_year not in self.checkpoints:
            return None
        
        year_checkpoints = self.checkpoints[simulation_year]
        
        if checkpoint_type:
            filtered_checkpoints = [cp for cp in year_checkpoints if cp.checkpoint_type == checkpoint_type]
        else:
            filtered_checkpoints = year_checkpoints
        
        if not filtered_checkpoints:
            return None
        
        # Return most recent checkpoint
        return max(filtered_checkpoints, key=lambda cp: cp.timestamp)
    
    def get_resume_checkpoint(self, start_year: int, end_year: int) -> Optional[Tuple[int, SimulationCheckpoint]]:
        """
        Find the best checkpoint to resume from for a year range.
        
        Args:
            start_year: Start year of simulation
            end_year: End year of simulation
            
        Returns:
            Tuple of (resume_year, checkpoint) or None if no valid checkpoint found
        """
        best_checkpoint = None
        best_year = None
        
        # Look for the latest completed year checkpoint
        for year in range(end_year, start_year - 1, -1):  # Search backwards
            if year in self.checkpoints:
                year_complete_checkpoint = self.get_latest_checkpoint(year, CheckpointType.YEAR_COMPLETE)
                if year_complete_checkpoint:
                    # Validate checkpoint integrity
                    if self._validate_checkpoint(year_complete_checkpoint):
                        best_checkpoint = year_complete_checkpoint
                        best_year = year + 1  # Resume from next year
                        break
        
        if best_checkpoint and best_year:
            logger.info(f"Found resume checkpoint for year {best_year}: {best_checkpoint.checkpoint_id}")
            return best_year, best_checkpoint
        
        logger.info("No valid resume checkpoint found")
        return None
    
    def _validate_checkpoint(self, checkpoint: SimulationCheckpoint) -> bool:
        """Validate checkpoint integrity."""
        try:
            # Check data hash if available
            if checkpoint.data_hash:
                current_hash = self._calculate_data_hash(checkpoint.state_data)
                if current_hash != checkpoint.data_hash:
                    logger.warning(f"Checkpoint {checkpoint.checkpoint_id} failed hash validation")
                    return False
            
            # Check required state data fields
            required_fields = ['simulation_year', 'step_name']
            for field in required_fields:
                if field not in checkpoint.state_data and hasattr(checkpoint, field) and getattr(checkpoint, field) is not None:
                    continue  # Field is in checkpoint object, not state_data
            
            return True
            
        except Exception as e:
            logger.warning(f"Checkpoint validation failed for {checkpoint.checkpoint_id}: {e}")
            return False
    
    def cleanup_old_checkpoints(self, keep_days: int = 7) -> None:
        """Clean up old checkpoints."""
        cutoff_date = datetime.now() - timedelta(days=keep_days)
        removed_count = 0
        
        for year in list(self.checkpoints.keys()):
            year_checkpoints = self.checkpoints[year]
            valid_checkpoints = []
            
            for checkpoint in year_checkpoints:
                if checkpoint.timestamp > cutoff_date:
                    valid_checkpoints.append(checkpoint)
                else:
                    # Remove checkpoint file
                    try:
                        checkpoint_path = self._get_checkpoint_path(checkpoint.checkpoint_id)
                        if checkpoint_path.exists():
                            checkpoint_path.unlink()
                        removed_count += 1
                    except Exception as e:
                        logger.warning(f"Failed to remove old checkpoint file {checkpoint.checkpoint_id}: {e}")
            
            if valid_checkpoints:
                self.checkpoints[year] = valid_checkpoints
            else:
                del self.checkpoints[year]
        
        logger.info(f"Cleaned up {removed_count} old checkpoints (older than {keep_days} days)")
    
    def get_checkpoint_summary(self) -> Dict[str, Any]:
        """Get summary of available checkpoints."""
        summary = {
            'total_checkpoints': sum(len(cps) for cps in self.checkpoints.values()),
            'years_with_checkpoints': list(self.checkpoints.keys()),
            'checkpoint_types': {},
            'latest_checkpoint': None
        }
        
        all_checkpoints = []
        for year_checkpoints in self.checkpoints.values():
            all_checkpoints.extend(year_checkpoints)
        
        if all_checkpoints:
            # Count by type
            for checkpoint in all_checkpoints:
                cp_type = checkpoint.checkpoint_type.value
                if cp_type not in summary['checkpoint_types']:
                    summary['checkpoint_types'][cp_type] = 0
                summary['checkpoint_types'][cp_type] += 1
            
            # Find latest
            latest = max(all_checkpoints, key=lambda cp: cp.timestamp)
            summary['latest_checkpoint'] = {
                'checkpoint_id': latest.checkpoint_id,
                'year': latest.simulation_year,
                'type': latest.checkpoint_type.value,
                'timestamp': latest.timestamp.isoformat()
            }
        
        return summary


class MultiYearStateRecovery:
    """
    Manages state recovery for multi-year simulations.
    
    Features:
    - Detection of incomplete simulations
    - State reconstruction from checkpoints and database
    - Validation of multi-year data consistency
    - Rollback capabilities for corrupted states
    """
    
    def __init__(self, checkpoint_manager: CheckpointManager):
        self.checkpoint_manager = checkpoint_manager
        
    def detect_incomplete_simulation(self, start_year: int, end_year: int) -> Dict[str, Any]:
        """
        Detect incomplete simulation state and recovery options.
        
        Args:
            start_year: Simulation start year
            end_year: Simulation end year
            
        Returns:
            Dictionary with detection results and recovery options
        """
        from ..core.database_manager import get_connection
        
        detection_result = {
            'incomplete_simulation_detected': False,
            'completed_years': [],
            'failed_years': [],
            'missing_years': [],
            'data_inconsistencies': [],
            'recovery_options': [],
            'resume_recommendation': None
        }
        
        try:
            # Check database for completed years
            conn = get_connection()
            try:
                for year in range(start_year, end_year + 1):
                    # Check workforce snapshot
                    snapshot_check = """
                        SELECT COUNT(*) FROM fct_workforce_snapshot
                        WHERE simulation_year = ? AND employment_status = 'active'
                    """
                    snapshot_result = conn.execute(snapshot_check, [year]).fetchone()
                    
                    # Check yearly events
                    events_check = """
                        SELECT COUNT(*) FROM fct_yearly_events
                        WHERE simulation_year = ?
                    """
                    events_result = conn.execute(events_check, [year]).fetchone()
                    
                    if snapshot_result and snapshot_result[0] > 0 and events_result and events_result[0] > 0:
                        detection_result['completed_years'].append(year)
                    else:
                        detection_result['missing_years'].append(year)
                        
            finally:
                conn.close()
            
            # Check for partial completion
            if detection_result['completed_years'] and detection_result['missing_years']:
                detection_result['incomplete_simulation_detected'] = True
                
                # Find resume point
                if detection_result['completed_years']:
                    last_completed = max(detection_result['completed_years'])
                    if last_completed < end_year:
                        detection_result['resume_recommendation'] = last_completed + 1
                        detection_result['recovery_options'].append(f"Resume from year {last_completed + 1}")
                
                # Check for checkpoints
                resume_info = self.checkpoint_manager.get_resume_checkpoint(start_year, end_year)
                if resume_info:
                    resume_year, checkpoint = resume_info
                    detection_result['recovery_options'].append(f"Resume from checkpoint at year {resume_year}")
                    if not detection_result['resume_recommendation']:
                        detection_result['resume_recommendation'] = resume_year
                
                detection_result['recovery_options'].extend([
                    "Clear and restart simulation",
                    "Rollback to last valid state",
                    "Repair missing data"
                ])
            
            logger.info(f"Incomplete simulation detection: {detection_result}")
            return detection_result
            
        except Exception as e:
            logger.error(f"Error detecting incomplete simulation: {e}")
            detection_result['data_inconsistencies'].append(f"Detection error: {e}")
            return detection_result
    
    def validate_multi_year_consistency(self, start_year: int, end_year: int) -> Dict[str, Any]:
        """
        Validate data consistency across multiple years.
        
        Args:
            start_year: Start year to validate
            end_year: End year to validate
            
        Returns:
            Validation results with any inconsistencies found
        """
        from ..core.database_manager import get_connection
        
        validation_result = {
            'consistent': True,
            'inconsistencies': [],
            'warnings': [],
            'year_validations': {}
        }
        
        try:
            conn = get_connection()
            try:
                for year in range(start_year, end_year + 1):
                    year_validation = self._validate_single_year(conn, year)
                    validation_result['year_validations'][year] = year_validation
                    
                    if not year_validation['valid']:
                        validation_result['consistent'] = False
                        validation_result['inconsistencies'].extend(year_validation['errors'])
                    
                    if year_validation['warnings']:
                        validation_result['warnings'].extend(year_validation['warnings'])
                
                # Cross-year consistency checks
                if len(validation_result['year_validations']) > 1:
                    cross_year_validation = self._validate_cross_year_consistency(conn, start_year, end_year)
                    if not cross_year_validation['valid']:
                        validation_result['consistent'] = False
                        validation_result['inconsistencies'].extend(cross_year_validation['errors'])
                
            finally:
                conn.close()
            
            logger.info(f"Multi-year consistency validation: consistent={validation_result['consistent']}, issues={len(validation_result['inconsistencies'])}")
            return validation_result
            
        except Exception as e:
            logger.error(f"Error validating multi-year consistency: {e}")
            validation_result['consistent'] = False
            validation_result['inconsistencies'].append(f"Validation error: {e}")
            return validation_result
    
    def _validate_single_year(self, conn, year: int) -> Dict[str, Any]:
        """Validate data consistency for a single year."""
        validation = {
            'valid': True,
            'errors': [],
            'warnings': []
        }
        
        try:
            # Check workforce snapshot exists
            snapshot_count = conn.execute(
                "SELECT COUNT(*) FROM fct_workforce_snapshot WHERE simulation_year = ?", [year]
            ).fetchone()[0]
            
            if snapshot_count == 0:
                validation['valid'] = False
                validation['errors'].append(f"No workforce snapshot for year {year}")
            
            # Check events exist
            events_count = conn.execute(
                "SELECT COUNT(*) FROM fct_yearly_events WHERE simulation_year = ?", [year]
            ).fetchone()[0]
            
            if events_count == 0:
                validation['valid'] = False
                validation['errors'].append(f"No events for year {year}")
            
            # Check for data quality flags
            invalid_events = conn.execute(
                "SELECT COUNT(*) FROM fct_yearly_events WHERE simulation_year = ? AND data_quality_flag != 'VALID'", [year]
            ).fetchone()[0]
            
            if invalid_events > 0:
                validation['warnings'].append(f"Year {year} has {invalid_events} invalid events")
            
        except Exception as e:
            validation['valid'] = False
            validation['errors'].append(f"Validation error for year {year}: {e}")
        
        return validation
    
    def _validate_cross_year_consistency(self, conn, start_year: int, end_year: int) -> Dict[str, Any]:
        """Validate consistency across multiple years."""
        validation = {
            'valid': True,
            'errors': [],
            'warnings': []
        }
        
        try:
            # Check workforce continuity between years
            for year in range(start_year, end_year):
                next_year = year + 1
                
                # Get active employees at end of year
                year_end_active = conn.execute("""
                    SELECT COUNT(*) FROM fct_workforce_snapshot
                    WHERE simulation_year = ? AND employment_status = 'active'
                """, [year]).fetchone()[0]
                
                # Get starting workforce for next year (should be similar)
                next_year_events = conn.execute("""
                    SELECT COUNT(*) FROM fct_yearly_events
                    WHERE simulation_year = ?
                """, [next_year]).fetchone()
                
                if not next_year_events or next_year_events[0] == 0:
                    continue  # Next year not completed yet
                
                # Check for reasonable workforce continuity
                # This is a simplified check - more sophisticated logic could be added
                if year_end_active == 0:
                    validation['errors'].append(f"No active employees at end of year {year}")
                    validation['valid'] = False
                
        except Exception as e:
            validation['valid'] = False
            validation['errors'].append(f"Cross-year validation error: {e}")
        
        return validation
    
    def repair_simulation_state(self, start_year: int, end_year: int, repair_strategy: str = "auto") -> bool:
        """
        Attempt to repair simulation state issues.
        
        Args:
            start_year: Start year of simulation
            end_year: End year of simulation
            repair_strategy: Strategy for repair ("auto", "rollback", "rebuild")
            
        Returns:
            True if repair was successful, False otherwise
        """
        logger.info(f"Attempting to repair simulation state for years {start_year}-{end_year} using strategy: {repair_strategy}")
        
        try:
            if repair_strategy == "auto":
                # Detect issues and choose best repair strategy
                detection = self.detect_incomplete_simulation(start_year, end_year)
                
                if not detection['incomplete_simulation_detected']:
                    logger.info("No incomplete simulation detected - no repair needed")
                    return True
                
                # Try checkpoint recovery first
                resume_info = self.checkpoint_manager.get_resume_checkpoint(start_year, end_year)
                if resume_info:
                    return self._repair_from_checkpoint(resume_info[0], resume_info[1])
                
                # Try rollback to last valid state
                if detection['completed_years']:
                    return self._repair_by_rollback(detection['completed_years'], detection['missing_years'])
                
                # Last resort - clear and recommend restart
                logger.warning("Cannot automatically repair - manual intervention required")
                return False
            
            elif repair_strategy == "rollback":
                detection = self.detect_incomplete_simulation(start_year, end_year)
                if detection['completed_years']:
                    return self._repair_by_rollback(detection['completed_years'], detection['missing_years'])
                
            elif repair_strategy == "rebuild":
                return self._repair_by_rebuild(start_year, end_year)
            
            return False
            
        except Exception as e:
            logger.error(f"Error during simulation state repair: {e}")
            return False
    
    def _repair_from_checkpoint(self, resume_year: int, checkpoint: SimulationCheckpoint) -> bool:
        """Repair simulation state using a checkpoint."""
        try:
            logger.info(f"Repairing simulation state from checkpoint: {checkpoint.checkpoint_id}")
            
            # Validate checkpoint
            if not self.checkpoint_manager._validate_checkpoint(checkpoint):
                logger.error("Checkpoint failed validation - cannot repair from it")
                return False
            
            # Clear data for years after the checkpoint
            from ..core.database_manager import get_connection
            conn = get_connection()
            try:
                # Clear events and snapshots for years >= resume_year
                events_deleted = conn.execute(
                    "DELETE FROM fct_yearly_events WHERE simulation_year >= ?", [resume_year]
                ).rowcount
                
                snapshots_deleted = conn.execute(
                    "DELETE FROM fct_workforce_snapshot WHERE simulation_year >= ?", [resume_year]
                ).rowcount
                
                logger.info(f"Cleared {events_deleted} events and {snapshots_deleted} snapshots for repair")
                
            finally:
                conn.close()
            
            logger.info(f"State repair completed - simulation can resume from year {resume_year}")
            return True
            
        except Exception as e:
            logger.error(f"Error repairing from checkpoint: {e}")
            return False
    
    def _repair_by_rollback(self, completed_years: List[int], missing_years: List[int]) -> bool:
        """Repair by rolling back to last completed year."""
        try:
            if not completed_years:
                logger.error("No completed years found - cannot rollback")
                return False
            
            last_completed = max(completed_years)
            logger.info(f"Rolling back to last completed year: {last_completed}")
            
            # Clear data for incomplete years
            from ..core.database_manager import get_connection
            conn = get_connection()
            try:
                for year in missing_years:
                    events_deleted = conn.execute(
                        "DELETE FROM fct_yearly_events WHERE simulation_year = ?", [year]
                    ).rowcount
                    
                    snapshots_deleted = conn.execute(
                        "DELETE FROM fct_workforce_snapshot WHERE simulation_year = ?", [year]
                    ).rowcount
                    
                    logger.info(f"Rolled back year {year}: {events_deleted} events, {snapshots_deleted} snapshots")
                
            finally:
                conn.close()
            
            logger.info(f"Rollback completed - simulation can resume from year {last_completed + 1}")
            return True
            
        except Exception as e:
            logger.error(f"Error during rollback repair: {e}")
            return False
    
    def _repair_by_rebuild(self, start_year: int, end_year: int) -> bool:
        """Repair by clearing all data and recommending full rebuild."""
        try:
            logger.warning(f"Rebuilding simulation state - clearing all data for years {start_year}-{end_year}")
            
            from ..core.database_manager import get_connection
            conn = get_connection()
            try:
                events_deleted = conn.execute(
                    "DELETE FROM fct_yearly_events WHERE simulation_year BETWEEN ? AND ?", [start_year, end_year]
                ).rowcount
                
                snapshots_deleted = conn.execute(
                    "DELETE FROM fct_workforce_snapshot WHERE simulation_year BETWEEN ? AND ?", [start_year, end_year]
                ).rowcount
                
                logger.info(f"Cleared all data: {events_deleted} events, {snapshots_deleted} snapshots")
                
            finally:
                conn.close()
            
            logger.info("Rebuild completed - simulation should be rerun from the beginning")
            return True
            
        except Exception as e:
            logger.error(f"Error during rebuild repair: {e}")
            return False


class MultiYearCircuitBreaker:
    """
    Specialized circuit breaker for multi-year simulation operations.
    
    Features:
    - Year-specific failure tracking
    - Step-level circuit breaking
    - Multi-year failure pattern recognition
    - Graceful degradation strategies
    """
    
    def __init__(self, name: str):
        self.name = name
        self.year_breakers: Dict[int, Any] = {}  # Circuit breakers per year
        self.step_breakers: Dict[str, Any] = {}  # Circuit breakers per step
        
        # Multi-year specific configurations
        self.database_config = CircuitBreakerConfig(
            failure_threshold=3,
            recovery_timeout_seconds=30,
            success_threshold=2
        )
        
        self.dbt_config = CircuitBreakerConfig(
            failure_threshold=2,
            recovery_timeout_seconds=60,
            success_threshold=1
        )
        
        self.validation_config = CircuitBreakerConfig(
            failure_threshold=5,
            recovery_timeout_seconds=10,
            success_threshold=3
        )
    
    def get_database_breaker(self, year: int) -> Any:
        """Get circuit breaker for database operations in a specific year."""
        breaker_name = f"{self.name}_db_{year}"
        return get_circuit_breaker(breaker_name, self.database_config)
    
    def get_dbt_breaker(self, step: str) -> Any:
        """Get circuit breaker for dbt operations in a specific step."""
        breaker_name = f"{self.name}_dbt_{step}"
        return get_circuit_breaker(breaker_name, self.dbt_config)
    
    def get_validation_breaker(self, year: int) -> Any:
        """Get circuit breaker for validation operations in a specific year."""
        breaker_name = f"{self.name}_validation_{year}"
        return get_circuit_breaker(breaker_name, self.validation_config)


# Global instances
_checkpoint_manager: Optional[CheckpointManager] = None
_state_recovery: Optional[MultiYearStateRecovery] = None


def get_checkpoint_manager(checkpoint_dir: str = ".checkpoints") -> CheckpointManager:
    """Get or create the global checkpoint manager."""
    global _checkpoint_manager
    if _checkpoint_manager is None:
        _checkpoint_manager = CheckpointManager(checkpoint_dir)
    return _checkpoint_manager


def get_state_recovery() -> MultiYearStateRecovery:
    """Get or create the global state recovery manager."""
    global _state_recovery
    if _state_recovery is None:
        _state_recovery = MultiYearStateRecovery(get_checkpoint_manager())
    return _state_recovery


def create_multi_year_error_context(
    base_error: Exception,
    operation_name: str,
    simulation_year: int,
    step_name: Optional[str],
    total_years: int,
    years_completed: List[int],
    years_failed: List[int]
) -> MultiYearErrorContext:
    """Create extended error context for multi-year simulations."""
    severity, category = ErrorClassifier.classify_error(base_error, operation_name)
    
    base_context = ErrorContext(
        operation_name=operation_name,
        attempt_number=1,
        total_attempts=1,
        error_type=type(base_error).__name__,
        error_message=str(base_error),
        severity=severity,
        category=category,
        timestamp=datetime.now()
    )
    
    # Check for checkpoints and recovery options
    checkpoint_manager = get_checkpoint_manager()
    checkpoint_available = checkpoint_manager.get_latest_checkpoint(simulation_year) is not None
    
    # Determine if we can resume
    can_resume = len(years_completed) > 0 or checkpoint_available
    
    # Generate recovery options
    recovery_options = []
    if checkpoint_available:
        recovery_options.append("Resume from checkpoint")
    if years_completed:
        recovery_options.append(f"Resume from year {max(years_completed) + 1}")
    recovery_options.extend(["Rollback and retry", "Clear and restart"])
    
    return MultiYearErrorContext(
        base_context=base_context,
        simulation_year=simulation_year,
        step_name=step_name,
        total_years=total_years,
        years_completed=years_completed,
        years_failed=years_failed,
        checkpoint_available=checkpoint_available,
        can_resume=can_resume,
        recovery_options=recovery_options
    )


def register_multi_year_recovery_strategies():
    """Register recovery strategies for multi-year simulation operations."""
    recovery_manager = get_recovery_manager()
    
    def database_recovery_strategy(error_context: ErrorContext):
        """Recovery strategy for database operation failures."""
        logger.info("Attempting database recovery strategy")
        # Add specific database recovery logic here
        # For example: check connection, reset connection pool, etc.
        pass
    
    def dbt_recovery_strategy(error_context: ErrorContext):
        """Recovery strategy for dbt operation failures."""
        logger.info("Attempting dbt recovery strategy")
        # Add specific dbt recovery logic here
        # For example: clear dbt cache, retry with different approach, etc.
        pass
    
    def year_transition_recovery_strategy(error_context: ErrorContext):
        """Recovery strategy for year transition failures."""
        logger.info("Attempting year transition recovery strategy")
        # Add specific year transition recovery logic here
        pass
    
    # Register strategies
    recovery_manager.register_recovery_strategy("database_operation", database_recovery_strategy)
    recovery_manager.register_recovery_strategy("dbt_execution", dbt_recovery_strategy)
    recovery_manager.register_recovery_strategy("year_transition", year_transition_recovery_strategy)
    
    logger.info("Multi-year recovery strategies registered")


# Initialize recovery strategies on module import
register_multi_year_recovery_strategies()