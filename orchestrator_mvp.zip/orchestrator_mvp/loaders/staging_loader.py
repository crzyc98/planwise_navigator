"""Staging data loading operations.

Handles running dbt staging models and related operations.
"""

import os
import subprocess
import json
from pathlib import Path

from ..core.config import DBT_PROJECT_DIR

# Try to find dbt executable
def _get_dbt_executable():
    """Find the dbt executable, checking virtual environment first."""
    # Check if we're in a virtual environment
    project_root = Path(DBT_PROJECT_DIR).parent
    venv_dbt = project_root / "venv" / "bin" / "dbt"

    if venv_dbt.exists():
        return str(venv_dbt)

    # Fallback to system dbt
    return "dbt"


def run_dbt_model(model_name: str) -> None:
    """Run a specific dbt model using subprocess.

    Args:
        model_name: Name of the dbt model to run (e.g., 'stg_census_data')
    """
    print("\n" + "="*60)
    print(f"RUNNING DBT MODEL: {model_name}")
    print("="*60)

    # Save current directory
    original_dir = os.getcwd()

    try:
        # Change to dbt project directory
        os.chdir(DBT_PROJECT_DIR)

        # Construct dbt command
        cmd = [_get_dbt_executable(), "run", "--select", model_name]

        print(f"\nExecuting command: {' '.join(cmd)}")
        print(f"Working directory: {DBT_PROJECT_DIR}")
        print("-" * 40)

        # Run dbt command
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True
        )

        # Print output
        if result.stdout:
            print(result.stdout)

        if result.stderr:
            print("\nSTDERR:")
            print(result.stderr)

        if result.returncode != 0:
            raise RuntimeError(f"dbt run failed with exit code {result.returncode}")

        print(f"\n✅ Successfully ran {model_name}")

    except Exception as e:
        print(f"\n❌ ERROR running dbt model: {str(e)}")
        raise

    finally:
        # Return to original directory
        os.chdir(original_dir)


def run_staging_models() -> None:
    """Run all staging models in sequence."""
    staging_models = [
        "stg_census_data",
        # Add other staging models here as needed
    ]

    print("\n" + "="*60)
    print("RUNNING ALL STAGING MODELS")
    print("="*60)

    for model in staging_models:
        try:
            run_dbt_model(model)
        except Exception as e:
            print(f"\n❌ Failed to run {model}: {str(e)}")
            raise


def run_dbt_seed(seed_name: str) -> None:
    """Run a specific dbt seed using subprocess.

    Args:
        seed_name: Name of the dbt seed to run (e.g., 'config_job_levels')
    """
    print("\n" + "="*60)
    print(f"LOADING DBT SEED: {seed_name}")
    print("="*60)

    # Save current directory
    original_dir = os.getcwd()

    try:
        # Change to dbt project directory
        os.chdir(DBT_PROJECT_DIR)

        # Construct dbt command
        cmd = [_get_dbt_executable(), "seed", "--select", seed_name]

        print(f"\nExecuting command: {' '.join(cmd)}")
        print(f"Working directory: {DBT_PROJECT_DIR}")
        print("-" * 40)

        # Run dbt command
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True
        )

        # Print output
        if result.stdout:
            print(result.stdout)

        if result.stderr:
            print("\nSTDERR:")
            print(result.stderr)

        if result.returncode != 0:
            raise RuntimeError(f"dbt seed failed with exit code {result.returncode}")

        print(f"\n✅ Successfully loaded seed {seed_name}")

    except Exception as e:
        print(f"\n❌ ERROR loading dbt seed: {str(e)}")
        raise

    finally:
        # Return to original directory
        os.chdir(original_dir)


def run_dbt_command(command_args: list) -> None:
    """Run a custom dbt command with arbitrary arguments.

    Args:
        command_args: List of command arguments (e.g., ['test', '--select', 'stg_census_data'])
    """
    # Save current directory
    original_dir = os.getcwd()

    try:
        # Change to dbt project directory
        os.chdir(DBT_PROJECT_DIR)

        # Construct full command
        cmd = [_get_dbt_executable()] + command_args

        print(f"\nExecuting command: {' '.join(cmd)}")
        print(f"Working directory: {DBT_PROJECT_DIR}")
        print("-" * 40)

        # Run command
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True
        )

        # Print output
        if result.stdout:
            print(result.stdout)

        if result.stderr:
            print("\nSTDERR:")
            print(result.stderr)

        if result.returncode != 0:
            raise RuntimeError(f"dbt command failed with exit code {result.returncode}")

        print(f"\n✅ Successfully executed: {' '.join(cmd)}")
        return {"success": True}

    except Exception as e:
        error_msg = f"ERROR running dbt command: {str(e)}"
        print(f"\n❌ {error_msg}")
        return {"success": False, "error": error_msg}

    finally:
        # Return to original directory
        os.chdir(original_dir)


def run_dbt_batch_seeds(seed_names: list) -> dict:
    """Run multiple dbt seeds in a single command to reduce startup overhead.

    Args:
        seed_names: List of seed names to run (e.g., ['config_job_levels', 'comp_levers'])
    
    Returns:
        Dictionary with success status and any error messages
    """
    print("\n" + "="*60)
    print(f"LOADING DBT SEEDS (BATCH): {', '.join(seed_names)}")
    print("="*60)

    # Save current directory
    original_dir = os.getcwd()

    try:
        # Change to dbt project directory
        os.chdir(DBT_PROJECT_DIR)

        # Construct dbt command with multiple selects
        cmd = [_get_dbt_executable(), "seed"]
        
        # Add all seeds as a single select expression
        if len(seed_names) == 1:
            cmd.extend(["--select", seed_names[0]])
        else:
            # Use space-separated model names for multiple selection
            select_expr = " ".join(seed_names)
            cmd.extend(["--select", select_expr])

        print(f"\nExecuting command: {' '.join(cmd)}")
        print(f"Working directory: {DBT_PROJECT_DIR}")
        print("-" * 40)

        # Run dbt command
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True
        )

        # Print output
        if result.stdout:
            print(result.stdout)

        if result.stderr:
            print("\nSTDERR:")
            print(result.stderr)

        if result.returncode != 0:
            error_msg = f"dbt seed batch failed with exit code {result.returncode}"
            print(f"\n❌ ERROR: {error_msg}")
            return {"success": False, "error": error_msg}

        print(f"\n✅ Successfully loaded seeds: {', '.join(seed_names)}")
        return {"success": True}

    except Exception as e:
        error_msg = f"ERROR loading dbt seeds batch: {str(e)}"
        print(f"\n❌ {error_msg}")
        return {"success": False, "error": error_msg}

    finally:
        # Return to original directory
        os.chdir(original_dir)


def run_dbt_batch_models(model_names: list) -> dict:
    """Run multiple dbt models in a single command to reduce startup overhead.

    Args:
        model_names: List of model names to run (e.g., ['stg_config_job_levels', 'stg_comp_levers'])
    
    Returns:
        Dictionary with success status and any error messages
    """
    print("\n" + "="*60)
    print(f"RUNNING DBT MODELS (BATCH): {', '.join(model_names)}")
    print("="*60)

    # Save current directory
    original_dir = os.getcwd()

    try:
        # Change to dbt project directory
        os.chdir(DBT_PROJECT_DIR)

        # Construct dbt command with multiple selects
        cmd = [_get_dbt_executable(), "run"]
        
        # Add all models as a single select expression
        if len(model_names) == 1:
            cmd.extend(["--select", model_names[0]])
        else:
            # Use space-separated model names for multiple selection
            select_expr = " ".join(model_names)
            cmd.extend(["--select", select_expr])

        print(f"\nExecuting command: {' '.join(cmd)}")
        print(f"Working directory: {DBT_PROJECT_DIR}")
        print("-" * 40)

        # Run dbt command
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True
        )

        # Print output
        if result.stdout:
            print(result.stdout)

        if result.stderr:
            print("\nSTDERR:")
            print(result.stderr)

        if result.returncode != 0:
            error_msg = f"dbt run batch failed with exit code {result.returncode}"
            print(f"\n❌ ERROR: {error_msg}")
            return {"success": False, "error": error_msg}

        print(f"\n✅ Successfully ran models: {', '.join(model_names)}")
        return {"success": True}

    except Exception as e:
        error_msg = f"ERROR running dbt models batch: {str(e)}"
        print(f"\n❌ {error_msg}")
        return {"success": False, "error": error_msg}

    finally:
        # Return to original directory
        os.chdir(original_dir)


def run_dbt_threaded_models(model_names: list, thread_count: int = 4) -> dict:
    """Run multiple dbt models using dbt's built-in threading (SAFE - fixes database locking).
    
    This function uses a single dbt process with --threads flag instead of multiple
    processes, preventing DuckDB file locking conflicts.

    Args:
        model_names: List of model names to run (e.g., ['stg_config_job_levels', 'stg_comp_levers'])
        thread_count: Number of threads for dbt to use internally (default: 4)
    
    Returns:
        Dictionary with success status and any error messages
    """
    print("\n" + "="*60)
    print(f"RUNNING DBT MODELS (THREADED - {thread_count} threads): {', '.join(model_names)}")
    print("="*60)
    print(f"🔧 Using dbt's built-in threading to prevent database locking conflicts")

    # Save current directory
    original_dir = os.getcwd()

    try:
        # Change to dbt project directory
        os.chdir(DBT_PROJECT_DIR)

        # Construct dbt command with threading
        cmd = [_get_dbt_executable(), "run"]
        
        # Add all models as a single select expression
        if len(model_names) == 1:
            cmd.extend(["--select", model_names[0]])
        else:
            # Use space-separated model names for multiple selection
            select_expr = " ".join(model_names)
            cmd.extend(["--select", select_expr])
        
        # Add threading parameter (KEY FIX - single process with internal threading)
        cmd.extend(["--threads", str(thread_count)])

        print(f"\nExecuting command: {' '.join(cmd)}")
        print(f"Working directory: {DBT_PROJECT_DIR}")
        print(f"Thread count: {thread_count}")
        print("-" * 40)

        # Run the command
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=600  # 10 minute timeout
        )

        print("\nSTDOUT:")
        print(result.stdout)

        if result.stderr:
            print("\nSTDERR:")
            print(result.stderr)

        if result.returncode == 0:
            success_msg = f"✅ Successfully ran {len(model_names)} dbt models with {thread_count} threads"
            print(f"\n{success_msg}")
            return {"success": True, "message": success_msg}
        else:
            error_msg = f"❌ dbt command failed with return code {result.returncode}"
            print(f"\n{error_msg}")
            return {"success": False, "error": error_msg, "stderr": result.stderr}

    except subprocess.TimeoutExpired:
        error_msg = f"❌ dbt command timed out after 600 seconds"
        print(f"\n{error_msg}")
        return {"success": False, "error": error_msg}
    except Exception as e:
        error_msg = f"ERROR running dbt threaded models: {str(e)}"
        print(f"\n❌ {error_msg}")
        return {"success": False, "error": error_msg}

    finally:
        # Return to original directory
        os.chdir(original_dir)


def run_dbt_parallel_groups(model_groups: list) -> dict:
    """Run multiple groups of dbt models in parallel using threading.
    
    Args:
        model_groups: List of model group lists, where each group can run in parallel
                     e.g., [['model1', 'model2'], ['model3', 'model4']]
    
    Returns:
        Dictionary with success status and any error messages
    """
    import threading
    import queue
    
    print("\n" + "="*60)
    print(f"RUNNING DBT MODELS (PARALLEL GROUPS)")
    print("="*60)
    
    # Results queue for thread communication
    results_queue = queue.Queue()
    threads = []
    
    def run_group_worker(group_models, group_id):
        """Worker function to run a group of models."""
        try:
            result = run_dbt_batch_models(group_models)
            results_queue.put((group_id, result))
        except Exception as e:
            results_queue.put((group_id, {"success": False, "error": str(e)}))
    
    try:
        # Start threads for each group
        for i, group in enumerate(model_groups):
            print(f"Starting parallel group {i+1}: {group}")
            thread = threading.Thread(
                target=run_group_worker, 
                args=(group, i),
                name=f"dbt-group-{i}"
            )
            threads.append(thread)
            thread.start()
        
        # Wait for all threads to complete and collect results
        group_results = {}
        for thread in threads:
            thread.join(timeout=300)  # 5 minute timeout per group
            if thread.is_alive():
                return {"success": False, "error": f"Thread {thread.name} timed out"}
        
        # Collect all results
        while not results_queue.empty():
            group_id, result = results_queue.get()
            group_results[group_id] = result
        
        # Check if all groups succeeded
        failed_groups = [gid for gid, result in group_results.items() if not result.get("success", False)]
        
        if failed_groups:
            error_details = [f"Group {gid}: {group_results[gid].get('error', 'Unknown error')}" for gid in failed_groups]
            return {"success": False, "error": f"Failed groups: {', '.join(map(str, failed_groups))}. Details: {'; '.join(error_details)}"}
        
        print(f"\n✅ All parallel groups completed successfully")
        return {"success": True, "group_results": group_results}
        
    except Exception as e:
        error_msg = f"ERROR in parallel execution: {str(e)}"
        print(f"\n❌ {error_msg}")
        return {"success": False, "error": error_msg}


def run_dbt_model_with_vars(model_name: str, vars_dict: dict, full_refresh: bool = False) -> dict:
    """Run a specific dbt model with variable parameters.

    Args:
        model_name: Name of the dbt model to run (e.g., 'fct_workforce_snapshot')
        vars_dict: Dictionary of variables to pass to dbt (e.g., {'simulation_year': 2025})

    Returns:
        Dictionary with success status and any error messages
    """
    print("\n" + "="*60)
    print(f"RUNNING DBT MODEL WITH VARS: {model_name}")
    print(f"Variables: {vars_dict}")
    print("="*60)

    # Save current directory
    original_dir = os.getcwd()

    try:
        # Change to dbt project directory
        os.chdir(DBT_PROJECT_DIR)

        # Construct dbt command with variables
        cmd = [_get_dbt_executable(), "run", "--select", model_name]

        # Add full-refresh flag if requested
        if full_refresh:
            cmd.append("--full-refresh")

        # Add variables if provided
        if vars_dict:
            # Format vars as a JSON string for proper parsing
            vars_json = json.dumps(vars_dict)
            cmd.extend(["--vars", vars_json])

        print(f"\nExecuting command: {' '.join(cmd)}")
        print(f"Working directory: {DBT_PROJECT_DIR}")
        print("-" * 40)

        # Run dbt command
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True
        )

        # Print output
        if result.stdout:
            print(result.stdout)

        if result.stderr:
            print("\nSTDERR:")
            print(result.stderr)

        if result.returncode != 0:
            error_msg = f"dbt run failed with exit code {result.returncode}"
            print(f"\n❌ ERROR: {error_msg}")
            return {"success": False, "error": error_msg}

        print(f"\n✅ Successfully ran {model_name} with variables")
        return {"success": True}

    except Exception as e:
        error_msg = f"ERROR running dbt model with vars: {str(e)}"
        print(f"\n❌ {error_msg}")
        return {"success": False, "error": error_msg}

    finally:
        # Return to original directory
        os.chdir(original_dir)
