"""Resources package for PlanWise Navigator."""

from .duckdb_resource import DuckDBResource

__all__ = ["DuckDBResource"]
